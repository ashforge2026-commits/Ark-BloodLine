BLOODLINEBANK v0.6.3 — COMPACT DESKTOP LAYOUT

This smaller ZIP uses high-quality WebP for catalog portraits.
All poses keep their original resolution, transparency, and color maps.

Unzip into a new folder, import project.godot in Godot 4.6, and press F5.
Your existing BloodlineBank collection and breeding projects use the
same local data directory as v0.6.2.

Click the arrow at the end of the navigation dock to switch between
icons and icons with labels. Settings / Data > Layout lets you dock
navigation on the left, right, top, or bottom and set the preview width.
Layout preferences are stored locally and apply on the next launch.

Select a creature in the Library or Color Table to open its preview.
Drag the divider to resize, or focus it and press Left or Right.
Use the preview header arrow or Escape to close, and the toolbar
button to reopen the selected creature. Recent width is remembered.

The Library and Color Table show only the rows that fit on a screen.
Use Previous and Next to reach the rest. Projects, Partner Finder,
Lowest Stats, Color Bingo and other long desktop lists have page
controls. In Color Bingo, choose Coverage or Carriers to open
the matching view. Color Lab has a side-by-side desktop workbench.

----------------------------------------------------------------------

BLOODLINEBANK v0.6.2 — CREATURE CATALOG AND POSES

Extract this ZIP into a new folder. In Godot 4.6, import project.godot
and press F5 to run the app.

In Color Lab, click the creature name and search for a species or
variant. Try Argentavis, X-Rex, Enigmasaur, Cat or Lumina. You can
also open an imported creature in the library and select
Try these colors in Color Lab to use its confirmed colors.

Use the pose menu to switch views where available. Alternate angles,
sex-specific looks and coat patterns are labeled separately.
The same color design follows the creature when you switch views.

The search catalog contains 629 names across 1,338 blueprint records.
Records include variants, bosses, mission variants and legacy entries.
The app uses the exact blueprint from an export for creature identity.
The 378 names with artwork have 404 static 2D views and 380 matching
recolor masks. Twenty-four names have multiple views or patterns.
Some entries have color metadata but still need a capture or a mask.
Portraits and masks are bundled for offline use. Assets are credited in
LICENSE_species_images.txt and LICENSE_ark_smart_breeding.txt.

PC and mobile layouts use the same catalog. Your existing local
BloodlineBank saves are read from the same app data folder.

----------------------------------------------------------------------

BLOODLINEBANK v0.6.1 — CUSTOM RESOLUTION

Go to Settings / Data > Display > Custom resolution. Enter the window
width and height in pixels, then click Apply size. Use Default size to
restore 1280 × 720.

The size is saved for Windowed and Borderless modes. When the window
would exceed the monitor's available space, the app fits it to the
screen and keeps the requested size for later. Fullscreen uses the
monitor size.

To try actual window resizing in the Godot 4.6 editor, turn off Embed
Game on Next Play in the Game tab and run the app in its own window.

----------------------------------------------------------------------

BLOODLINEBANK v0.6.0 — MOBILE DINO EXPORT LOCATION

On Android, open the Godot 4.6+ project and run it. Go to More >
Files & Backups > Mobile Dino Export Location. In Android Files,
choose a folder such as Documents/BloodlineBank and tap Use this
folder. The app remembers your mobile choice.

Tap Import and choose your DinoExports ZIP. Review the selected
location and tap Import & extract. The extracted files go under
BloodlineBank Extracted inside the selected folder. If the ZIP's
creatures are already imported, tap Extract ZIP. Individual INI
files still import directly into the library.

The initial location is the app's private Mobile Dino Exports folder.
Choose a folder in Documents if you want to browse the extracted
files from Android Files. The mobile and desktop locations are
saved independently.

This download is the Godot project. See TEST_REPORT.txt for mobile
layout checks and Android device verification status.

----------------------------------------------------------------------

BLOODLINEBANK v0.5.9 — SIMPLER COLOR

Open Settings / Data > Appearance. Under Simpler color, pick one color
and click Apply theme. BloodlineBank uses the color to make dark
backgrounds, lighter panels and a brighter accent. Black makes a
neutral charcoal theme with a light gray accent.

Use Individual colors to fine-tune any part of the theme. Restore
defaults brings back the original blue. The chosen theme is saved
for the next launch.

----------------------------------------------------------------------

BLOODLINEBANK v0.5.8 — DISPLAY SETTINGS

Open Settings / Data and choose one of the three tabs:

Appearance — Change and save the app's colors.
Display — Choose Windowed, Borderless window, Maximized, Fullscreen,
or Exclusive fullscreen, then click Apply mode. The choice is saved
for the next launch. Minimize window is a one-time action.
Files — Choose where BloodlineBank scans for DinoExports and extracts
imported ZIPs. This tab also contains auto-sync and file review.

F11 switches between Windowed and Fullscreen. From the other saved
modes, F11 returns to Windowed. A Borderless window hides the title
bar at windowed size. Fullscreen fills the monitor.

When testing with Godot 4.6, launch in a separate window to test native
display modes. In the Game tab, turn off Embed Game on Next Play
under the embedding options, then press F5.

----------------------------------------------------------------------

BLOODLINEBANK v0.5.7 — COLOR LAB AND WORKSPACE

Open project.godot with Godot 4.6 and press F5.

Creature Library — Choose a species beside the search field. Combine it
with Name, Color ID or exact Level. In Color ID mode, choose a region
when you only want a match in that slot.

Color Lab — Click any of the six swatches from R0 to R5. A slot marked ×
is unused on that species. Lock a color to keep it during Randomize.
Name your design and click Save design. To reopen it, choose its
species and click the saved design in the list.

Designs are stored in the app at user://color_lab_designs.json. On
Windows the folder is %APPDATA%\BloodlineBank_Prototype. The first
Color Lab visit copies older saved palettes into the new file. The ARK
export folder is used for creature imports.

Projects — Click Add creatures from library to show the picker. Expand
picker gives it more room and temporarily hides Notes. Restore picker
brings Notes back. Use the picker's name, sex and exact-level filters
to find creatures, then choose their destination breeding list.

Partner Finder — Choose a species and search by Color ID, Name or
Level. Color ID ranks males by confirmed matching regions. Pick a male
and use Find Females to see the females that contribute missing regions.

Settings / Data — Under Appearance, set the tint of the background,
navigation, main panels, detail panels and accent. Click Apply colors.
Restore defaults is in the same section. These colors affect the app
interface, with ARK palette swatches and creature previews using ARK
colors. Appearance is saved independently in user://appearance.cfg.
The app-wide appearance controls are on desktop.

See TEST_REPORT.txt for verification details.

----------------------------------------------------------------------

BLOODLINEBANK v0.5.6 — LIBRARY SEARCH AND BINGO UI

Use the selector on the left of the Creature Library search box.
Name searches creature and species names. Color ID accepts exact IDs
such as 79 or #79. Use All regions or choose a specific region.
Level searches for the exact displayed level, such as 41.

Color Bingo shows headings above Creature, Find color, Sort by and
Filter values. Color cards use a larger name, with the ID in the
swatch. The sidebar scrolls on shorter windows.

The previous demo ZIP with 10 Concavenators and 10 Enigmasaurs is
still in examples/. The demo import instructions are below.

----------------------------------------------------------------------

DEMO PACK

examples/DEMO_Concavenators_and_Enigmasaurs.zip contains 20 fictional
creatures: five males and five females of each species. In Creature
Library, choose Import .ini / .zip, select the demo ZIP, then confirm.
For a separate demo folder, use Export folder… first. BloodlineBank
copies files from confirmed ZIPs into the selected export folder.

Try color #79 in Partner Finder to compare males and see females that
fill missing regions. The demo set also includes full #75 coverage in
Bingo and varied stats for Lowest Stats.

----------------------------------------------------------------------

BLOODLINEBANK v0.5.5 — CONCAVENATOR AND ENIGMASAUR

Open Color Lab and choose X-Otter, Concavenator, or Enigmasaur.
Concavenator edits regions 0, 2, and 5. Enigmasaur edits all six and has
Side view and Front angle poses. Both poses use the same color design.
Pick a color manually, randomize unlocked regions, or save a design
for the selected species. From a creature's details, use Try these
colors in Color Lab to start with its confirmed colors.

Import as usual. Both species work in the library, Color Table, Bingo,
Partner Finder, Projects and Lowest Stats. The mobile color pages and
Partner Finder have a species selector. Previously imported Enigmasaurs
with the known blueprint are recognized on startup.

The pose assets are from arkutils/species-images, commit
3e2c7ce6f28a55fc92d697e682ab2a54e8c56c75.
https://github.com/arkutils/species-images
See LICENSE_species_images.txt for the MIT license.
The added region labels come from ARK Smart Breeding ASA values,
commit 6d4cefffc4c83ed6f09788f254addf23322661c5.
https://github.com/cadon/ARKStatsExtractor
See LICENSE_ark_smart_breeding.txt for its MIT license.

----------------------------------------------------------------------

BLOODLINEBANK v0.5.4 — EXPORT FOLDER SHORTCUT

Open Creature Library and click Export folder… beside Import .ini / .zip.
Choose the folder that holds your ARK exports. BloodlineBank saves the
choice and scans it immediately. With auto-sync enabled, later scans use
that folder. Hover over Export folder… to see the current path.

Previously imported creatures stay in your library. Manage auto-sync or
return to the detected Steam folder from Settings / Data.

----------------------------------------------------------------------

BLOODLINEBANK v0.5.3 — CLEAR FEMALE X MARKS

In Partner Finder, click Clear all X marks next to the female results
count. The reset is immediate and saves every female as unmarked,
including females outside the current results. The button is disabled
when there are no X marks. You can mark females individually again.

----------------------------------------------------------------------

BLOODLINEBANK v0.5.2 — PARTNER FINDER MALE COLOR SEARCH

Open Partner Finder and type 79 or #79 into the male search box. Males
are ranked by how many confirmed active regions carry that exact ID.
The Matching column shows the count, and matching swatches have an outline.
For X-Otters, unused region 1 is excluded from the count.

Click a male to set the searched color as his Target color, then click
Find Females. In the current version, choose Name or Level from the mode menu.
Clear the box to return to the general male list.

Open project.godot in Godot 4.6 and press F5 to run. See TEST_REPORT.txt
for verification details.

----------------------------------------------------------------------

BLOODLINEBANK v0.5.0 — MOBILE BETA + COLOR LAB
Read MOBILE_COLOR_LAB_0_5_0_README.txt FIRST for features, PC and Android
setup, honest testing status, and important phone data-import limitations.
The original 0.4.5 guidance and historical notes remain below.

----------------------------------------------------------------------

BLOODLINEBANK 0.4.5 — LOWEST STATS TRACKER

Open Lowest Stats in the sidebar to compare imported creatures from the same
species/variant. X-Otter is preferred when available. The table shows minimum
values for Health, Stamina, Oxygen, Food, Weight, Melee and Movement Speed;
Torpidity is included in Displayed Stats as a reference only.

- Breeding points: compares exported NumberOfLevelUpPointsApplied[] fields if
  present. Points not present in an export are UNKNOWN, not zero. A 0 is
  evidence of zero in that exported field, not proof a baby will be level 1.
  Mutated levels and other game factors are not independently confirmed here.
- Displayed stats: compares HP / Stamina / Oxygen / Food / Weight / Melee /
  Movement Speed / Torpidity from existing import fields. These are useful
  references, NOT verified inheritable stat levels. Leveling and imprinting
  can affect these values.
- The app chooses Breeding points only if the selected species has at least
  one exported point value; otherwise it starts on Displayed stats.
- Click a stat to see all known Otters ranked lowest to highest in the right
  panel, including tied minimum carriers. Click a carrier to open the Library.
- Unknown fields are excluded from comparisons, counted separately, and
  never silently replaced with zero.
- The tracker is read-only: creature data, projects, the Partner Finder X marks,
  import behavior and saved JSON structure are unchanged.

TESTING: A new synthetic regression script tests/test_lowest_stats.gd is included
but has NOT been run inside Godot in this build environment. Before trusting a
Level 1 breeding decision, test an actual exported Otter and compare its raw
point fields with its in-game stats / a validated stat extractor.

BLOODLINEBANK 0.4.2 — PARTNER FINDER

New read-only breeding match tab. See PARTNER_FINDER_0_4_2_README.txt
for the workflow and test instructions. All 0.4.1 reorder-list changes stay intact.

BLOODLINEBANK 0.4.1 — REORDER WHOLE BREEDING LISTS

See LIST_ORDER_0_4_1_README.txt for instructions and compatibility details.

BLOODLINEBANK 0.3.9 — GODOT SOURCE PROJECT
========================================

This ZIP contains an editable Godot 4.6 project, not a standalone EXE.
Open it with the standard Godot 4.6 editor; the project uses GDScript and
requires no C#/.NET installation when using the standard Godot editor.

UPDATING FROM 0.2 OR 0.3.x
1. Close the old app, extract this ZIP into a new folder, and open Godot 4.6.
2. Choose Import and select project.godot inside this extracted 0.3.9 folder.
3. Open the project and press F5. Wait for images to import on first launch.
4. Your previous creatures and goals should load automatically. The save
   path and format remain the same as versions 0.2 and 0.3.x. You do not need to
   reimport the demo.

The Windows library is normally in:
%APPDATA%\BloodlineBank_Prototype\
The library is bloodlinebank.json; a previous-save backup is beside it.
If your previous creatures do not appear, do not delete your old project or
saved files. Ask for help so the library path can be checked.

AUTOMATIC IMPORT
1. Open Settings / Data. BloodlineBank creates a default Exported Dino
   folder inside its local user-data folder and scans it on startup.
2. Click Show folder to open that folder, or Choose folder to select your
   existing ARK DinoExports folder. The chosen folder is remembered.
3. Put dino INIs or ZIPs in the folder. Start the app again, or click
   Scan now. New identified dinos are added; unchanged files are skipped.
4. ZIPs are kept intact. Regular ZIP files are extracted into a separate
   BloodlineBank Extracted subfolder. Nested names are flattened with a
   stable prefix to prevent collisions; ordinary non-INI files are kept.
   The app imports supported creature INIs only. It does not execute files.
5. A changed creature or a creature without a verified game ID is held for
   review. Open Settings / Data and click its Review button. Confirm an
   update only after checking it. Invalid or unsupported files are reported
   there as scan issues. A missing folder does not erase your library.
6. Selecting a ZIP via Import Creature also offers review. ZIP extraction
   starts after confirmation; cancel leaves the folder and library unchanged.

Deleting an identified creature stops automatic scans from re-adding it.
Use Import Creature to restore it intentionally. Source files remain intact.

COLOR TABLE
- Open Color Table in the sidebar. Each row uses your existing saved library
  and shows the creature, level, sex, and six separate colored region cells.
- Filter any region by its exact color ID or part of its color name. Filters
  combine: for example, R0 = 90 and R2 = 83 finds both on the same creature.
  Enter ? to find an unidentified color. Click Clear to reset the filters.
- Click R0–R5 to sort by that region's ID; click the same heading again to
  reverse. Unknown and confirmed-unused regions remain at the end.
- ? means the ID is not confirmed. — means species data marks that region
  unused. If visible-region metadata is unknown, recorded IDs can still be
  shown; check in game whether those regions are actually visible.
- Select a creature to see its existing details. Color Bingo opens for the
  selected creature's species. Filters remain while switching tabs.
- Hide details gives the table more width on a smaller screen. The table can
  also scroll sideways, with the region headings following the rows.
- Copy rows copies ALL matching rows, across pages, as tab-separated text
  with IDs and color names. Paste into a spreadsheet or message yourself.
  The copied text does not include colored cell backgrounds.

PROJECTS: NAMED BREEDING LISTS (UPDATED IN 0.3.9)
- Projects keeps the same color table and sex/level data as your Library.
- Open Projects and select an existing project or create a named one.
- Previous creatures and row order remain. All old creatures appear in Main List.
- Under Breeding lists, type a group name like First Breed or Second Batch
  and click + New list; add as many groups as you need.
- Each group is collapsible. Edit the name on its header to rename it.
- Position numbers replace the old Your label input: enter 1 or 5, then
  press Enter or click away to move to that position INSIDE the group.
  The position always counts the whole saved list, even with filters active.
- Drag the ↕ handle onto another row to reorder, or use the ↑ ↓ buttons.
  Dragging onto a row in another group also transfers the creature there.
- Choose Move to list on each row to move between groups without duplicating.
- In the Add creatures area, select Add to: [group] to add new otters there.
- Delete a group only after confirmation; otters move back to Main List.
  Deleting a group NEVER deletes any creature from the library or project.
- Project notes at the top remain collapsible and support completed checkboxes.
- Expand workspace / Restore layout still gives you more screen space.
- Old custom aliases are retained in data and shown as the row name when
  present. No original library creature name, color, sex or stats are changed.
- See PROJECT_LISTS_0_3_9_README.txt for current steps and tests.

COLOR BINGO
- Select Color Bingo from the sidebar and choose a species.
- Search by color name or ID, sort ID low to high/high to low/Bingo first,
  Bingo + most regions, or filter completed colors, one region away,
  or needs review. Bingo + most regions lists completed colors first, then
  by the number of confirmed regions from most to least; equal progress is
  ordered by color ID. Colors without data remain at the end.
- Each card shows collection coverage for the species' active regions.
  Select a card to see a region summary and the creatures carrying its color.
  Carrier names include levels; click a name to open that creature.
- In Creatures by region, each gold star is one confirmed visible region on
  THAT creature with the selected color. A five-star X-Otter has that color
  in all five of its visible regions. The All star ratings menu can show
  an exact rating, such as 3 stars. Higher ratings appear first.
- Unknown/ambiguous IDs and unused regions do not add stars. A creature
  with unknown regions could have more matches than are currently shown.
- BINGO means that color is present across all active visible regions of
  your collection. It does not mean one creature is already solid, or that
  a compatible breeding pair or a solid baby is guaranteed.
- IDs 1–255 are listed. This build has definitions for 227 of them; the rest
  say Not in color data and are not counted as complete or missing.
- A ? color needs review. Hover the region in the creature details for its
  stored raw value or possible IDs. It is not automatically called missing.

PREVIEW QUALITY AND LIMITS
- The Creature Library's large image is centered and limited to 280 pixels,
  so it is enlarged less. It shrinks further if the available space is small.
- Enlarged creature previews use alpha-aware cubic scaling and mild detail
  sharpening. Thumbnails and previews at native size retain their existing
  rendering. This does not change a creature's stored colors or stats.
- The X-Otter source image and its mask are still 256 x 256. Scaling improves
  their presentation but cannot recover missing fur detail. True higher
  detail needs a higher-resolution image AND a matching, perfectly aligned
  color-region mask. The preview remains an approximation of ARK.
- The official image-creation guide explains how to capture aligned views:
  https://github.com/cadon/ARKStatsExtractor/wiki/Creating-New-Images
  If a suitable new pair becomes available, close Godot and back up the
  project first. Replace both x_otter.png and x_otter_mask.png in
  assets/creatures with the matched PNG pair, then reopen Godot so it can
  reimport them. The images must have the same dimensions and framing, and
  the mask must use the Smart Breeding region colors. Test all regions.
- Bundled colorable images: X-Otter, Yutyrannus and Magmasaur. Other
  recognized species can still be shown without a creature picture.
- Focus stats compare displayed values; inheritable breeding points and
  automatic pairing are not yet confirmed or calculated.
- Encrypted, ZIP64, split archives, unsafe paths and links are not supported.
  ZIPs are limited to 50 MB, INIs to 1 MB each, other files to 16 MB each,
  and total uncompressed contents to 64 MB. Nested ZIP files are preserved
  as files but are not automatically unpacked a second time.
- Older versions had Linux Godot tests. The new 0.3.9 list features have
  passed static checks, but require Godot runtime/Windows testing. See
  TEST_REPORT.txt for details.

SOURCES AND CREDITS
Color/species data and color-rendering approach: ARK Smart Breeding
https://github.com/cadon/ARKStatsExtractor
Creature images and masks: https://github.com/arkutils/species-images
See the LICENSE text files for upstream licenses. ARK and creature imagery
belong to their respective owners.
