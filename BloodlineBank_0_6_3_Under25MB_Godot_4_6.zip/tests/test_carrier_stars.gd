extends SceneTree

const Palette = preload("res://scripts/palette.gd")
const Registry = preload("res://scripts/species_registry.gd")
const Parser = preload("res://scripts/ark_parser.gd")
const Goals = preload("res://scripts/color_goals.gd")
const Bingo = preload("res://scripts/bingo.gd")
var failures: Array = []

func check(value: bool, label: String) -> void:
	if value:
		print("PASS: ", label)
	else:
		printerr("FAIL: ", label)
		failures.append(label)

func _initialize() -> void:
	call_deferred("_run")

func carrier_rows(host: Node) -> Array:
	var result: Array = []
	for child in host.get_children():
		if child is HBoxContainer and child.has_node("BingoCarrierStars"):
			result.append(child)
	return result

func _run() -> void:
	root.size = Vector2i(1280, 720)
	var palette = Palette.new()
	var parser = Parser.new(palette, Registry.new())
	var example = parser.parse_export(FileAccess.get_file_as_string("res://examples/DEMO_Female_XOtter.ini"), "DEMO.ini")["creature"]
	var key = str(example["species_key"])
	var visible = [0, 2, 3, 4, 5]
	var creatures: Array = []
	for count in range(1, 6):
		var creature = example.duplicate(true)
		creature["local_id"] = "matching-%s" % count
		creature["name"] = "Unnamed X-Otter"
		creature["level"] = 176
		for i in range(visible.size()):
			creature["regions"][visible[i]] = palette.from_id(90 if i < count else 79)
		# Region 1 is invisible for this species, even if it contains the color.
		creature["regions"][1] = palette.from_id(90)
		if count == 3:
			# A possible fourth match must not count until its ID is confirmed.
			creature["regions"][4] = {"state": "ambiguous", "id": null, "candidates": [90, 86], "raw": []}
		creatures.append(creature)
	var other = creatures[4].duplicate(true)
	other["local_id"] = "different-species"
	other["species_key"] = "different-species"
	creatures.append(other)
	var goal = Goals.calculate(creatures, key, example["region_names"], 90)
	var counts = Bingo.carrier_match_counts(goal)
	for count in range(1, 6):
		check(int(counts.get("matching-%s" % count, 0)) == count, "%s confirmed matching regions yield %s stars" % [count, count])
	check(not counts.has("different-species"), "another species does not affect star ratings")
	var duplicate_id_goal = {"regions": [{"status": "found", "carrier_ids": ["same", "same", ""]}]}
	check(Bingo.carrier_match_counts(duplicate_id_goal) == {"same": 1}, "duplicate IDs in one region are counted once and empty IDs are ignored")
	var six_regions: Array = []
	for i in range(6):
		six_regions.append({"status": "found", "carrier_ids": ["six"]})
	check(int(Bingo.carrier_match_counts({"regions": six_regions}).get("six", 0)) == 6, "species with six visible regions can earn six stars")
	var app = load("res://main.tscn").instantiate()
	root.add_child(app)
	app.data = {"version": 1, "creatures": creatures, "goals": {}}
	app.selected_id = "matching-5"
	app.bingo_color_id = 90
	app._show_bingo()
	await process_frame
	await process_frame
	app.bingo_detail_box.find_child("BingoCarriersTab", true, false).pressed.emit()
	var host = app.bingo_detail_box.find_child("BingoCarrierRows", true, false)
	var option = app.bingo_detail_box.find_child("BingoStarFilter", true, false)
	check(host != null and option != null, "Bingo displays carrier stars and a rating filter")
	if host != null and option != null:
		var rows = carrier_rows(host)
		check(rows.size() == 15, "all five creatures appear for their confirmed regions")
		var scores: Array = []
		for i in range(mini(5, rows.size())):
			scores.append(rows[i].get_node("BingoCarrierStars").text.length())
		check(scores == [5, 4, 3, 2, 1], "each region lists higher star ratings first")
		for count in range(1, 6):
			var option_index = option.get_item_index(count)
			option.select(option_index)
			option.item_selected.emit(option_index)
			rows = carrier_rows(host)
			var exact_match = rows.size() == count
			for row in rows:
				exact_match = exact_match and row.get_node("BingoCarrierStars").text == "★".repeat(count)
			check(exact_match, "%s-star filter shows exactly the matching creature's regions" % count)
		app._render_bingo_carriers(host, goal, counts, 6)
		check(carrier_rows(host).is_empty() and host.get_child_count() == 1 and str(host.get_child(0).text).contains("No creatures"), "an empty star filter gives a clear message")
		var option_index = option.get_item_index(3)
		option.select(option_index)
		option.item_selected.emit(option_index)
		rows = carrier_rows(host)
		if not rows.is_empty():
			rows[0].get_node("BingoCarrierButton").pressed.emit()
			check(app.selected_page == "library" and app.selected_id == "matching-3", "a filtered carrier opens the correct creature")
	for dimensions in [Vector2i(1680, 1050), Vector2i(1280, 720), Vector2i(1024, 768), Vector2i(960, 640)]:
		root.size = dimensions
		await process_frame
		await process_frame
		var holder = app.details.find_child("LibraryPreviewHolder", true, false)
		var picture = holder.get_node_or_null("LibraryCreaturePreview") if holder != null else null
		var fits = picture != null and picture.size.x > 0 and picture.size.x <= 280.01 and picture.size.y <= 280.01
		if fits:
			fits = picture.size.x <= holder.size.x + 0.01 and picture.size.y <= holder.size.y + 0.01
			fits = fits and picture.position.is_equal_approx((holder.size - picture.size) * 0.5)
		check(fits, "library image stays centered and within its smaller area at %sx%s" % [dimensions.x, dimensions.y])
	app.queue_free()
	await process_frame
	print("CARRIER STAR TESTS COMPLETE; failures: ", failures.size())
	quit(0 if failures.is_empty() else 1)
