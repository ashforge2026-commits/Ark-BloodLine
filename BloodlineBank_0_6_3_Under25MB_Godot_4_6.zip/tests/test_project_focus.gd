extends SceneTree

# Run with BLOODLINEBANK_TEST_MODE=1, BLOODLINEBANK_DISABLE_AUTOSCAN=1,
# and an isolated user data directory. This test does not require ARK.
const Store = preload("res://scripts/storage.gd")
const Parser = preload("res://scripts/ark_parser.gd")
const Palette = preload("res://scripts/palette.gd")
const Registry = preload("res://scripts/species_registry.gd")
const Plans = preload("res://scripts/project_plans.gd")
var failures: Array = []

func check(ok: bool, explanation: String) -> void:
	if ok:
		print("PASS: ", explanation)
	else:
		printerr("FAIL: ", explanation)
		failures.append(explanation)

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	if OS.get_environment("BLOODLINEBANK_TEST_MODE") != "1":
		printerr("Set BLOODLINEBANK_TEST_MODE=1 and disable auto scan for tests.")
		quit(1)
		return
	root.size = Vector2i(1280, 720)
	var app = load("res://main.tscn").instantiate()
	root.add_child(app)
	var path = "user://_bloodlinebank_focus_038_%s.json" % Time.get_ticks_usec()
	app.storage = Store.new(path)
	app.data = app.storage.empty_data()
	var parser = Parser.new(Palette.new(), Registry.new())
	var specimen = parser.parse_export(FileAccess.get_file_as_string("res://examples/DEMO_Female_XOtter.ini"), "demo.ini")["creature"]
	specimen["local_id"] = "focus-test-female"
	app.data["creatures"] = [specimen]
	app._show_projects()
	app.project_name_field.text = "Focus Test"
	app._create_project()
	app._project_add_creature("focus-test-female")
	var project_before: Dictionary = app.data.duplicate(true)
	var filter_before: String = "Female"
	app.project_query = filter_before
	app._show_projects()
	await process_frame
	await process_frame
	var normal_width: float = app.middle.size.x
	var normal_height: float = app.project_rows_scroll.size.y
	var initial_scroll: ScrollContainer = app.project_rows_scroll
	var initial_rows = app.project_table_rows
	check(app.find_child("ProjectExpandToggle", true, false) != null, "Expand button is available")
	check(app.sidebar_panel.visible and app.project_header_options.visible, "normal mode shows sidebar and project controls")
	check(not app.project_focus_expanded, "normal mode starts collapsed")
	app.project_expand_button.pressed.emit()
	await process_frame
	await process_frame
	check(app.project_focus_expanded, "expand button activates focus mode")
	check(not app.sidebar_panel.visible and not app.project_header_options.visible, "focus mode hides navigation and project controls")
	check(app.middle.size.x > normal_width + 24, "focus mode increases planning width")
	check(app.project_rows_scroll.size.y > normal_height + 20, "focus mode increases table height")
	check(app.project_expand_button.text == "Restore layout" and app.project_expand_button.is_visible_in_tree(), "Restore remains accessible")
	check(app.project_rows_scroll == initial_scroll and app.project_table_rows == initial_rows, "toggle keeps the original table and scroll objects")
	check(app.project_query == filter_before and app.data == project_before, "focus toggle does not reset filters or modify saved data")
	app.project_expand_button.pressed.emit()
	await process_frame
	await process_frame
	check(not app.project_focus_expanded and app.sidebar_panel.visible and app.project_header_options.visible, "restore returns to normal")
	check(abs(app.middle.size.x - normal_width) < 2, "normal width is restored")
	app.project_expand_button.pressed.emit()
	app._project_toggle_notes()
	check(app.project_focus_expanded and not app.sidebar_panel.visible, "project redraw keeps focus mode")
	app._show_color_table()
	check(app.sidebar_panel.visible and not app.project_focus_expanded, "switching pages restores sidebar")
	app._show_projects()
	check(app.sidebar_panel.visible and not app.project_focus_expanded, "reentering Projects starts normal")
	check(Plans.members_of(app._project_current()).size() == 1 and app.data["creatures"].size() == 1, "creature membership is unchanged")
	app.queue_free()
	await process_frame
	for suffix in ["", ".tmp", ".backup"]:
		if FileAccess.file_exists(path + suffix):
			DirAccess.remove_absolute(ProjectSettings.globalize_path(path + suffix))
	print("FOCUS VIEW TESTS COMPLETE; failures: ", failures.size())
	quit(0 if failures.is_empty() else 1)
