extends SceneTree

var failures: Array = []

func check(condition: bool, description: String) -> void:
	if condition:
		print("PASS: ", description)
	else:
		failures.append(description)
		printerr("FAIL: ", description)

func inside_view(rect: Rect2, viewport: Vector2) -> bool:
	return rect.position.x >= -1 and rect.position.y >= -1 and rect.end.x <= viewport.x + 1 and rect.end.y <= viewport.y + 1

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	root.size = Vector2i(1280, 720)
	var app = load("res://main.tscn").instantiate()
	root.add_child(app)
	var example = app.parser.parse_export(FileAccess.get_file_as_string("res://examples/DEMO_Female_XOtter.ini"), "DEMO.ini")["creature"]
	app.data = {"version": 1, "creatures": [], "goals": {}}
	for i in range(30):
		var creature = example.duplicate(true)
		creature["local_id"] = "layout-test-%s" % i
		creature["name"] = "Example X-Otter %s" % i
		if i == 0:
			creature["warnings"] = ["A long import note that must remain reachable. ".repeat(120)]
		app.data["creatures"].append(creature)
	app.selected_id = "layout-test-0"
	app._show_library()
	app.search_mode_picker.select(1)
	app.search_mode_picker.item_selected.emit(1)
	for dimensions in [Vector2i(1680, 1050), Vector2i(1600, 900), Vector2i(1280, 720), Vector2i(1152, 648), Vector2i(1024, 768), Vector2i(960, 640)]:
		root.size = dimensions
		await process_frame
		await process_frame
		await process_frame
		var viewport = app.get_viewport_rect().size
		var table_scroll: ScrollContainer = app.list_box.get_parent().get_parent()
		var details_scroll: ScrollContainer = app.details.get_child(0).get_child(0)
		var detail_content: Control = details_scroll.get_child(0)
		var size_label = "%sx%s" % [dimensions.x, dimensions.y]
		print("LAYOUT ", size_label, ": middle=", app.middle.get_global_rect(), " details=", app.details.get_global_rect(), " table=", table_scroll.get_global_rect())
		check(inside_view(app.middle.get_global_rect(), viewport), size_label + " library area fits viewport")
		check(inside_view(app.details.get_global_rect(), viewport), size_label + " details area fits viewport")
		check(inside_view(table_scroll.get_global_rect(), viewport), size_label + " table viewport fits")
		var table_content: Control = table_scroll.get_child(0)
		check(not table_scroll.get_h_scroll_bar().visible and not table_scroll.get_v_scroll_bar().visible, size_label + " library uses pages without scrollbars")
		check(table_content.get_combined_minimum_size().x <= table_scroll.size.x + 1, size_label + " all table columns fit")
		check(table_content.get_combined_minimum_size().y <= table_scroll.size.y + 1, size_label + " all visible rows fit")
		check(detail_content.get_combined_minimum_size().x <= details_scroll.size.x + 1, size_label + " detail content does not clip horizontally")
		check(detail_content.get_combined_minimum_size().y <= details_scroll.size.y + 1, size_label + " preview actions and stats fit vertically")
		for input_control in [app.search_mode_picker, app.search_field, app.search_region, app.sort_field]:
			check(inside_view(input_control.get_global_rect(), viewport) and input_control.get_global_rect().end.x <= app.middle.get_global_rect().end.x + 1, size_label + " search control fits")
		var first_row = app.list_box.get_child(0)
		var swatch = first_row.get_child(0).get_child(3).get_child(0)
		check(swatch.size.y <= 28, size_label + " table color swatches are compact")
	app._show_goals()
	app.goal_color.text = "6"
	app._refresh_goal()
	for dimensions in [Vector2i(1680, 1050), Vector2i(1280, 720), Vector2i(1024, 768), Vector2i(960, 640)]:
		root.size = dimensions
		await process_frame
		await process_frame
		var viewport = app.get_viewport_rect().size
		var label = "goals %sx%s" % [dimensions.x, dimensions.y]
		print("LAYOUT ", label, ": middle=", app.middle.get_global_rect(), " details=", app.details.get_global_rect())
		check(inside_view(app.middle.get_global_rect(), viewport), label + " controls fit viewport")
		check(inside_view(app.details.get_global_rect(), viewport), label + " preview fits viewport")
		for input_control in [app.goal_species, app.goal_color, app.goal_stat_1, app.goal_stat_2, app.goal_note, app.goal_header_info, app.goal_result.get_parent()]:
			var control_fits = inside_view(input_control.get_global_rect(), viewport) and input_control.get_global_rect().end.x <= app.middle.get_global_rect().end.x + 1
			if not control_fits:
				print("OUTSIDE: ", input_control.get_class(), " rect=", input_control.get_global_rect(), " min=", input_control.get_combined_minimum_size())
			check(control_fits, label + " goal control fits")
	app.queue_free()
	await process_frame
	print("LAYOUT TESTS COMPLETE; failures: ", failures.size())
	quit(0 if failures.is_empty() else 1)
