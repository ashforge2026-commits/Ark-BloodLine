extends SceneTree

const Plans = preload("res://scripts/project_plans.gd")
const Layout = preload("res://scripts/layout_settings.gd")
var failed = 0

func _initialize() -> void:
	call_deferred("_run")

func check(ok: bool, message: String) -> void:
	if ok:
		print("PASS: ", message)
	else:
		failed += 1
		printerr("FAIL: ", message)

func settle() -> void:
	for _frame in range(3):
		await process_frame

func app_fits(app) -> bool:
	var viewport = app.get_viewport_rect()
	var screen = viewport.grow(1)
	for item in [app.sidebar_panel, app.workspace, app.middle, app.details]:
		if item.visible and not screen.encloses(item.get_global_rect()):
			print(item.get_class(), " outside viewport: ", item.get_global_rect(), " / ", viewport)
			return false
	return true

func add_samples(app) -> void:
	for i in range(444):
		var file = "res://examples/DEMO_%s_XOtter.ini" % ("Female" if i % 2 else "Male")
		var item: Dictionary = app.parser.parse_export(FileAccess.get_file_as_string(file))["creature"]
		item["local_id"] = "compact-%s" % i
		item["name"] = "Library X-Otter with a readable name %03d" % i
		item["neutered"] = false
		item["regions"][0] = app.palette.from_id(75)
		item["regions"][2] = app.palette.from_id(75)
		item["regions"][3] = app.palette.from_id(75)
		item["regions"][4] = app.palette.from_id(75)
		item["regions"][5] = app.palette.from_id(6 if i % 2 == 0 else 75)
		app.data["creatures"].append(item)

func _run() -> void:
	root.size = Vector2i(1280, 720)
	var app = load("res://main.tscn").instantiate()
	root.add_child(app)
	await settle()
	check(not app.details.visible, "empty library opens at full width")
	add_samples(app)
	app._show_library()
	await settle()
	var count: int = app.list_box.get_child_count()
	check(count >= 12 and count <= 20 and not app.next_button.disabled, "444 creatures use window-sized library pages")
	app.next_button.pressed.emit()
	check(app.page_index == 1, "Next advances to the next set of creatures")
	app.list_box.get_child(0).pressed.emit()
	await settle()
	var old_width: float = app.details.size.x
	check(app.details.visible and app.preview_splitter.visible, "selecting a creature opens its preview and splitter")
	var down = InputEventMouseButton.new()
	down.button_index = MOUSE_BUTTON_LEFT
	down.pressed = true
	down.global_position = Vector2(900, 200)
	app.preview_splitter._gui_input(down)
	var move = InputEventMouseMotion.new()
	move.global_position = Vector2(842, 200)
	app.preview_splitter._gui_input(move)
	var up = InputEventMouseButton.new()
	up.button_index = MOUSE_BUTTON_LEFT
	up.pressed = false
	app.preview_splitter._gui_input(up)
	await settle()
	check(app.details.size.x > old_width + 45 and int(Layout.load_layout()["preview"]) == int(app.details.size.x), "mouse drag changes and saves the preview width")
	var id = app.selected_id
	var collapse = app.details.find_child("CollapseCreaturePreview", true, false) as Button
	collapse.pressed.emit()
	check(not app.details.visible and not app.preview_splitter.visible, "collapse gives the table its width back")
	app.library_preview_button.pressed.emit()
	await settle()
	check(app.details.visible and app.selected_id == id and app.details.size.x > old_width + 45, "reopen restores the selected creature and preview width")
	app.sidebar_panel.find_child("NavigationLabelToggle", true, false).pressed.emit()
	check(app.nav_buttons["library"].text == "Creature Library" and app.nav_buttons["library"].icon != null, "switching to text mode keeps icons visible")
	app._show_settings()
	app.middle.get_node("SettingsTabs").current_tab = 3
	var picker = app.middle.find_child("LayoutNavigationPosition", true, false) as OptionButton
	for dock in [1, 2, 3, 0]:
		picker.select(dock)
		picker.item_selected.emit(dock)
		await settle()
		check(int(Layout.load_layout()["dock"]) == dock and app.shell.vertical == (dock >= 2) and app.sidebar_panel.get_index() == (0 if dock in [0, 2] else 1), "dock position %s applies and persists" % dock)
	app.middle.find_child("LayoutReset", true, false).pressed.emit()
	check(Layout.load_layout() == Layout.DEFAULTS, "Reset layout restores the default icon dock and preview width")

	app._show_projects()
	app.project_name_field.text = "Compact breeding board"
	app._create_project()
	for i in range(18):
		Plans.add_member(app.data["projects"][app.project_id], "compact-%s" % i)
	app._show_projects()
	await settle()
	var pager = app.project_rows_scroll.get_parent()
	var project_page = pager.next
	check(project_page.visible and not project_page.disabled, "large projects offer page navigation")
	project_page.pressed.emit()
	await settle()
	check(app.project_rows_scroll.scroll_vertical > 0 and not app.project_rows_scroll.get_v_scroll_bar().visible, "project pages advance without a draggable scrollbar")

	for dimensions in [Vector2i(1680, 1050), Vector2i(1280, 720), Vector2i(960, 640)]:
		root.size = dimensions
		await settle()
		for key in ["library", "color_table", "color_lab", "projects", "partner", "low_stats", "bingo", "goals", "settings"]:
			app._nav_pressed(key)
			if key == "partner":
				app._partner_select_male("compact-0")
				var target: OptionButton = app.partner_color_select
				for i in range(target.item_count):
					if target.get_item_id(i) == 75:
						target.select(i)
						target.item_selected.emit(i)
						break
				app._partner_run_search()
			elif key == "bingo":
				app.bingo_detail_box.find_child("BingoCarriersTab", true, false).pressed.emit()
				await settle()
				var carriers = app.bingo_detail_box.find_child("BingoCarrierRows", true, false)
				check(carriers.get_child_count() < 50 and app.bingo_carrier_footer.get_child(2).visible, "Bingo pages the 444-creature carrier list")
			elif key == "goals":
				app.goal_color.text = "75"
				app._refresh_goal()
			await settle()
			check(app_fits(app), "%s fits %sx%s" % [key, dimensions.x, dimensions.y])
			var visible_bars: Array = []
			for scroll in app.workspace.find_children("*", "ScrollContainer", true, false):
				if scroll.is_visible_in_tree() and (scroll.get_h_scroll_bar().visible or scroll.get_v_scroll_bar().visible):
					visible_bars.append(str(scroll.get_path()))
			check(visible_bars.is_empty(), "%s uses page controls instead of visible scrollbars: %s" % [key, visible_bars])
		app._nav_pressed("import")
		await settle()
		check(app.file_dialog.visible, "the import dock action opens the file picker")
		app.file_dialog.hide()
	app.queue_free()
	await process_frame
	print("COMPACT DESKTOP TEST COMPLETE; failures: ", failed)
	quit(0 if failed == 0 else 1)
