extends RefCounted

const PATH = "user://layout.cfg"
const EDGES = ["Left", "Right", "Top", "Bottom"]
const MIN_PREVIEW = 244
const MAX_PREVIEW = 480
const DEFAULTS = {"dock": 0, "icons": true, "preview": 292}

static func load_layout() -> Dictionary:
	var config = ConfigFile.new()
	if config.load(PATH) != OK:
		return DEFAULTS.duplicate()
	var dock = config.get_value("layout", "dock", DEFAULTS["dock"])
	var icons = config.get_value("layout", "icons", DEFAULTS["icons"])
	var width = config.get_value("layout", "preview", DEFAULTS["preview"])
	return {
		"dock": clampi(dock, 0, EDGES.size() - 1) if dock is int else DEFAULTS["dock"],
		"icons": icons if icons is bool else DEFAULTS["icons"],
		"preview": clampi(width, MIN_PREVIEW, MAX_PREVIEW) if width is int else DEFAULTS["preview"]
	}

static func save_layout(layout: Dictionary) -> Error:
	var config = ConfigFile.new()
	for key in DEFAULTS:
		config.set_value("layout", key, layout.get(key, DEFAULTS[key]))
	return config.save(PATH)
