extends RefCounted

const Palette = preload("res://scripts/palette.gd")
const CreatureShader = preload("res://shaders/creature_regions.gdshader")

static func build(creature: Dictionary, paths: Array, minimum: Vector2, high_quality: bool) -> TextureRect:
	var view = TextureRect.new()
	view.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	view.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	view.custom_minimum_size = minimum
	set_pose(view, creature, paths, high_quality)
	return view

static func set_pose(view: TextureRect, creature: Dictionary, paths: Array, high_quality: bool) -> void:
	view.material = null
	view.texture = null
	if paths.is_empty():
		return
	var base = load(paths[0]) as Texture2D
	if base == null:
		return
	view.texture = base
	if paths.size() < 2:
		return
	var mask = load(paths[1]) as Texture2D
	if mask == null or base.get_size() != mask.get_size():
		return
	var material = ShaderMaterial.new()
	material.shader = CreatureShader
	material.set_shader_parameter("region_mask", mask)
	material.set_shader_parameter("image_source", base)
	material.set_shader_parameter("high_quality_preview", high_quality)
	material.set_shader_parameter("detail_sharpen", 0.22 if high_quality else 0.0)
	var regions: Array = creature.get("regions", [])
	var names = creature.get("region_names", null)
	for i in range(6):
		var region: Dictionary = regions[i] if i < regions.size() and typeof(regions[i]) == TYPE_DICTIONARY else {}
		var raw: Array = region.get("raw", [])
		var unused = typeof(names) == TYPE_ARRAY and names.size() == 6 and names[i] == null
		var enabled = not unused and raw.size() >= 3 and str(region.get("state", "unknown")) != "empty"
		material.set_shader_parameter("use_%s" % i, enabled)
		if enabled:
			material.set_shader_parameter("region_%s" % i, Palette.display_color(raw))
	view.material = material

static func pose_selector(poses: Array, selected: int, change: Callable) -> OptionButton:
	var picker = OptionButton.new()
	for pose in poses:
		picker.add_item(pose["label"])
	picker.select(clampi(selected, 0, poses.size() - 1))
	picker.item_selected.connect(change)
	return picker
