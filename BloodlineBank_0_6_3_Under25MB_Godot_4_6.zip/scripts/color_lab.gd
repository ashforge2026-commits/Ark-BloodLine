extends RefCounted

# Each design uses the same six-slot structure as imported creatures.
const DEFAULT_COLOR = 233
const MAX_HISTORY = 20

var palette
var library: Dictionary
var species_name: String
var species_key: String
var region_names: Array
var active_regions: Array = []
var default_color = DEFAULT_COLOR
var ids: Array = []
var locked: Array = []
var history: Array = []
var rng := RandomNumberGenerator.new()

func _init(palette_ref, library_ref: Dictionary, subject: Dictionary) -> void:
	palette = palette_ref
	library = library_ref
	species_name = subject["name"]
	species_key = subject["key"]
	var names = subject["regions"]
	region_names = names.duplicate() if typeof(names) == TYPE_ARRAY and names.size() == 6 else [null, null, null, null, null, null]
	rng.randomize()
	if palette.get_color(DEFAULT_COLOR).is_empty() and not palette.entries.is_empty():
		default_color = int(palette.entries[0].get("id", -1))
	for i in range(6):
		var active = region_names[i] != null
		ids.append(default_color if active else -1)
		locked.append(not active)
		if active:
			active_regions.append(i)

func _record_previous() -> void:
	history.append(ids.duplicate())
	if history.size() > MAX_HISTORY:
		history.pop_front()

func set_color(slot: int, id: int) -> bool:
	if not active_regions.has(slot) or palette.get_color(id).is_empty() or ids[slot] == id:
		return false
	_record_previous()
	ids[slot] = id
	return true

func toggle_lock(slot: int) -> void:
	if active_regions.has(slot):
		locked[slot] = not bool(locked[slot])

func apply_colors(colors: Array) -> bool:
	if colors.size() != 6:
		return false
	var next = ids.duplicate()
	for i in active_regions:
		var parsed = colors[i]
		if typeof(parsed) != TYPE_INT and typeof(parsed) != TYPE_FLOAT:
			return false
		var id = int(parsed)
		if palette.get_color(id).is_empty():
			return false
		next[i] = id
	if next == ids:
		return false
	_record_previous()
	ids = next
	return true

func from_creature(creature: Dictionary) -> bool:
	if str(creature.get("species_key", "")) != species_key:
		return false
	var next = ids.duplicate()
	var seen = 0
	var regions: Array = creature.get("regions", [])
	for i in active_regions:
		if i >= regions.size() or typeof(regions[i]) != TYPE_DICTIONARY:
			continue
		var item: Dictionary = regions[i]
		if not (str(item.get("state", "")) in ["explicit", "matched"]):
			continue
		var id_value = item.get("id", null)
		if id_value == null or palette.get_color(int(id_value)).is_empty():
			continue
		next[i] = int(id_value)
		seen += 1
	if seen == 0 or next == ids:
		return false
	_record_previous()
	ids = next
	return true

func undo() -> bool:
	if history.is_empty():
		return false
	ids = history.pop_back()
	return true

func reset() -> bool:
	var next = ids.duplicate()
	for slot in active_regions:
		next[slot] = default_color
	return apply_colors(next)

func owned_ids(slot: int) -> Array:
	var found: Dictionary = {}
	if not active_regions.has(slot):
		return []
	for creature in library.get("creatures", []):
		if typeof(creature) != TYPE_DICTIONARY or str(creature.get("species_key", "")) != species_key:
			continue
		var names = creature.get("region_names", null)
		if typeof(names) != TYPE_ARRAY or names.size() != 6 or names[slot] == null:
			continue
		var regions: Array = creature.get("regions", [])
		if slot >= regions.size() or typeof(regions[slot]) != TYPE_DICTIONARY:
			continue
		var region: Dictionary = regions[slot]
		if not (str(region.get("state", "")) in ["explicit", "matched"]) or region.get("id", null) == null:
			continue
		var id = int(region["id"])
		if not palette.get_color(id).is_empty():
			found[id] = true
	var result: Array = found.keys()
	result.sort()
	return result

func _all_ids() -> Array:
	var result: Array = []
	for entry in palette.entries:
		var id = int(entry.get("id", -1))
		if id >= 0:
			result.append(id)
	return result

func randomize_colors(mode: String) -> Dictionary:
	if not (mode in ["all", "owned", "solid"]):
		return {"changed": false, "message": "Invalid randomizer mode."}
	var next = ids.duplicate()
	var all_colors = _all_ids()
	if all_colors.is_empty():
		return {"changed": false, "message": "No palette colors available."}
	var missing: Array = []
	var solid_id = int(all_colors[rng.randi_range(0, all_colors.size() - 1)])
	for slot in active_regions:
		if bool(locked[slot]):
			continue
		var candidates = owned_ids(slot) if mode == "owned" else all_colors
		if candidates.is_empty():
			missing.append("R%s" % slot)
			continue
		var id = solid_id if mode == "solid" else int(candidates[rng.randi_range(0, candidates.size() - 1)])
		if mode != "solid" and candidates.size() > 1 and id == int(next[slot]):
			var index = candidates.find(id)
			id = int(candidates[(index + 1) % candidates.size()])
		next[slot] = id
	var changed = next != ids
	if changed:
		_record_previous()
		ids = next
	var message = "Generated a new design." if changed else "No region changed. Unlock a region or choose another mode."
	if not missing.is_empty():
		message += " No owned colors in " + ", ".join(missing) + "."
	return {"changed": changed, "message": message}

func preview_creature() -> Dictionary:
	var regions: Array = []
	for i in range(6):
		regions.append(palette.from_id(int(ids[i])) if active_regions.has(i) else {"state": "empty", "id": null, "raw": []})
	return {"verified_species": true, "species_name": species_name, "species_key": species_key, "regions": regions, "region_names": region_names.duplicate()}

func label_for(slot: int) -> String:
	var id = int(ids[slot])
	var entry: Dictionary = palette.get_color(id)
	return "#%s · %s" % [id, str(entry.get("name", "Unknown"))]
