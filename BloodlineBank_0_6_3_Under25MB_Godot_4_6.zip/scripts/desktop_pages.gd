extends VBoxContainer

# Keeps the original row controls and their signals. Large collections can
# be advanced a screen at a time without exposing a scrollbar.
var viewport: ScrollContainer
var previous: Button
var next: Button
var indicator: Label

func install(scroll: ScrollContainer, back: Button, forward: Button, label: Label) -> void:
	viewport = scroll
	previous = back
	next = forward
	indicator = label
	var host = scroll.get_parent()
	var index = scroll.get_index()
	var minimum_height = scroll.custom_minimum_size.y
	size_flags_horizontal = scroll.size_flags_horizontal
	size_flags_vertical = scroll.size_flags_vertical
	custom_minimum_size.y = minimum_height + 25 if minimum_height > 0 else 0
	host.remove_child(scroll)
	host.add_child(self)
	host.move_child(self, index)
	add_theme_constant_override("separation", 2)
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_NEVER
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(scroll)
	var footer = HBoxContainer.new()
	footer.custom_minimum_size.y = 25
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	add_child(footer)
	for child in [label, back, forward]:
		footer.add_child(child)
	back.pressed.connect(_advance.bind(-1))
	forward.pressed.connect(_advance.bind(1))
	var bar = scroll.get_v_scroll_bar()
	bar.changed.connect(_refresh)
	bar.value_changed.connect(func(_value): _refresh())
	scroll.resized.connect(_refresh)
	_refresh.call_deferred()

func _step() -> int:
	return maxi(1, floori(viewport.get_v_scroll_bar().page) - 2)

func _advance(direction: int) -> void:
	viewport.scroll_vertical = viewport.scroll_vertical + direction * _step()

func _refresh() -> void:
	var bar = viewport.get_v_scroll_bar()
	var distance = maxf(0.0, bar.max_value - bar.page)
	var end = ceili(distance / float(_step()))
	var cursor = end if bar.value >= distance - 1.0 else floori(bar.value / float(_step()))
	previous.visible = end > 0
	next.visible = end > 0
	indicator.visible = end > 0
	previous.disabled = bar.value <= 0.0
	next.disabled = bar.value >= distance - 1.0
	indicator.text = "Page %s of %s" % [cursor + 1, end + 1]
