extends Control

# Lightweight Android touch shell. The desktop scene and its features are not
# modified: both shells reuse the same parser, storage, palette and lab logic.
const Palette = preload("res://scripts/palette.gd")
const Registry = preload("res://scripts/species_registry.gd")
const Parser = preload("res://scripts/ark_parser.gd")
const Importer = preload("res://scripts/import_service.gd")
const Storage = preload("res://scripts/storage.gd")
const Bingo = preload("res://scripts/bingo.gd")
const Goals = preload("res://scripts/color_goals.gd")
const Projects = preload("res://scripts/project_plans.gd")
const Partner = preload("res://scripts/partner_finder.gd")
const Lowest = preload("res://scripts/lowest_stats.gd")
const ColorTable = preload("res://scripts/color_table.gd")
const Appearance = preload("res://scripts/appearance.gd")
const MobileExports = preload("res://scripts/mobile_exports.gd")
const ArchiveExtract = preload("res://scripts/archive_extract.gd")
const LabUI = preload("res://scripts/color_lab_ui.gd")
const CreaturePreview = preload("res://scripts/creature_preview.gd")
const BG = Color("#071521")
const PANEL = Color("#0f2a39")
const EDGE = Color("#31556b")
const INK = Color("#edf7fa")
const DIM = Color("#a2b7c3")
const ACCENT = Color("#42d7f2")

var palette = Palette.new()
var registry = Registry.new()
var store = Storage.new()
var parser
var importer
var library: Dictionary = {}
var active_page = "library"
var selected_creature_id = ""
var lab_session: Dictionary = {}
var lab_widget
var color_species_keys: Dictionary = {}
var page_host: VBoxContainer
var nav_items: Dictionary = {}
var safe_frame: MarginContainer
var search_text = ""
var list_host: VBoxContainer
var search_input: LineEdit
var bingo_query = ""
var bingo_list: VBoxContainer
var bingo_rows: Array = []
var bingo_spec_key = ""
var bingo_filter = 0
var picker: FileDialog
var export_dialog: FileDialog
var backup_picker: FileDialog
var confirm_backup: ConfirmationDialog
var pending_backup: Dictionary = {}
var confirm_import: ConfirmationDialog
var pending_import: Dictionary = {}
var selected_archive = ""
var selected_archive_name = ""
var staged_document: FileAccess
var extraction_folder = MobileExports.DEFAULT_FOLDER
var extraction_status: Label
var folder_picker: FileDialog
var extraction_thread: Thread
var notice: AcceptDialog
var male_id = ""
var partner_color_id = -1
var low_key = ""
var low_mode = "points"

func _ready() -> void:
	parser = Parser.new(palette, registry)
	importer = Importer.new(parser)
	library = store.load_data()
	extraction_folder = MobileExports.load_folder()
	registry.recognize_saved_creatures(library.get("creatures", []))
	_build_shell()
	_show_page("library")
	if not store.last_warning.is_empty():
		_message("Library recovery", store.last_warning)

func _style(bg: Color = PANEL, edge: Color = EDGE) -> StyleBoxFlat:
	var s = StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = edge
	s.set_border_width_all(1)
	s.set_corner_radius_all(9)
	s.set_content_margin_all(8)
	return s

func _label(text: String, size: int = 16, color: Color = INK) -> Label:
	var l = Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l

func _button(text: String, focus: bool = false) -> Button:
	var b = Button.new()
	b.text = text
	b.custom_minimum_size.y = 52
	b.clip_text = true
	b.add_theme_font_size_override("font_size", 16)
	b.add_theme_color_override("font_color", INK)
	b.add_theme_stylebox_override("normal", _style(Color("#14506a") if focus else Color("#173747"), ACCENT if focus else EDGE))
	b.add_theme_stylebox_override("hover", _style(Color("#24667d"), ACCENT))
	b.add_theme_stylebox_override("pressed", _style(Color("#0a4b5e"), ACCENT))
	return b

func _field(hint: String) -> LineEdit:
	var l = LineEdit.new()
	l.placeholder_text = hint
	l.clear_button_enabled = true
	l.custom_minimum_size.y = 48
	l.add_theme_font_size_override("font_size", 16)
	return l

func _panel() -> PanelContainer:
	var p = PanelContainer.new()
	p.add_theme_stylebox_override("panel", _style())
	p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return p

func _clear(node: Node) -> void:
	for child in node.get_children():
		node.remove_child(child)
		child.queue_free()

func _build_shell() -> void:
	var bg = ColorRect.new()
	bg.color = BG
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)
	# Insets are separate from the page content, and keep navigation away
	# from notches, rounded corners, and Android's gesture area.
	safe_frame = MarginContainer.new()
	safe_frame.name = "SafeArea"
	safe_frame.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(safe_frame)
	var frame = VBoxContainer.new()
	frame.name = "Frame"
	frame.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	frame.size_flags_vertical = Control.SIZE_EXPAND_FILL
	frame.add_theme_constant_override("separation", 6)
	safe_frame.add_child(frame)
	var header = HBoxContainer.new()
	header.add_theme_constant_override("separation", 8)
	frame.add_child(header)
	var title = _label("BloodlineBank", 21)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.clip_text = true
	header.add_child(title)
	var imp = _button("Import")
	imp.custom_minimum_size.x = 84
	imp.pressed.connect(_choose_import)
	header.add_child(imp)
	page_host = VBoxContainer.new()
	page_host.name = "Pages"
	page_host.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	page_host.size_flags_vertical = Control.SIZE_EXPAND_FILL
	page_host.add_theme_constant_override("separation", 8)
	frame.add_child(page_host)
	# Five always-visible touch targets replace eight hidden scrolling tabs.
	var footer = HBoxContainer.new()
	footer.name = "BottomNavigation"
	footer.add_theme_constant_override("separation", 4)
	frame.add_child(footer)
	for item in [["library", "Otters"], ["lab", "Lab"], ["bingo", "Bingo"], ["partner", "Breed"], ["more", "More"]]:
		var key = str(item[0])
		var b = _button(str(item[1]), key == "library")
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.size_flags_stretch_ratio = 1.0
		b.custom_minimum_size.x = 0
		b.custom_minimum_size.y = 56
		b.add_theme_font_size_override("font_size", 14)
		b.pressed.connect(func(): _show_page(key))
		footer.add_child(b)
		nav_items[key] = b
	picker = FileDialog.new()
	picker.access = FileDialog.ACCESS_FILESYSTEM
	picker.file_mode = FileDialog.FILE_MODE_OPEN_FILE
	picker.use_native_dialog = OS.get_name() == "Android"
	if not picker.use_native_dialog:
		picker.filters = PackedStringArray(["*.ini ; Dino export", "*.zip ; ZIP export"])
	picker.file_selected.connect(_import_file)
	add_child(picker)
	folder_picker = FileDialog.new()
	folder_picker.title = "Mobile Dino Export Location"
	folder_picker.access = FileDialog.ACCESS_FILESYSTEM
	folder_picker.file_mode = FileDialog.FILE_MODE_OPEN_DIR
	folder_picker.use_native_dialog = OS.get_name() == "Android"
	folder_picker.dir_selected.connect(_set_extraction_folder)
	add_child(folder_picker)
	confirm_import = ConfirmationDialog.new()
	confirm_import.title = "Review import"
	confirm_import.ok_button_text = "Import new and updated"
	confirm_import.confirmed.connect(_apply_import)
	confirm_import.canceled.connect(_clear_import)
	confirm_import.dialog_autowrap = true
	add_child(confirm_import)
	notice = AcceptDialog.new()
	notice.dialog_autowrap = true
	add_child(notice)
	export_dialog = FileDialog.new()
	export_dialog.access = FileDialog.ACCESS_FILESYSTEM
	export_dialog.file_mode = FileDialog.FILE_MODE_SAVE_FILE
	export_dialog.filters = PackedStringArray(["*.json ; BloodlineBank backup"])
	export_dialog.file_selected.connect(_export_data)
	add_child(export_dialog)
	backup_picker = FileDialog.new()
	backup_picker.access = FileDialog.ACCESS_FILESYSTEM
	backup_picker.file_mode = FileDialog.FILE_MODE_OPEN_FILE
	backup_picker.filters = PackedStringArray(["*.json ; BloodlineBank backup"])
	backup_picker.file_selected.connect(_review_backup)
	add_child(backup_picker)
	confirm_backup = ConfirmationDialog.new()
	confirm_backup.title = "Restore library backup"
	confirm_backup.ok_button_text = "Replace mobile library"
	confirm_backup.confirmed.connect(_apply_backup)
	add_child(confirm_backup)
	resized.connect(_update_phone_insets)
	_update_phone_insets()

func _update_phone_insets() -> void:
	if not is_instance_valid(safe_frame):
		return
	var margins = [10, 10, 10, 10] # Left, top, right, bottom.
	if OS.get_name() == "Android":
		var safe = DisplayServer.get_display_safe_area()
		var screen = DisplayServer.screen_get_size()
		var window_px = DisplayServer.window_get_size()
		if safe.size.x > 0 and safe.size.y > 0 and window_px.x > 0 and screen.x > 0:
			var logical = get_viewport_rect().size
			var pixel_to_unit = logical.x / float(window_px.x)
			margins[0] += clampi(ceili(maxf(0.0, float(safe.position.x)) * pixel_to_unit), 0, 52)
			margins[1] += clampi(ceili(maxf(0.0, float(safe.position.y)) * pixel_to_unit), 0, 52)
			margins[2] += clampi(ceili(maxf(0.0, float(screen.x - safe.end.x)) * pixel_to_unit), 0, 52)
			margins[3] += clampi(ceili(maxf(0.0, float(screen.y - safe.end.y)) * pixel_to_unit), 0, 52)
	for i in range(4):
		var constant = ["margin_left", "margin_top", "margin_right", "margin_bottom"][i]
		if safe_frame.get_theme_constant(constant) != margins[i]:
			safe_frame.add_theme_constant_override(constant, margins[i])

func _show_page(page: String, creature: Dictionary = {}) -> void:
	active_page = page
	selected_creature_id = ""
	_clear(page_host)
	var nav_page = page if nav_items.has(page) else "more"
	for key in nav_items:
		var item: Button = nav_items[key]
		item.add_theme_stylebox_override("normal", _style(Color("#14506a") if key == nav_page else Color("#173747"), ACCENT if key == nav_page else EDGE))
	match page:
		"library":
			_show_library()
		"lab":
			_show_lab(creature)
		"bingo":
			_show_bingo()
		"table":
			_show_table()
		"projects":
			_show_projects()
		"partner":
			_show_partner()
		"lowest":
			_show_lowest()
		"tools":
			_show_tools()
		"more":
			_show_more()

func _scroll_page() -> VBoxContainer:
	var scroll = ScrollContainer.new()
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	page_host.add_child(scroll)
	var content = VBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 8)
	scroll.add_child(content)
	return content

func _creature_by_id(local_id: String) -> Dictionary:
	for creature in library.get("creatures", []):
		if str(creature.get("local_id", "")) == local_id:
			return creature
	return {}

func _creature_label(creature: Dictionary) -> String:
	return "%s  ·  Lvl %s  ·  %s" % [str(creature.get("name", "Unnamed")), str(creature.get("level", "—")), str(creature.get("sex", "?"))]

func _preview(creature: Dictionary, pixels: int = 220) -> TextureRect:
	return CreaturePreview.build(creature, registry.images_for(creature), Vector2(pixels, pixels), pixels >= 200)

func _swatch(id: int, compact: bool = false) -> Control:
	var box = ColorRect.new()
	box.color = Palette.display_color(palette.get_color(id).get("rgba", [])) if not palette.get_color(id).is_empty() else Color("#384957")
	box.custom_minimum_size = Vector2(30, 30) if compact else Vector2(42, 42)
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return box

func _show_library() -> void:
	page_host.add_child(_label("Creature Library", 23))
	search_input = _field("Search name, level or species")
	search_input.text = search_text
	search_input.text_changed.connect(func(v): search_text = v; _render_library())
	page_host.add_child(search_input)
	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	page_host.add_child(scroll)
	list_host = VBoxContainer.new()
	list_host.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list_host.add_theme_constant_override("separation", 7)
	scroll.add_child(list_host)
	_render_library()

func _render_library() -> void:
	if not is_instance_valid(list_host):
		return
	_clear(list_host)
	var count = 0
	for creature in library.get("creatures", []):
		if typeof(creature) != TYPE_DICTIONARY:
			continue
		var name = (_creature_label(creature) + " " + str(creature.get("species_name", ""))).to_lower()
		if not search_text.strip_edges().is_empty() and not name.contains(search_text.strip_edges().to_lower()):
			continue
		count += 1
		var id = str(creature.get("local_id", ""))
		var card = _button(_creature_label(creature))
		card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		card.alignment = HORIZONTAL_ALIGNMENT_LEFT
		card.pressed.connect(func(): _show_creature(id))
		list_host.add_child(card)
	if count == 0:
		list_host.add_child(_label("No matching otters yet. Use Import to load an ARK INI/ZIP.", 16, DIM))

func _show_creature(local_id: String) -> void:
	var creature = _creature_by_id(local_id)
	if creature.is_empty():
		return
	selected_creature_id = local_id
	_clear(page_host)
	var content = _scroll_page()
	var back = _button("‹ Back to library")
	back.pressed.connect(func(): _show_page("library"))
	content.add_child(back)
	content.add_child(_label(str(creature.get("species_name", "Creature")), 23))
	content.add_child(_label(_creature_label(creature), 15, DIM))
	var center = CenterContainer.new()
	var picture = _preview(creature)
	center.add_child(picture)
	content.add_child(center)
	var poses: Array = registry.poses_for(creature)
	if poses.size() > 1:
		var pose = CreaturePreview.pose_selector(poses, registry.default_pose(creature), func(index: int):
			CreaturePreview.set_pose(picture, creature, registry.images_for(creature, index), true)
		)
		pose.name = "LibraryCreaturePose"
		pose.custom_minimum_size.y = 44
		content.add_child(pose)
	if picture.texture == null:
		content.add_child(_label("No matching preview image included yet.", 14, DIM))
	content.add_child(_label("Color regions", 19))
	var regions: Array = creature.get("regions", [])
	var names = creature.get("region_names", null)
	for i in range(6):
		if typeof(names) == TYPE_ARRAY and names.size() == 6 and names[i] == null:
			continue
		var region: Dictionary = regions[i] if i < regions.size() and typeof(regions[i]) == TYPE_DICTIONARY else {}
		var id_val = ColorTable.confirmed_id(creature, i)
		var row = HBoxContainer.new()
		row.add_child(_swatch(int(id_val) if id_val != null else -1))
		var color_name = str(palette.get_color(int(id_val)).get("name", "Unknown")) if id_val != null else "Unknown"
		row.add_child(_label("R%s: %s  %s" % [i, str(id_val) if id_val != null else "?", color_name], 15))
		content.add_child(row)
	if registry.can_use_lab(creature):
		var try_colors = _button("Try these colors in Color Lab", true)
		try_colors.pressed.connect(_show_page.bind("lab", creature))
		content.add_child(try_colors)
	content.add_child(_label("Stats (exported values)", 18))
	for item in [["Health", "health"], ["Stamina", "stamina"], ["Weight", "weight"], ["Melee", "melee damage"], ["Food", "food"], ["Oxygen", "oxygen"]]:
		var val = creature.get("stats", {}).get(item[1], null)
		content.add_child(_label("%s: %s" % [item[0], str(val) if val != null else "?"], 15, DIM))

func _show_lab(creature: Dictionary) -> void:
	lab_widget = LabUI.new()
	lab_widget.configure(palette, registry, library, lab_session, true, creature, Appearance.load_colors())
	page_host.add_child(lab_widget)

func _add_color_species_selector(host: Control) -> String:
	var entries = Lowest.species(library.get("creatures", []))
	if entries.is_empty():
		return ""
	var page = active_page
	var preferred = color_species_keys.get(page, "")
	var selected = entries.find_custom(func(entry): return entry["key"] == preferred)
	if selected < 0:
		selected = maxi(0, entries.find_custom(func(entry): return entry["name"] == "X-Otter"))
	var selector = OptionButton.new()
	selector.name = "MobileColorSpecies"
	selector.clip_text = true
	selector.custom_minimum_size.y = 48
	for entry in entries:
		selector.add_item(str(entry["name"]))
	selector.select(selected)
	selector.item_selected.connect(func(index: int):
		color_species_keys[page] = entries[index]["key"]
		_show_page(page)
	)
	host.add_child(selector)
	return str(entries[selected]["key"])

func _show_bingo() -> void:
	page_host.add_child(_label("Color Bingo", 23))
	bingo_spec_key = _add_color_species_selector(page_host)
	if bingo_spec_key.is_empty():
		page_host.add_child(_label("Import a creature to begin your color collection.", 16, DIM))
		return
	var specimen: Dictionary = {}
	for c in library.get("creatures", []):
		if str(c.get("species_key", "")) == bingo_spec_key:
			specimen = c
			break
	bingo_rows = Bingo.build(library.get("creatures", []), bingo_spec_key, specimen.get("region_names", null), palette)
	var search = _field("Search color name or ID")
	search.text = bingo_query
	search.text_changed.connect(func(t): bingo_query = t; _render_bingo())
	page_host.add_child(search)
	var options = OptionButton.new()
	options.custom_minimum_size.y = 48
	for item in ["All 255 IDs", "Bingo complete", "One region missing"]:
		options.add_item(item)
	options.select(bingo_filter)
	options.item_selected.connect(func(idx: int): bingo_filter = idx; _render_bingo())
	page_host.add_child(options)
	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	page_host.add_child(scroll)
	bingo_list = VBoxContainer.new()
	bingo_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bingo_list.add_theme_constant_override("separation", 5)
	scroll.add_child(bingo_list)
	_render_bingo()

func _render_bingo() -> void:
	if not is_instance_valid(bingo_list):
		return
	_clear(bingo_list)
	var filtered = Bingo.filtered(bingo_rows, bingo_query, bingo_filter, 0)
	for entry in filtered:
		var id = int(entry["id"])
		var total = int(entry.get("total", 0))
		var found = int(entry.get("found", 0))
		var label = "#%s  %s  ·  %s/%s" % [id, str(entry.get("name", "")), found, total]
		if str(entry.get("status", "")) == "bingo":
			label += "  ★"
		var button = _button(label)
		button.alignment = HORIZONTAL_ALIGNMENT_LEFT
		button.pressed.connect(func(): _bingo_detail(id))
		bingo_list.add_child(button)

func _bingo_detail(id: int) -> void:
	var creatures: Array = library.get("creatures", [])
	var specimen: Dictionary = {}
	for c in creatures:
		if str(c.get("species_key", "")) == bingo_spec_key:
			specimen = c
			break
	var index = Goals.build_index(creatures, bingo_spec_key, specimen.get("region_names", null))
	var result = Goals.calculate_indexed(index, id)
	var body = "Color #%s · %s\n\n" % [id, str(palette.get_color(id).get("name", "Unknown"))]
	for region in result.get("regions", []):
		if region.get("status") == "unused":
			continue
		body += "R%s  %s: %s\n" % [region.get("region", "?"), region.get("name", ""), region.get("status", "?")]
		for carrier in region.get("carriers", []).slice(0, 3):
			body += "  • " + str(carrier) + "\n"
	_message("Bingo color details", body)

func _show_table() -> void:
	page_host.add_child(_label("Color Table", 23))
	var species_key = _add_color_species_selector(page_host)
	var content = _scroll_page()
	if species_key.is_empty():
		content.add_child(_label("Import a creature to view its colors.", 16, DIM))
		return
	for creature in library.get("creatures", []):
		if str(creature.get("species_key", "")) != species_key:
			continue
		var row = VBoxContainer.new()
		var id = str(creature.get("local_id", ""))
		var label = _button(_creature_label(creature))
		label.pressed.connect(func(): _show_creature(id))
		row.add_child(label)
		var chips = HFlowContainer.new()
		for i in range(6):
			var color_id = ColorTable.confirmed_id(creature, i)
			if color_id == null:
				continue
			chips.add_child(_swatch(int(color_id), true))
			chips.add_child(_label(str(color_id), 12, DIM))
		row.add_child(chips)
		content.add_child(row)

func _show_projects() -> void:
	page_host.add_child(_label("Breeding Projects · View", 23))
	var content = _scroll_page()
	var projects: Dictionary = Projects.get_projects(library)
	if projects.is_empty():
		content.add_child(_label("No saved projects yet. Create projects on PC for now.", 16, DIM))
		return
	for project in projects.values():
		if typeof(project) != TYPE_DICTIONARY:
			continue
		content.add_child(_label(str(project.get("name", "Project")), 20, ACCENT))
		for group in Projects.lists_of(project):
			var group_id = str(group.get("id", "main"))
			content.add_child(_label(str(group.get("name", "Main List")), 17))
			for member in Projects.members_in_list(project, group_id):
				var local_id = str(member.get("id", ""))
				var creature = _creature_by_id(local_id)
				if creature.is_empty():
					continue
				var button = _button(_creature_label(creature))
				button.alignment = HORIZONTAL_ALIGNMENT_LEFT
				button.pressed.connect(func(): _show_creature(local_id))
				content.add_child(button)
	content.add_child(_label("Project editing and drag reordering remain on desktop for this mobile beta.", 14, DIM))

func _show_partner() -> void:
	page_host.add_child(_label("Partner Finder", 23))
	var content = _scroll_page()
	var species_key = _add_color_species_selector(content)
	var creatures: Array = library.get("creatures", [])
	var males = Partner.male_options(creatures.filter(func(creature): return creature.get("species_key", "") == species_key))
	if males.is_empty():
		content.add_child(_label("Import a male with confirmed colors for this species.", 16, DIM))
		return
	var select = OptionButton.new()
	select.custom_minimum_size.y = 49
	content.add_child(_label("Select male", 17))
	content.add_child(select)
	for male in males:
		select.add_item(_creature_label(male))
	var current = 0
	for i in range(males.size()):
		if str(males[i].get("local_id", "")) == male_id:
			current = i
	select.select(current)
	male_id = str(males[current].get("local_id", ""))
	var colors = Partner.colors_for_male(males[current])
	var color_select = OptionButton.new()
	color_select.custom_minimum_size.y = 49
	content.add_child(_label("Select target male color", 17))
	content.add_child(color_select)
	for item in colors:
		color_select.add_item("#%s ×%s" % [item["id"], item["count"]])
	var selected_index = 0
	for i in range(colors.size()):
		if int(colors[i]["id"]) == partner_color_id:
			selected_index = i
	color_select.select(selected_index)
	partner_color_id = int(colors[selected_index]["id"])
	var results = VBoxContainer.new()
	content.add_child(results)
	select.item_selected.connect(func(idx: int):
		male_id = str(males[idx].get("local_id", ""))
		partner_color_id = -1
		_show_page("partner")
	)
	color_select.item_selected.connect(func(idx: int):
		partner_color_id = int(colors[idx]["id"])
		_render_partner(males[current], results)
	)
	_render_partner(males[current], results)

func _render_partner(male: Dictionary, host: VBoxContainer) -> void:
	_clear(host)
	var ranked: Dictionary = Partner.rank(library.get("creatures", []), male, partner_color_id)
	for entry in ranked.get("results", []):
		var female: Dictionary = entry.get("creature", {})
		if female.is_empty():
			continue
		var id = str(female.get("local_id", ""))
		var button = _button(_creature_label(female))
		button.pressed.connect(func(): _show_creature(id))
		host.add_child(button)
	if host.get_child_count() == 0:
		host.add_child(_label("No matching female partners found.", 15, DIM))

func _show_lowest() -> void:
	page_host.add_child(_label("Lowest Stats Tracker", 23))
	var content = _scroll_page()
	var species_list = Lowest.species(library.get("creatures", []))
	if species_list.is_empty():
		content.add_child(_label("Import a creature first.", 16, DIM))
		return
	var species_pick = OptionButton.new()
	species_pick.custom_minimum_size.y = 49
	content.add_child(_label("Species / variant", 16))
	content.add_child(species_pick)
	for entry in species_list:
		species_pick.add_item(str(entry.get("name", "Unknown")))
	var index = 0
	for i in range(species_list.size()):
		if str(species_list[i].get("key", "")) == low_key:
			index = i
	low_key = str(species_list[index]["key"])
	species_pick.select(index)
	species_pick.item_selected.connect(func(idx: int):
		low_key = str(species_list[idx]["key"])
		_show_page("lowest")
	)
	var mode = OptionButton.new()
	mode.custom_minimum_size.y = 49
	mode.add_item("Wild points (when exported)")
	mode.add_item("Displayed stat values")
	mode.select(0 if low_mode == "points" else 1)
	mode.item_selected.connect(func(idx: int):
		low_mode = "points" if idx == 0 else "values"
		_show_page("lowest")
	)
	content.add_child(mode)
	var result = Lowest.analyze(library.get("creatures", []), low_key, low_mode)
	for row in result.get("rows", []):
		var stat = row.get("stat", {})
		var value = Lowest.format_value(row.get("lowest", null), stat, low_mode)
		content.add_child(_label("%s  ·  %s" % [stat.get("label", "Stat"), value], 17, ACCENT))
		var carriers: Array = row.get("carriers", [])
		if carriers.is_empty():
			content.add_child(_label("No comparable value exported", 14, DIM))
		for carrier in carriers:
			var creature = carrier.get("creature", {})
			var id = str(creature.get("local_id", ""))
			var button = _button(_creature_label(creature))
			button.alignment = HORIZONTAL_ALIGNMENT_LEFT
			button.pressed.connect(func(): _show_creature(id))
			content.add_child(button)
	content.add_child(_label("Displayed values are not confirmed inherited points.", 14, DIM))

func _show_more() -> void:
	page_host.add_child(_label("More tools", 23))
	var content = _scroll_page()
	for entry in [["table", "Color Table", "View imported colors by otter"], ["projects", "Breeding Projects", "See your saved breeding groups"], ["lowest", "Lowest Stats", "Find lowest values by species"], ["tools", "Files & Backups", "Import, export, and restore data"]]:
		var key = str(entry[0])
		var button = _button(str(entry[1]))
		button.alignment = HORIZONTAL_ALIGNMENT_LEFT
		button.pressed.connect(func(): _show_page(key))
		content.add_child(button)
		content.add_child(_label(str(entry[2]), 14, DIM))

func _show_tools() -> void:
	page_host.add_child(_label("Data & Tools", 23))
	var content = _scroll_page()
	content.add_child(_label("Creatures: %s" % library.get("creatures", []).size(), 17))
	content.add_child(_label("Your library is stored locally. PC and Android saves do not sync automatically.", 15, DIM))
	var imp = _button("Import ARK .ini or .zip", true)
	imp.pressed.connect(_choose_import)
	content.add_child(imp)
	var location = _button("Mobile Dino Export Location")
	location.name = "MobileDinoExportLocation"
	location.pressed.connect(_choose_extraction_folder)
	content.add_child(location)
	extraction_status = _label("", 14, DIM)
	extraction_status.name = "MobileDinoExportPath"
	extraction_status.autowrap_mode = TextServer.AUTOWRAP_ARBITRARY
	content.add_child(extraction_status)
	_show_extraction_folder()
	var backup = _button("Export library backup (.json)")
	backup.pressed.connect(func(): export_dialog.popup_centered_ratio(0.92))
	content.add_child(backup)
	var restore = _button("Restore PC / phone backup (.json)")
	restore.pressed.connect(func(): backup_picker.popup_centered_ratio(0.92))
	content.add_child(restore)
	content.add_child(_label("Restore replaces the mobile library only after confirmation. It does not edit the PC file.", 14, DIM))

func _show_extraction_folder() -> void:
	if active_page == "tools" and is_instance_valid(extraction_status):
		extraction_status.text = "ZIP extraction folder\n" + MobileExports.describe(extraction_folder)

func _choose_import() -> void:
	if extraction_thread != null:
		_message("Extraction in progress", "Wait for the current ZIP to finish.")
		return
	picker.popup_centered_ratio(0.92)

func _choose_extraction_folder() -> void:
	if extraction_thread != null:
		_message("Extraction in progress", "Wait for the current ZIP to finish.")
		return
	if not folder_picker.use_native_dialog and DirAccess.dir_exists_absolute(extraction_folder):
		folder_picker.current_dir = ProjectSettings.globalize_path(extraction_folder)
	folder_picker.popup_centered_ratio(0.92)

func _set_extraction_folder(path: String) -> void:
	var error = MobileExports.save_folder(path)
	if error != OK:
		_message("Folder could not be saved", "Select a folder that BloodlineBank can access.")
		return
	extraction_folder = path
	_show_extraction_folder()

func _clear_import() -> void:
	pending_import = {}
	selected_archive = ""
	selected_archive_name = ""
	staged_document = null

func _import_file(path: String) -> void:
	if extraction_thread != null:
		return
	_clear_import()
	var source_name = path.get_file()
	if path.begins_with("content://"):
		var staged = MobileExports.stage_document(path)
		if staged.has("error"):
			_message("Cannot read file", staged["error"])
			return
		staged_document = staged["file"]
		path = staged["path"]
		source_name = staged["name"]
	var result = importer.prepare(path, library.get("creatures", []))
	if not result.get("ok", false):
		_clear_import()
		_message("Cannot read file", str(result.get("error", "Unknown error")))
		return
	pending_import = result
	var count: Dictionary = result.get("counts", {})
	var changes = int(count.get("new", 0)) + int(count.get("update", 0))
	if path.get_extension().to_lower() == "zip":
		selected_archive = path
		selected_archive_name = source_name
	elif changes == 0:
		_clear_import()
		_message("Import review", "No new or updated records. Conflicts: %s. Invalid entries: %s." % [count.get("conflict", 0), result.get("errors", []).size()])
		return
	var review = "%s\nNew: %s  ·  Updates: %s\nUnchanged: %s  ·  Conflicts: %s\nInvalid entries: %s" % [source_name, count.get("new", 0), count.get("update", 0), count.get("unchanged", 0), count.get("conflict", 0), result.get("errors", []).size()]
	if not selected_archive.is_empty():
		review += "\n\nExtract to " + MobileExports.describe(extraction_folder)
	confirm_import.ok_button_text = "Import" if selected_archive.is_empty() else ("Extract ZIP" if changes == 0 else "Import & extract")
	confirm_import.dialog_text = review
	confirm_import.popup_centered(Vector2i(_dialog_width(), 0))

func _apply_import() -> void:
	if extraction_thread != null or pending_import.is_empty():
		return
	var counts: Dictionary = pending_import.get("counts", {})
	var changes = int(counts.get("new", 0)) + int(counts.get("update", 0))
	if changes > 0:
		var next: Dictionary = importer.apply_plan(pending_import, library)
		var result: Dictionary = store.save_data(next)
		if not result.get("ok", false):
			_clear_import()
			_message("Import not saved", str(result.get("error", "Unknown error")))
			return
		library = next
		_show_page("library")
	if selected_archive.is_empty():
		_clear_import()
		_message("Import complete", "Your local creature library has been updated.")
		return
	extraction_thread = Thread.new()
	var code = extraction_thread.start(_extract_zip.bind(selected_archive, extraction_folder, selected_archive_name, changes))
	if code != OK:
		extraction_thread = null
		_clear_import()
		_message("Could not start extraction", "Choose the ZIP again to retry extraction.")

func _extract_zip(path: String, folder: String, filename: String, imported: int) -> void:
	if folder == MobileExports.DEFAULT_FOLDER and not DirAccess.dir_exists_absolute(folder):
		DirAccess.make_dir_recursive_absolute(folder)
	var result = ArchiveExtract.extract_archive(path, folder, filename)
	call_deferred("_finish_extraction", result, imported)

func _finish_extraction(result: Dictionary, imported: int) -> void:
	extraction_thread.wait_to_finish()
	extraction_thread = null
	_clear_import()
	var details = "%s creature records saved.\n%s files extracted. %s already present." % [imported, result.get("copied", 0), result.get("unchanged", 0)]
	if result.get("ok", false):
		details += "\n\n" + MobileExports.describe(result.get("output_folder", extraction_folder))
	else:
		details += "\n\n" + str(result.get("error", "Extraction failed.")).split("; ", true, 1)[0].left(220)
	_message("ZIP complete" if result.get("ok", false) else "ZIP extraction needs attention", details)

func _dialog_width() -> int:
	return roundi(get_viewport_rect().size.x * 0.88)

func _exit_tree() -> void:
	if extraction_thread != null:
		extraction_thread.wait_to_finish()

func _export_data(path: String) -> void:
	var file = FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		_message("Backup failed", "Cannot write to that folder. Try another location.")
		return
	file.store_string(JSON.stringify(library, "\t"))
	file.flush()
	file.close()
	_message("Backup created", "Exported your library to:\n" + path)

func _review_backup(path: String) -> void:
	var file = FileAccess.open(path, FileAccess.READ)
	if file == null or file.get_length() > 128 * 1024 * 1024:
		_message("Cannot open backup", "The file is inaccessible or larger than 128 MB.")
		return
	var parsed = JSON.parse_string(file.get_as_text())
	file.close()
	if typeof(parsed) != TYPE_DICTIONARY or typeof(parsed.get("creatures", null)) != TYPE_ARRAY or typeof(parsed.get("goals", null)) != TYPE_DICTIONARY or (parsed.has("projects") and typeof(parsed.get("projects")) != TYPE_DICTIONARY):
		_message("Invalid backup", "This is not a valid BloodlineBank JSON library.")
		return
	if parsed.get("read_only", false):
		_message("Recovery backup", "This backup was marked read-only. Restore it on PC first and export a fresh backup.")
		return
	pending_backup = parsed
	confirm_backup.dialog_text = "This will REPLACE the current phone library (%s creatures) with the selected backup (%s creatures), including saved projects and designs. Your PC data will not change. A previous mobile save is backed up by the storage system. Continue?" % [library.get("creatures", []).size(), parsed.get("creatures", []).size()]
	confirm_backup.popup_centered()

func _apply_backup() -> void:
	if pending_backup.is_empty():
		return
	var result = store.save_data(pending_backup)
	if not result.get("ok", false):
		_message("Restore failed", str(result.get("error", "Save error")))
		return
	library = pending_backup
	pending_backup = {}
	registry.recognize_saved_creatures(library.get("creatures", []))
	lab_session.clear()
	_show_page("library")
	_message("Backup restored", "Mobile library restored. Existing ARK files were not touched.")

func _message(title: String, message: String) -> void:
	notice.title = title
	notice.dialog_text = message
	notice.popup_centered(Vector2i(_dialog_width(), 0))
