extends Control

const PaletteScript = preload("res://scripts/palette.gd")
const RegistryScript = preload("res://scripts/species_registry.gd")
const ParserScript = preload("res://scripts/ark_parser.gd")
const ImportScript = preload("res://scripts/import_service.gd")
const StorageScript = preload("res://scripts/storage.gd")
const GoalScript = preload("res://scripts/color_goals.gd")
const BingoScript = preload("res://scripts/bingo.gd")
const PartnerScript = preload("res://scripts/partner_finder.gd")
const LowestStatsScript = preload("res://scripts/lowest_stats.gd")
const Appearance = preload("res://scripts/appearance.gd")
const DisplaySettings = preload("res://scripts/display_settings.gd")
const LayoutSettings = preload("res://scripts/layout_settings.gd")
const PreviewSplitter = preload("res://scripts/preview_splitter.gd")
const DesktopPages = preload("res://scripts/desktop_pages.gd")
const ColorLabUI = preload("res://scripts/color_lab_ui.gd")
const PARTNER_MARKS_KEY = "partner_used_females"
const ColorTableScript = preload("res://scripts/color_table.gd")
const ProjectPlans = preload("res://scripts/project_plans.gd")
const ProjectTableRowScript = preload("res://scripts/project_table_row.gd")
const ProjectRowHandleScript = preload("res://scripts/project_row_handle.gd")
const ProjectRowDragAreaScript = preload("res://scripts/project_row_drag_area.gd")
const ProjectListDropTargetScript = preload("res://scripts/project_list_drop_target.gd")
const FolderScanScript = preload("res://scripts/folder_scan.gd")
const ScanSettingsScript = preload("res://scripts/scan_settings.gd")
const ArchiveExtractScript = preload("res://scripts/archive_extract.gd")
const ZipGuardScript = preload("res://scripts/zip_guard.gd")
const CreaturePreview = preload("res://scripts/creature_preview.gd")
const SexSymbolScript = preload("res://scripts/sex_symbol.gd")

const BACKGROUND = Color("#071521")
const PANEL = Color("#0d2231")
const PANEL_LIGHT = Color("#142d3d")
const TEXT = Color("#eaf5fa")
const MUTED = Color("#9bb1bd")
const CYAN = Color("#35d5f4")
const RED = Color("#ff8f8f")
const GREEN = Color("#8ddf99")
const DESKTOP_ROW_HEIGHT = 34

enum LibrarySearchMode { NAME, COLOR_ID, LEVEL }
const AUTO_SYNC_SECONDS = 45.0
const LIBRARY_PREVIEW_MAX_SIZE = 260.0
const COLUMN_NAME = 126
const COLUMN_LEVEL = 34
const COLUMN_SEX = 28
const COLUMN_COLORS = 160
const COLUMN_HEALTH = 58
const COLUMN_MELEE = 62
const TABLE_CREATURE_WIDTH = 126
const TABLE_LEVEL_WIDTH = 34
const TABLE_SEX_WIDTH = 28
const TABLE_REGION_WIDTH = 34
const TABLE_CONTENT_WIDTH = TABLE_CREATURE_WIDTH + TABLE_LEVEL_WIDTH + TABLE_SEX_WIDTH + 6 * TABLE_REGION_WIDTH + 8 * 5 + 14

var palette = PaletteScript.new()
var registry = RegistryScript.new()
var parser
var importer
var storage = StorageScript.new()
var data: Dictionary = {}
var appearance = Appearance.DEFAULTS.duplicate()
var background_rect: ColorRect
var color_lab_session: Dictionary = {}
var color_lab
var selected_id = ""
var selected_page = "library"
var page_index = 0
var database_revision = 0
var pending_import: Dictionary = {}
var pending_revision = 0
var import_thread: Thread
var is_importing = false

var shell: BoxContainer
var workspace: HBoxContainer
var layout = LayoutSettings.DEFAULTS.duplicate()
var navigation_icons: Dictionary = {}
var preview_splitter: Control
var library_preview_open = true
var library_preview_button: Button
var page_preview_toggle: Button
var layout_text_toggle: CheckButton
var library_table_scroll: ScrollContainer
var library_rows_per_page = 12
var color_table_rows_per_page = 12
var detail_visibility: Dictionary = {}
var bingo_detail_tab = 0
var bingo_carrier_page = 0
var bingo_carrier_footer: HBoxContainer
var last_desktop_height = 0
var sidebar_panel: PanelContainer
var middle: VBoxContainer
var details: VBoxContainer
var nav_buttons: Dictionary = {}
var search_field: LineEdit
var library_species_key = ""
var library_species: OptionButton
var library_search_mode = LibrarySearchMode.NAME
var search_mode_picker: OptionButton
var search_region: OptionButton
var sort_field: OptionButton
var list_box: VBoxContainer
var page_label: Label
var previous_button: Button
var next_button: Button
var file_dialog: FileDialog
var message_dialog: AcceptDialog
var confirm_import: ConfirmationDialog
var confirm_delete: ConfirmationDialog
var goal_species: OptionButton
var goal_color: LineEdit
var goal_stat_1: OptionButton
var goal_stat_2: OptionButton
var goal_note: TextEdit
var goal_result: VBoxContainer
var goal_keys: Array = []
var goal_header_info: Label
var goal_preview_host: VBoxContainer
var bingo_species: OptionButton
var bingo_search: LineEdit
var bingo_order: OptionButton
var bingo_filter: OptionButton
var bingo_grid: HFlowContainer
var bingo_summary: Label
var bingo_keys: Array = []
var bingo_rows: Array = []
var bingo_color_id = 0
var bingo_detail_box: VBoxContainer
# Partner Finder matching is read-only; manual X marks live in saved metadata.
# IDs survive tab changes; result rows are recalculated.
var partner_male_id = ""
var partner_female_id = ""
var partner_target_color = -1
var partner_picker_visible = true
var partner_searched = false
var partner_search_query = ""
var partner_species_key = ""
var partner_search_mode = PartnerScript.SearchMode.COLOR_ID
var partner_results: Array = []
var partner_male_picker: VBoxContainer
var partner_selected_host: VBoxContainer
var partner_results_box: VBoxContainer
var partner_result_footer: HBoxContainer
var partner_result_page = 0
var partner_results_summary: Label
var partner_clear_marks_button: Button
var partner_details_host: VBoxContainer
var partner_color_select: OptionButton
var partner_picker_scroll: ScrollContainer
# Lowest Stats is a read-only comparison of creatures already imported.
var lowest_species_key = ""
var lowest_species_keys: Array = []
var lowest_mode = "" # Auto-select points when exported; otherwise display reference values.
var lowest_selected_stat = "health"
var lowest_analysis: Dictionary = {}
var lowest_rows_host: VBoxContainer
var lowest_details_host: VBoxContainer
var lowest_page = 0
var lowest_mode_selector: OptionButton
var project_id = ""
# Focus mode is UI-only: it must never modify creature data, saved projects, or notes.
var project_focus_expanded = false
var project_header_options: HBoxContainer
var project_expand_button: Button
var project_heading: Label
var project_color_table_button: Button
var project_query = ""
var project_species_key = ""
var project_sex_filter = "All"
var project_keys: Array = []
var project_species_keys: Array = []
var project_selector: OptionButton
var project_name_field: LineEdit
var project_species: OptionButton
var project_sex: OptionButton
var project_search: LineEdit
var project_picker: VBoxContainer
var project_picker_expanded = false
var project_picker_name = ""
var project_picker_level = ""
var project_picker_sex = "All"
var project_picker_count: Label
var project_rows_scroll: ScrollContainer
var project_table_rows: VBoxContainer
var project_notes_list: VBoxContainer
var project_note_input: LineEdit
var project_board_status: Label
var project_new_list_name: LineEdit
var project_add_list: OptionButton
var project_add_list_id: String = ProjectPlans.MAIN_LIST_ID
var confirm_project_list_delete: ConfirmationDialog
var pending_project_list_delete_id: String = ""
var pending_project_list_delete_project_id: String = ""
var confirm_project_delete: ConfirmationDialog
var pending_project_delete_id = ""
var color_table_query = ""
var color_table_filters: Array = ["", "", "", "", "", ""]
var color_table_species_key = ""
var color_table_sort_region = -1
var color_table_descending = false
var color_table_page = 0
var color_table_show_details = false
var color_table_species: OptionButton
var color_table_species_keys: Array = []
var color_table_search: LineEdit
var color_table_inputs: Array = []
var color_table_rows: VBoxContainer
var color_table_page_label: Label
var color_table_copy_button: Button
var color_table_previous: Button
var color_table_next: Button
var color_table_header_buttons: Array = []
var color_table_scroll: ScrollContainer
var color_table_header_scroll: ScrollContainer
var color_table_toggle_details: Button
var scan_settings = ScanSettingsScript.new()
var folder_scanner
var export_folder = ""
var scan_state: Dictionary = {"files": {}, "archives": {}}
var scan_pending: Array = []
var scan_issues: Array = []
var scan_block_reason = ""
var scan_summary = "No scan yet."
var scan_status_label: Label
enum SettingsTab { APPEARANCE, DISPLAY, FILES, LAYOUT }

var settings_tab = SettingsTab.APPEARANCE
var settings_files_box: VBoxContainer
var settings_scan_summary_label: Label
var window_mode = DisplaySettings.Mode.WINDOWED
var display_mode_picker: OptionButton
var display_mode_status: Label
var custom_window_size = Vector2i.ZERO
var window_size_status: Label
var auto_scan_timer: Timer
var folder_dialog: FileDialog
var library_folder_button: Button
var pending_import_path = ""

func _apply_mobile_screen_scale() -> void:
	var root_window = get_tree().root
	root_window.content_scale_mode = Window.CONTENT_SCALE_MODE_CANVAS_ITEMS
	root_window.content_scale_aspect = Window.CONTENT_SCALE_ASPECT_EXPAND
	var physical_size = DisplayServer.window_get_size()
	var landscape = physical_size.x > physical_size.y
	var wanted = Vector2i(820, 420) if landscape else Vector2i(420, 820)
	if root_window.content_scale_size != wanted:
		root_window.content_scale_size = wanted

func _ready() -> void:
	if OS.get_name() == "Android" or "--mobile-preview" in OS.get_cmdline_user_args():
		# Mobile gets a phone-sized layout, without changing the desktop project.
		# Swap the virtual design size on rotation instead of shrinking 1280x720.
		_apply_mobile_screen_scale()
		get_tree().root.size_changed.connect(_apply_mobile_screen_scale)
		var mobile = preload("res://mobile_main.tscn").instantiate()
		mobile.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		add_child(mobile)
		return
	parser = ParserScript.new(palette, registry)
	importer = ImportScript.new(parser)
	folder_scanner = FolderScanScript.new(parser)
	data = storage.load_data()
	appearance = Appearance.load_colors()
	layout = LayoutSettings.load_layout()
	window_mode = DisplaySettings.load_mode()
	custom_window_size = DisplaySettings.load_size()
	if FileAccess.file_exists(DisplaySettings.PATH):
		_apply_display_preferences()
	registry.recognize_saved_creatures(data.get("creatures", []))
	export_folder = scan_settings.load_folder()
	if export_folder == scan_settings.default_folder() and not DirAccess.dir_exists_absolute(export_folder):
		var create_error = DirAccess.make_dir_recursive_absolute(export_folder)
		if create_error != OK:
			scan_block_reason = "Could not create the default Exported Dino folder. Choose a folder in Settings."
	var loaded_state = scan_settings.load_state()
	if loaded_state.get("ok", false):
		scan_state = loaded_state["state"]
	else:
		scan_block_reason = str(loaded_state.get("error", "Scan state could not be loaded."))
	_build_shell()
	_show_library()
	resized.connect(_adjust_detail_width)
	# A low-frequency background scan adds new exports while BloodlineBank is open.
	# Test mode can disable it to keep deterministic regression tests.
	auto_scan_timer = Timer.new()
	auto_scan_timer.wait_time = AUTO_SYNC_SECONDS
	auto_scan_timer.one_shot = false
	auto_scan_timer.timeout.connect(_automatic_scan_tick)
	add_child(auto_scan_timer)
	if OS.get_environment("BLOODLINEBANK_DISABLE_AUTOSCAN") != "1" and scan_settings.load_auto_sync():
		auto_scan_timer.start()
	if not storage.last_warning.is_empty():
		_show_message("Library recovery", storage.last_warning)
	elif auto_scan_timer.is_stopped() == false:
		call_deferred("_start_scan", false)

func _style(background: Color, border: Color = Color.TRANSPARENT, radius: int = 4, tint_key: String = "panels") -> StyleBoxFlat:
	var box = StyleBoxFlat.new()
	box.bg_color = _surface_color(background, tint_key)
	box.border_color = _surface_color(border, tint_key)
	if border == CYAN:
		box.border_color = Appearance.accent(appearance)
	box.set_border_width_all(1 if border.a > 0.0 else 0)
	box.set_corner_radius_all(radius)
	box.content_margin_left = 9
	box.content_margin_right = 9
	box.content_margin_top = 5
	box.content_margin_bottom = 5
	return box

func _surface_color(color: Color, key: String) -> Color:
	if key.is_empty() or color.a == 0 or color.h < 0.48 or color.h > 0.72:
		return color
	return Appearance.surface(color, appearance, key)

func _panel(background: Color = PANEL, border: Color = Color("#1e4154"), tint_key: String = "panels") -> PanelContainer:
	var p = PanelContainer.new()
	p.add_theme_stylebox_override("panel", _style(background, border, 4, tint_key))
	return p

func _label(value: String, size: int = 16, color: Color = TEXT) -> Label:
	var result = Label.new()
	result.text = value
	result.add_theme_font_size_override("font_size", size)
	result.add_theme_color_override("font_color", Appearance.accent(appearance) if color == CYAN else color)
	result.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	return result

func _button(value: String, highlighted: bool = false) -> Button:
	var b = Button.new()
	b.text = value
	b.focus_mode = Control.FOCUS_ALL
	b.add_theme_font_size_override("font_size", 15)
	b.add_theme_color_override("font_color", TEXT)
	b.add_theme_color_override("font_hover_color", TEXT)
	_style_button(b, highlighted)
	return b

func _style_button(b: Button, highlighted: bool, tint_key: String = "panels") -> void:
	b.add_theme_stylebox_override("normal", _style(Color("#103747") if highlighted else PANEL_LIGHT, CYAN if highlighted else Color("#315263"), 4, tint_key))
	b.add_theme_stylebox_override("hover", _style(Color("#1c5366"), CYAN, 4, tint_key))
	b.add_theme_stylebox_override("pressed", _style(Color("#0a596d"), CYAN, 4, tint_key))
	b.add_theme_stylebox_override("disabled", _style(Color("#182733"), Color("#2a3940"), 4, tint_key))

func _text_input(value: String = "") -> LineEdit:
	var field = LineEdit.new()
	field.placeholder_text = value
	field.add_theme_font_size_override("font_size", 15)
	field.add_theme_color_override("font_color", TEXT)
	field.add_theme_color_override("font_placeholder_color", MUTED)
	field.add_theme_stylebox_override("normal", _style(Color("#091b27"), Color("#35566a"), 4))
	field.add_theme_stylebox_override("focus", _style(Color("#0b2230"), CYAN, 4))
	return field

func _option() -> OptionButton:
	var field = OptionButton.new()
	field.add_theme_font_size_override("font_size", 15)
	field.add_theme_color_override("font_color", TEXT)
	field.add_theme_stylebox_override("normal", _style(Color("#102c3b"), Color("#35566a"), 4))
	field.add_theme_stylebox_override("hover", _style(Color("#164456"), CYAN, 4))
	field.add_theme_stylebox_override("pressed", _style(Color("#164456"), CYAN, 4))
	return field

func _clear(node: Node) -> void:
	for child in node.get_children():
		node.remove_child(child)
		child.queue_free()

func _build_shell() -> void:
	background_rect = ColorRect.new()
	background_rect.color = Appearance.surface(BACKGROUND, appearance, "background")
	background_rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	background_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(background_rect)
	shell = BoxContainer.new()
	shell.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shell.add_theme_constant_override("separation", 0)
	add_child(shell)
	workspace = HBoxContainer.new()
	workspace.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	workspace.size_flags_vertical = Control.SIZE_EXPAND_FILL
	workspace.add_theme_constant_override("separation", 0)
	shell.add_child(workspace)
	workspace.resized.connect(_adjust_detail_width)
	_build_navigation()
	file_dialog = FileDialog.new()
	file_dialog.access = FileDialog.ACCESS_FILESYSTEM
	file_dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
	file_dialog.title = "Choose ARK dino INI or ZIP"
	file_dialog.filters = PackedStringArray(["*.zip ; ZIP archives", "*.ini ; Dino exports"])
	file_dialog.file_selected.connect(_start_import)
	add_child(file_dialog)
	folder_dialog = FileDialog.new()
	folder_dialog.access = FileDialog.ACCESS_FILESYSTEM
	folder_dialog.file_mode = FileDialog.FILE_MODE_OPEN_DIR
	folder_dialog.title = "Choose export folder"
	folder_dialog.dir_selected.connect(_folder_selected)
	add_child(folder_dialog)
	message_dialog = AcceptDialog.new()
	message_dialog.size = Vector2i(650, 300)
	add_child(message_dialog)
	confirm_import = ConfirmationDialog.new()
	confirm_import.title = "Review import"
	confirm_import.ok_button_text = "Import reviewed entries"
	confirm_import.size = Vector2i(740, 500)
	confirm_import.confirmed.connect(_commit_import)
	add_child(confirm_import)
	confirm_delete = ConfirmationDialog.new()
	confirm_delete.title = "Remove creature"
	confirm_delete.ok_button_text = "Remove"
	confirm_delete.confirmed.connect(_delete_selected)
	add_child(confirm_delete)
	confirm_project_delete = ConfirmationDialog.new()
	confirm_project_delete.title = "Delete planning project"
	confirm_project_delete.ok_button_text = "Delete project"
	confirm_project_delete.confirmed.connect(_delete_project_confirmed)
	add_child(confirm_project_delete)
	confirm_project_list_delete = ConfirmationDialog.new()
	confirm_project_list_delete.title = "Delete breeding list"
	confirm_project_list_delete.ok_button_text = "Move creatures to Main List and delete"
	confirm_project_list_delete.confirmed.connect(_project_delete_list_confirmed)
	add_child(confirm_project_list_delete)

func _build_navigation() -> void:
	var dock = int(layout["dock"])
	var horizontal = dock >= 2
	var icons = bool(layout["icons"])
	if is_instance_valid(sidebar_panel):
		shell.remove_child(sidebar_panel)
		sidebar_panel.queue_free()
	shell.vertical = horizontal
	sidebar_panel = _panel(Color("#091b29"), Color("#1b3748"), "sidebar")
	sidebar_panel.name = "NavigationDock"
	var style = sidebar_panel.get_theme_stylebox("panel").duplicate()
	style.set_content_margin_all(5)
	sidebar_panel.add_theme_stylebox_override("panel", style)
	shell.add_child(sidebar_panel)
	shell.move_child(sidebar_panel, 0 if dock in [0, 2] else 1)
	var nav = BoxContainer.new()
	nav.vertical = not horizontal
	nav.add_theme_constant_override("separation", 3)
	sidebar_panel.add_child(nav)
	nav_buttons.clear()
	var toggle = _button("›" if icons else "‹")
	toggle.name = "NavigationLabelToggle"
	toggle.custom_minimum_size = Vector2(28, 29)
	toggle.tooltip_text = "Show icons and labels" if icons else "Show icons only"
	toggle.pressed.connect(func(): layout["icons"] = not layout["icons"]; _save_navigation_layout())
	nav.add_child(toggle)
	if not icons and not horizontal:
		var brand = _label("BloodlineBank", 18)
		brand.custom_minimum_size.y = 30
		nav.add_child(brand)
	var items = [
		["library", "Creature Library", "Library", "M3 4h18v5H3zM3 10h18v5H3zM3 16h18v5H3zM7 6h1m-1 6h1m-1 6h1"],
		["color_table", "Color Table", "Table", "M3 5h18v14H3zM3 10h18M9 5v14m6-14v14"],
		["color_lab", "Color Lab", "Lab", "M8 3h8M10 3v7L4 19q-1 2 2 2h12q3 0 2-2l-6-9V3M8 15h8"],
		["projects", "Projects", "Projects", "M3 6h7l2 3h9v11H3zM3 9h9"],
		["partner", "Partner Finder", "Partners", "M12 20 4 12a5 5 0 0 1 8-6 5 5 0 0 1 8 6z"],
		["low_stats", "Lowest Stats", "Stats", "M4 20h16M6 16v-3m6 3V8m6 8V4"],
		["import", "Import Creature", "Import", "M12 16V4m-5 5 5-5 5 5M4 16v4h16v-4"],
		["bingo", "Color Bingo", "Bingo", "M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 16l3 3 5-6"],
		["goals", "Color Goals", "Goals", "M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0ZM17 12a5 5 0 1 1-10 0 5 5 0 0 1 10 0ZM12 11v2"],
		["settings", "Settings / Data", "Settings", "M4 6h16M4 12h16M4 18h16M8 4v4m8 2v4m-5 2v4"]
	]
	for item in items:
		var key: String = item[0]
		var label: String = item[2] if horizontal else item[1]
		var nav_button = _button("" if icons else label, key == selected_page)
		nav_button.name = "Nav_" + key
		nav_button.custom_minimum_size = Vector2(32 if icons else 0, 31)
		nav_button.tooltip_text = item[1]
		nav_button.clip_text = true
		nav_button.alignment = HORIZONTAL_ALIGNMENT_CENTER if icons else HORIZONTAL_ALIGNMENT_LEFT
		nav_button.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER if icons else HORIZONTAL_ALIGNMENT_LEFT
		if not navigation_icons.has(key):
			var image = Image.new()
			image.load_svg_from_string('<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24"><path fill="none" stroke="#eaf5fa" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" d="%s"/></svg>' % item[3])
			navigation_icons[key] = ImageTexture.create_from_image(image)
		nav_button.icon = navigation_icons[key]
		nav_button.pressed.connect(_nav_pressed.bind(key))
		nav.add_child(nav_button)
		nav_buttons[key] = nav_button
		if horizontal and not icons:
			nav_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scan_status_label = _label("Auto scan: waiting", 11, MUTED)
	scan_status_label.clip_text = true
	scan_status_label.visible = not horizontal and not icons
	nav.add_child(scan_status_label)
	if not scan_summary.is_empty():
		scan_status_label.text = scan_summary
	sidebar_panel.visible = not project_focus_expanded
	_adjust_detail_width.call_deferred()

func _save_navigation_layout() -> void:
	if LayoutSettings.save_layout(layout) != OK:
		_show_message("Layout not saved", "Could not write the layout preferences.")
	if is_instance_valid(layout_text_toggle):
		layout_text_toggle.set_pressed_no_signal(not layout["icons"])
	_build_navigation()

func _paged_scroll(scroll: ScrollContainer) -> void:
	var pager = DesktopPages.new()
	pager.install(scroll, _button("Previous"), _button("Next"), _label("", 11, MUTED))

func _result_page_controls(host: Container, total: int, page: int, per_page: int, show_page: Callable) -> void:
	_clear(host)
	var last = maxi(0, ceili(float(total) / float(per_page)) - 1)
	var indicator = _label("Page %s of %s" % [page + 1, last + 1], 11, MUTED)
	indicator.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	host.add_child(indicator)
	var previous = _button("Previous")
	previous.disabled = page <= 0
	previous.pressed.connect(show_page.bind(page - 1))
	host.add_child(previous)
	var next = _button("Next")
	next.disabled = page >= last
	next.pressed.connect(show_page.bind(page + 1))
	host.add_child(next)
	for child in host.get_children():
		child.visible = last > 0

func _nav_pressed(key: String) -> void:
	if key == "library":
		_show_library()
	elif key == "color_table":
		_show_color_table()
	elif key == "color_lab":
		_show_color_lab()
	elif key == "projects":
		_show_projects()
	elif key == "partner":
		_show_partner_finder()
	elif key == "low_stats":
		_show_lowest_stats()
	elif key == "import":
		_open_import()
	elif key == "goals":
		_show_goals()
	elif key == "bingo":
		_show_bingo()
	elif key == "settings":
		_show_settings()

func _activate_nav(key: String) -> void:
	# Leaving Projects always restores the normal navigation layout.
	# Returning to Projects later starts with the standard view.
	if key != "projects":
		project_focus_expanded = false
		if is_instance_valid(sidebar_panel):
			sidebar_panel.show()
	for id in nav_buttons:
		var b: Button = nav_buttons[id]
		var active = id == key
		_style_button(b, active, "sidebar")

func _show_color_lab(creature: Dictionary = {}) -> void:
	selected_page = "color_lab"
	_activate_nav("color_lab")
	_workspace_setup()
	details.hide()
	color_lab = ColorLabUI.new()
	color_lab.configure(palette, registry, data, color_lab_session, false, creature, appearance)
	middle.add_child(color_lab)

func _workspace_setup() -> void:
	_clear(workspace)
	page_preview_toggle = null
	middle = VBoxContainer.new()
	middle.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	middle.size_flags_vertical = Control.SIZE_EXPAND_FILL
	middle.add_theme_constant_override("separation", 6)
	workspace.add_child(middle)
	preview_splitter = PreviewSplitter.new()
	preview_splitter.name = "PreviewSplitter"
	preview_splitter.size_flags_vertical = Control.SIZE_EXPAND_FILL
	workspace.add_child(preview_splitter)
	details = VBoxContainer.new()
	details.size_flags_vertical = Control.SIZE_EXPAND_FILL
	details.add_theme_constant_override("separation", 4)
	workspace.add_child(details)
	details.custom_minimum_size.x = _preferred_detail_width()
	preview_splitter.panel = details
	preview_splitter.width_changed.connect(_resize_preview)
	preview_splitter.resize_finished.connect(func(): LayoutSettings.save_layout(layout))
	details.visibility_changed.connect(func(): preview_splitter.visible = details.visible)
	details.visible = detail_visibility.get(selected_page, true)

func _preview_width_limit() -> int:
	var available = workspace.size.x if is_instance_valid(workspace) and workspace.size.x > 0 else size.x
	return clampi(floori(available) - 560, LayoutSettings.MIN_PREVIEW, LayoutSettings.MAX_PREVIEW)

func _preferred_detail_width() -> float:
	return clampi(int(layout["preview"]), LayoutSettings.MIN_PREVIEW, _preview_width_limit())

func _resize_preview(width: int) -> void:
	layout["preview"] = clampi(width, LayoutSettings.MIN_PREVIEW, _preview_width_limit())
	_adjust_detail_width()

func _desktop_height() -> int:
	return floori(size.y) - (46 if int(layout["dock"]) >= 2 else 0)

func _adjust_detail_width() -> void:
	if is_instance_valid(details):
		details.custom_minimum_size.x = _preferred_detail_width()
	var height = _desktop_height()
	if last_desktop_height != height:
		last_desktop_height = height
		_refresh_desktop_result_pages.call_deferred()

func _refresh_desktop_result_pages() -> void:
	if selected_page == "low_stats":
		_lowest_render_details()
	elif selected_page == "partner":
		_partner_render_results()

func _toggle_current_details() -> void:
	details.visible = not details.visible
	detail_visibility[selected_page] = details.visible
	if selected_page == "library":
		library_preview_open = details.visible
		library_preview_button.text = "Hide preview" if details.visible else "Preview"
	elif selected_page == "color_table":
		color_table_show_details = details.visible
		color_table_toggle_details.text = "Hide details" if details.visible else "Show details"
	elif is_instance_valid(page_preview_toggle):
		page_preview_toggle.text = "Hide preview" if details.visible else "Preview"

func _page_heading(title: String) -> void:
	var row = HBoxContainer.new()
	middle.add_child(row)
	var heading = _label(title, 23)
	heading.clip_text = true
	heading.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(heading)
	page_preview_toggle = _button("Hide preview" if details.visible else "Preview")
	page_preview_toggle.pressed.connect(_toggle_current_details)
	row.add_child(page_preview_toggle)

func _preview_heading(parent: Container, title: String) -> void:
	var row = HBoxContainer.new()
	parent.add_child(row)
	var caption = _label(title, 18)
	caption.clip_text = true
	caption.tooltip_text = title
	caption.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(caption)
	var close = _button("›")
	close.name = "CollapseCreaturePreview"
	close.tooltip_text = "Collapse preview (Esc)"
	close.pressed.connect(_toggle_current_details)
	row.add_child(close)

func _table_page_length(scroll: ScrollContainer, header_height: int) -> int:
	var height = scroll.size.y if scroll.size.y > 60 else maxf(130, size.y - 180)
	return maxi(1, floori((height - header_height) / (DESKTOP_ROW_HEIGHT + 2.0)))

func _library_height_changed() -> void:
	if selected_page != "library" or not is_instance_valid(library_table_scroll):
		return
	var count = _table_page_length(library_table_scroll, 23)
	if count == library_rows_per_page:
		return
	page_index = floori(float(page_index * library_rows_per_page) / float(count))
	library_rows_per_page = count
	_render_rows()

func _color_table_height_changed() -> void:
	if selected_page != "color_table" or not is_instance_valid(color_table_scroll):
		return
	var count = _table_page_length(color_table_scroll, 0)
	if count == color_table_rows_per_page:
		return
	color_table_page = floori(float(color_table_page * color_table_rows_per_page) / float(count))
	color_table_rows_per_page = count
	_render_color_table()

func _fill_species_options(field: OptionButton, selected_key: String) -> void:
	field.clear()
	field.add_item("All species")
	field.set_item_metadata(0, "")
	field.fit_to_longest_item = false
	field.clip_text = true
	field.custom_minimum_size.x = 138
	var names = {}
	for creature in data.get("creatures", []):
		var key = str(creature.get("species_key", ""))
		if not key.is_empty():
			names[key] = str(creature.get("species_name", key))
	var keys = names.keys()
	keys.sort_custom(func(a, b):
		var left = str(names[a]).to_lower()
		var right = str(names[b]).to_lower()
		return str(a) < str(b) if left == right else left < right
	)
	var selected = 0
	for key in keys:
		field.add_item(str(names[key]))
		var index = field.item_count - 1
		field.set_item_metadata(index, key)
		if key == selected_key:
			selected = index
	field.select(selected)

func _show_library() -> void:
	selected_page = "library"
	_activate_nav("library")
	_workspace_setup()
	var title_bar = HBoxContainer.new()
	title_bar.add_theme_constant_override("separation", 10)
	middle.add_child(title_bar)
	var title = _label("Creature Library", 23, TEXT)
	title.clip_text = true
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_bar.add_child(title)
	library_preview_button = _button("Preview")
	library_preview_button.name = "LibraryTogglePreview"
	library_preview_button.pressed.connect(_toggle_current_details)
	title_bar.add_child(library_preview_button)
	var import_button = _button("Import .ini / .zip", true)
	import_button.pressed.connect(_open_import)
	title_bar.add_child(import_button)
	library_folder_button = _button("Export folder…")
	library_folder_button.name = "LibraryExportFolderButton"
	library_folder_button.tooltip_text = export_folder
	library_folder_button.pressed.connect(_open_export_folder_picker)
	title_bar.add_child(library_folder_button)
	var tools_row = HFlowContainer.new()
	tools_row.add_theme_constant_override("h_separation", 8)
	tools_row.add_theme_constant_override("v_separation", 6)
	middle.add_child(tools_row)
	var search_group = HBoxContainer.new()
	search_group.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	search_group.add_theme_constant_override("separation", 0)
	tools_row.add_child(search_group)
	search_mode_picker = _option()
	search_mode_picker.name = "LibrarySearchMode"
	search_mode_picker.tooltip_text = "Search by name, color ID, or level"
	search_mode_picker.custom_minimum_size.x = 105
	search_mode_picker.add_item("Name", LibrarySearchMode.NAME)
	search_mode_picker.add_item("Color ID", LibrarySearchMode.COLOR_ID)
	search_mode_picker.add_item("Level", LibrarySearchMode.LEVEL)
	search_mode_picker.select(library_search_mode)
	search_group.add_child(search_mode_picker)
	search_field = _text_input()
	search_field.name = "LibrarySearchField"
	search_field.clear_button_enabled = true
	search_field.custom_minimum_size.x = 142
	search_field.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	search_field.text_changed.connect(_on_search)
	search_group.add_child(search_field)
	search_region = _option()
	search_region.add_item("All regions")
	for region_index in range(6):
		search_region.add_item("Region %s" % region_index)
	search_region.item_selected.connect(func(_index): page_index = 0; _render_rows())
	tools_row.add_child(search_region)
	sort_field = _option()
	for name_text in ["Newest", "Name A–Z", "Level high", "Health high", "Melee high"]:
		sort_field.add_item(name_text)
	sort_field.item_selected.connect(func(_index): _render_rows())
	tools_row.add_child(sort_field)
	library_species = _option()
	library_species.name = "LibrarySpeciesFilter"
	library_species.tooltip_text = "Filter by creature species"
	_fill_species_options(library_species, library_species_key)
	library_species_key = str(library_species.get_selected_metadata())
	library_species.item_selected.connect(func(index):
		library_species_key = str(library_species.get_item_metadata(index))
		page_index = 0
		_render_rows()
	)
	tools_row.add_child(library_species)
	tools_row.move_child(library_species, 1)
	search_mode_picker.item_selected.connect(_on_library_search_mode_changed)
	_update_library_search_controls()
	var table = _panel(Color("#0a1c29"), Color("#203f50"))
	table.size_flags_vertical = Control.SIZE_EXPAND_FILL
	middle.add_child(table)
	var table_stack = VBoxContainer.new()
	table_stack.add_theme_constant_override("separation", 5)
	table.add_child(table_stack)
	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	library_table_scroll = scroll
	scroll.resized.connect(func(): _library_height_changed.call_deferred())
	table_stack.add_child(scroll)
	var table_content = VBoxContainer.new()
	table_content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	table_content.add_theme_constant_override("separation", 2)
	scroll.add_child(table_content)
	var header_margin = MarginContainer.new()
	header_margin.add_theme_constant_override("margin_left", 7)
	header_margin.add_theme_constant_override("margin_right", 7)
	table_content.add_child(header_margin)
	var header = HBoxContainer.new()
	header.add_theme_constant_override("separation", 5)
	for column in [["Name", COLUMN_NAME], ["Level", COLUMN_LEVEL], ["Sex", COLUMN_SEX], ["Health", COLUMN_HEALTH], ["Melee", COLUMN_MELEE]]:
		var label = _label(column[0], 13, MUTED)
		label.custom_minimum_size.x = column[1]
		label.clip_text = true
		if column[0] == "Name":
			label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		header.add_child(label)
	var regions_header = HBoxContainer.new()
	regions_header.add_theme_constant_override("separation", 2)
	header.add_child(regions_header)
	header.move_child(regions_header, 3)
	for i in range(6):
		var slot = _label("R%s" % i, 12, MUTED)
		slot.custom_minimum_size.x = 25
		slot.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		regions_header.add_child(slot)
	header_margin.add_child(header)
	list_box = VBoxContainer.new()
	list_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list_box.add_theme_constant_override("separation", 2)
	table_content.add_child(list_box)
	var bottom = HBoxContainer.new()
	bottom.add_theme_constant_override("separation", 8)
	table_stack.add_child(bottom)
	page_label = _label("", 13, MUTED)
	page_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bottom.add_child(page_label)
	previous_button = _button("Previous")
	previous_button.pressed.connect(func(): page_index = maxi(0, page_index - 1); _render_rows())
	bottom.add_child(previous_button)
	next_button = _button("Next")
	next_button.pressed.connect(func(): page_index += 1; _render_rows())
	bottom.add_child(next_button)
	_render_rows()
	_render_details()


# ---- LOWEST STATS TRACKER (0.4.5) -----------------------------------------
func _show_lowest_stats() -> void:
	selected_page = "low_stats"
	_activate_nav("low_stats")
	_workspace_setup()
	_page_heading("Lowest Stats")
	var species_options = LowestStatsScript.species(data.get("creatures", []))
	lowest_species_keys.clear()
	for option in species_options:
		lowest_species_keys.append(str(option["key"]))
	if not lowest_species_keys.has(lowest_species_key):
		lowest_species_key = ""
		for option in species_options:
			if str(option["name"]) == "X-Otter":
				lowest_species_key = str(option["key"])
				break
		if lowest_species_key.is_empty() and not lowest_species_keys.is_empty():
			lowest_species_key = str(lowest_species_keys[0])
	if lowest_mode.is_empty():
		lowest_mode = "points" if LowestStatsScript.has_points(data.get("creatures", []), lowest_species_key) else "values"
	var filters = HBoxContainer.new()
	filters.add_theme_constant_override("separation", 8)
	middle.add_child(filters)
	filters.add_child(_label("Species", 13, TEXT))
	var species_select = _option()
	species_select.fit_to_longest_item = false
	species_select.clip_text = true
	species_select.custom_minimum_size.x = 112
	species_select.name = "LowestSpecies"
	species_select.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for option in species_options:
		species_select.add_item("%s (%s)" % [str(option["name"]), int(option["count"])])
	if lowest_species_keys.has(lowest_species_key):
		species_select.select(lowest_species_keys.find(lowest_species_key))
	else:
		species_select.add_item("Import creatures first")
		species_select.disabled = true
	species_select.item_selected.connect(_lowest_species_changed)
	filters.add_child(species_select)
	lowest_mode_selector = _option()
	lowest_mode_selector.name = "LowestMode"
	lowest_mode_selector.add_item("Breeding points")
	lowest_mode_selector.add_item("Displayed stats")
	lowest_mode_selector.select(0 if lowest_mode == "points" else 1)
	lowest_mode_selector.item_selected.connect(_lowest_mode_changed)
	filters.add_child(lowest_mode_selector)
	var warning = _label("BREEDING POINTS: compares exported wild-point fields only. Missing fields remain unknown; mutation points are not verified." if lowest_mode == "points" else "DISPLAYED STATS ONLY: useful for finding low numbers, but not proof of inheritable points (level-ups and imprinting can change them).", 13, Color("#f3c77e"))
	warning.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	middle.add_child(warning)
	var summary_panel = _panel(Color("#0a1c29"), Color("#203f50"))
	summary_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	middle.add_child(summary_panel)
	var stack = VBoxContainer.new()
	stack.add_theme_constant_override("separation", 6)
	summary_panel.add_child(stack)
	var summary = _label("Lowest values in your collection", 18, TEXT)
	stack.add_child(summary)
	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	stack.add_child(scroll)
	lowest_rows_host = VBoxContainer.new()
	lowest_rows_host.name = "LowestStatsRows"
	lowest_rows_host.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	lowest_rows_host.add_theme_constant_override("separation", 5)
	scroll.add_child(lowest_rows_host)
	var detail_panel = _panel(Color("#0a1e2b"), Color("#255064"), "details")
	detail_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	details.add_child(detail_panel)
	var detail_scroll = ScrollContainer.new()
	detail_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	detail_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	detail_panel.add_child(detail_scroll)
	lowest_details_host = VBoxContainer.new()
	lowest_details_host.name = "LowestStatsDetails"
	lowest_details_host.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	lowest_details_host.add_theme_constant_override("separation", 8)
	detail_scroll.add_child(lowest_details_host)
	detail_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_NEVER
	_lowest_refresh()

func _lowest_species_changed(index: int) -> void:
	if index < 0 or index >= lowest_species_keys.size():
		return
	lowest_species_key = str(lowest_species_keys[index])
	lowest_selected_stat = "health"
	_lowest_refresh()

func _lowest_mode_changed(index: int) -> void:
	lowest_mode = "points" if index == 0 else "values"
	if lowest_mode == "points" and lowest_selected_stat == "torpidity":
		lowest_selected_stat = "health"
	# Rebuild the explanation and table in the new evidence mode.
	_show_lowest_stats()

func _lowest_refresh() -> void:
	lowest_page = 0
	lowest_analysis = LowestStatsScript.analyze(data.get("creatures", []), lowest_species_key, lowest_mode)
	_lowest_render_rows()
	_lowest_render_details()

func _lowest_render_rows() -> void:
	if not is_instance_valid(lowest_rows_host):
		return
	_clear(lowest_rows_host)
	var total = int(lowest_analysis.get("total", 0))
	if total == 0:
		var blank = _label("No creatures for this species. Import Otters first.", 15, MUTED)
		blank.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		lowest_rows_host.add_child(blank)
		return
	lowest_rows_host.add_child(_label("%s creatures  ·  lowest first  ·  click a stat for carriers" % total, 13, MUTED))
	for item in lowest_analysis.get("rows", []):
		var stat: Dictionary = item["stat"]
		var key = str(stat["key"])
		var selected = key == lowest_selected_stat
		var row_button = _button("", selected)
		row_button.name = "LowestStatRow_" + key.replace(" ", "_")
		row_button.custom_minimum_size.y = 39
		row_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row_button.pressed.connect(_lowest_select_stat.bind(key))
		lowest_rows_host.add_child(row_button)
		var line = HBoxContainer.new()
		line.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		line.offset_left = 8
		line.offset_right = -8
		line.add_theme_constant_override("separation", 12)
		line.mouse_filter = Control.MOUSE_FILTER_IGNORE
		row_button.add_child(line)
		var label = _label(str(stat["label"]), 16, TEXT)
		label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		label.clip_text = true
		label.mouse_filter = Control.MOUSE_FILTER_IGNORE
		line.add_child(label)
		var lowest_value = item["lowest"]
		var lowest = _label(LowestStatsScript.format_value(lowest_value, stat, lowest_mode), 17, GREEN if lowest_mode == "points" and lowest_value != null and int(lowest_value) == 0 else CYAN)
		lowest.custom_minimum_size.x = 98
		lowest.mouse_filter = Control.MOUSE_FILTER_IGNORE
		line.add_child(lowest)
		var known = _label("%s tied · %s/%s known" % [item["carriers"].size(), item["known"], total] if lowest_value != null else "No data", 12, MUTED)
		known.custom_minimum_size.x = 140
		known.clip_text = true
		known.mouse_filter = Control.MOUSE_FILTER_IGNORE
		line.add_child(known)
	if lowest_mode == "points" and not LowestStatsScript.has_points(data.get("creatures", []), lowest_species_key):
		var help = _label("No exported wild-point data found. Switch to Displayed stats for a reference comparison; it cannot confirm breeding points.", 13, Color("#f3c77e"))
		help.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		lowest_rows_host.add_child(help)

func _lowest_select_stat(key: String) -> void:
	lowest_selected_stat = key
	lowest_page = 0
	_lowest_render_rows()
	_lowest_render_details()

func _lowest_render_details() -> void:
	if not is_instance_valid(lowest_details_host):
		return
	_clear(lowest_details_host)
	var chosen: Dictionary = {}
	for item in lowest_analysis.get("rows", []):
		if str(item["stat"]["key"]) == lowest_selected_stat:
			chosen = item
			break
	if chosen.is_empty():
		lowest_details_host.add_child(_label("Select a stat", 23, TEXT))
		return
	var stat: Dictionary = chosen["stat"]
	_preview_heading(lowest_details_host, str(stat["label"]) + " · lowest")
	var minimum = chosen["lowest"]
	lowest_details_host.add_child(_label(LowestStatsScript.format_value(minimum, stat, lowest_mode), 26, GREEN if lowest_mode == "points" and minimum != null and int(minimum) == 0 else CYAN))
	lowest_details_host.add_child(_label("%s with this minimum  ·  %s unknown" % [chosen["carriers"].size(), chosen["unknown"]], 13, MUTED))
	if minimum == null:
		var none = _label("No usable values for this stat in the selected Otters. Missing export values are never treated as zero.", 14, MUTED)
		none.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		lowest_details_host.add_child(none)
		return
	if lowest_mode == "points":
		var note = _label("Goal: 0 points. Even a 0 here is not proof of a Level 1 baby; other stats and mutation levels also matter.", 12, Color("#f3c77e"))
		note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		lowest_details_host.add_child(note)
	elif str(stat["key"]) == "torpidity":
		lowest_details_host.add_child(_label("Torpor is shown for reference; it is not an independent breeding stat to reduce.", 12, MUTED))
	lowest_details_host.add_child(_label("Otters ranked lowest → highest", 17, TEXT))
	var candidates: Array = chosen["candidates"]
	var per_page = maxi(1, floori((_desktop_height() - 216.0) / 38.0))
	lowest_page = clampi(lowest_page, 0, maxi(0, ceili(float(candidates.size()) / float(per_page)) - 1))
	var start = lowest_page * per_page
	for i in range(start, mini(start + per_page, candidates.size())):
		var candidate: Dictionary = candidates[i]
		var creature: Dictionary = candidate["creature"]
		var value = LowestStatsScript.format_value(candidate["value"], stat, lowest_mode)
		var sex = "♀" if str(creature.get("sex", "")) == "Female" else ("♂" if str(creature.get("sex", "")) == "Male" else "?")
		var line = _button("%s %s  ·  Lv%s  ·  %s" % [sex, str(creature.get("name", "Unknown")), str(creature.get("level", "?")), value], i == 0)
		line.name = "LowestCarrierRow"
		line.alignment = HORIZONTAL_ALIGNMENT_LEFT
		line.clip_text = true
		line.custom_minimum_size.y = 30
		line.tooltip_text = "Open this Otter in the Creature Library"
		line.pressed.connect(_partner_open_in_library.bind(str(creature.get("local_id", ""))))
		lowest_details_host.add_child(line)
	var pages = HBoxContainer.new()
	lowest_details_host.add_child(pages)
	_result_page_controls(pages, candidates.size(), lowest_page, per_page, func(index):
		lowest_page = index
		_lowest_render_details()
	)

# ---- END LOWEST STATS TRACKER ---------------------------------------------

# ---- PARTNER FINDER (0.4.4) -----------------------------------------------
# The search remains read-only. A separate saved map tracks which females are
# already used elsewhere; it never changes creature colors or breeding lists.
func _partner_marks() -> Dictionary:
	var marks = data.get(PARTNER_MARKS_KEY, {})
	return marks if typeof(marks) == TYPE_DICTIONARY else {}

func _partner_is_used(local_id: String) -> bool:
	return _partner_marks().get(local_id, false) == true

func _partner_update_used_button(button: Button, used: bool) -> void:
	button.text = "✕" if used else "□"
	button.tooltip_text = "Already used in another breeding. Click to clear the X." if used else "Mark as used in another breeding."
	button.add_theme_font_size_override("font_size", 21)
	button.add_theme_color_override("font_color", RED if used else MUTED)
	button.add_theme_color_override("font_hover_color", TEXT)
	button.add_theme_stylebox_override("normal", _style(Color("#422532") if used else Color("#132b39"), RED if used else Color("#335365"), 5))
	button.add_theme_stylebox_override("hover", _style(Color("#60303e"), RED, 5))
	button.add_theme_stylebox_override("pressed", _style(Color("#60303e"), RED, 5))

func _partner_update_results_summary() -> void:
	if not is_instance_valid(partner_results_summary):
		return
	partner_clear_marks_button.disabled = not _partner_marks().values().has(true)
	if not partner_searched:
		partner_results_summary.text = ""
		return
	var marked = 0
	for item in partner_results:
		if _partner_is_used(str(item["creature"].get("local_id", ""))):
			marked += 1
	partner_results_summary.text = "%s matches · %s marked X" % [partner_results.size(), marked] if marked > 0 else "%s matches" % partner_results.size()

func _partner_save_marks(marks: Dictionary) -> bool:
	var next_data = data.duplicate()
	next_data[PARTNER_MARKS_KEY] = marks
	var saved = storage.save_data(next_data)
	if not saved.get("ok", false):
		_show_message("Could not save X marks", str(saved.get("error", "No changes were saved.")))
		return false
	data = next_data
	database_revision += 1
	return true

func _partner_toggle_used(local_id: String, button: Button) -> void:
	if local_id.is_empty():
		return
	var marks = _partner_marks().duplicate()
	var used = not _partner_is_used(local_id)
	if used:
		marks[local_id] = true
	else:
		marks.erase(local_id)
	if not _partner_save_marks(marks):
		return
	_partner_update_used_button(button, used)
	_partner_update_results_summary()
	if partner_female_id == local_id:
		_partner_render_details()

func _partner_clear_all_marks() -> void:
	if not _partner_marks().values().has(true) or not _partner_save_marks({}):
		return
	for button in partner_results_box.find_children("PartnerUsedToggle", "Button", true, false):
		_partner_update_used_button(button, false)
	_partner_update_results_summary()
	_partner_render_details()

func _partner_find_creature(local_id: String) -> Dictionary:
	if local_id.is_empty():
		return {}
	for item in data.get("creatures", []):
		if typeof(item) == TYPE_DICTIONARY and str(item.get("local_id", "")) == local_id:
			return item
	return {}

func _partner_row(creature: Dictionary, score: String, highlighted: bool, on_select: Callable, search_color: int = -1) -> Control:
	var button = Button.new()
	button.name = "PartnerCreatureRow"
	button.custom_minimum_size.y = 36
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.tooltip_text = "%s · Level %s · %s\n%s" % [str(creature.get("name", "Unnamed")), str(creature.get("level", "—")), str(creature.get("sex", "Unknown")), score]
	button.add_theme_stylebox_override("normal", _style(Color("#104656") if highlighted else Color("#0c202e"), CYAN if highlighted else Color("#173544"), 5))
	button.add_theme_stylebox_override("hover", _style(Color("#154254"), CYAN, 5))
	button.add_theme_stylebox_override("pressed", _style(Color("#104656"), CYAN, 5))
	if on_select.is_valid():
		button.pressed.connect(on_select)
	else:
		button.focus_mode = Control.FOCUS_NONE
	var row = HBoxContainer.new()
	row.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	row.offset_left = 7
	row.offset_right = -7
	row.add_theme_constant_override("separation", 5)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	button.add_child(row)
	var name_box = HBoxContainer.new()
	name_box.custom_minimum_size.x = 125 if on_select.is_valid() else 102
	name_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(name_box)
	var picture = _preview(creature, Vector2(27, 27))
	picture.custom_minimum_size = Vector2(27, 27)
	picture.mouse_filter = Control.MOUSE_FILTER_IGNORE
	name_box.add_child(picture)
	var name_label = _label(str(creature.get("name", "Unnamed")), 13, TEXT)
	name_label.clip_text = true
	name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	name_box.add_child(name_label)
	var level = _label(str(creature.get("level", "—")) if creature.get("level", null) != null else "—", 13, TEXT)
	level.custom_minimum_size.x = 34
	level.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(level)
	var sex = str(creature.get("sex", "Unknown"))
	var sex_label: Control = SexSymbolScript.new(sex) if sex in ["Male", "Female"] else _label("?", 18, MUTED)
	sex_label.custom_minimum_size.x = 29
	sex_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(sex_label)
	var region_row = HBoxContainer.new()
	region_row.custom_minimum_size.x = COLUMN_COLORS
	region_row.add_theme_constant_override("separation", 2)
	region_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var outline_color = search_color if search_color >= 0 else partner_target_color
	var selected_male = _partner_find_creature(partner_male_id) if search_color < 0 and outline_color >= 0 else {}
	for i in range(6):
		var cell = _creature_region_chip(creature, i)
		if outline_color >= 0 and ColorTableScript.confirmed_id(creature, i) == outline_color:
			var swatch_style = cell.get_theme_stylebox("panel").duplicate() as StyleBoxFlat
			if swatch_style != null:
				var already_on_male = PartnerScript.confirmed_color(selected_male, i) == outline_color
				swatch_style.border_color = Appearance.accent(appearance) if search_color >= 0 or already_on_male else GREEN
				swatch_style.set_border_width_all(2)
				cell.add_theme_stylebox_override("panel", swatch_style)
		cell.mouse_filter = Control.MOUSE_FILTER_IGNORE
		region_row.add_child(cell)
	row.add_child(region_row)
	var positive_score = score.begins_with("+") and not score.begins_with("+0 ")
	var score_label = _label(score, 12, GREEN if positive_score else MUTED)
	score_label.custom_minimum_size.x = 88
	score_label.clip_text = true
	score_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(score_label)
	score_label.visible = on_select.is_valid()
	return button

func _partner_table_header(parent: VBoxContainer, show_mark: bool = false) -> void:
	var margin = MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 7)
	margin.add_theme_constant_override("margin_right", 7)
	parent.add_child(margin)
	var row = HBoxContainer.new()
	row.add_theme_constant_override("separation", 5)
	margin.add_child(row)
	var columns = [["Creature", 125], ["Lvl", 34], ["Sex", 29], ["Color regions 0–5", COLUMN_COLORS], ["Matching", 88]]
	if show_mark:
		columns.append(["Used", 32])
	for column in columns:
		var label = _label(str(column[0]), 12, MUTED)
		label.custom_minimum_size.x = int(column[1])
		label.clip_text = true
		if str(column[0]) == "Creature":
			label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(label)

func _show_partner_finder() -> void:
	selected_page = "partner"
	_activate_nav("partner")
	_workspace_setup()
	_page_heading("Partner Finder")
	var selector_heading = HBoxContainer.new()
	middle.add_child(selector_heading)
	var selector_title = _label("Selected Male", 18, TEXT)
	selector_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	selector_heading.add_child(selector_title)
	var change = _button("Hide males" if partner_picker_visible else "Change Male")
	change.pressed.connect(_partner_toggle_picker)
	selector_heading.add_child(change)
	partner_selected_host = VBoxContainer.new()
	partner_selected_host.add_theme_constant_override("separation", 4)
	middle.add_child(partner_selected_host)
	var picker_section = VBoxContainer.new()
	picker_section.add_theme_constant_override("separation", 5)
	picker_section.visible = partner_picker_visible
	middle.add_child(picker_section)
	var filters = HFlowContainer.new()
	filters.add_theme_constant_override("h_separation", 7)
	filters.add_theme_constant_override("v_separation", 5)
	picker_section.add_child(filters)
	var species = _option()
	species.name = "PartnerSpecies"
	species.tooltip_text = "Filter by creature species"
	_fill_species_options(species, partner_species_key)
	partner_species_key = str(species.get_selected_metadata())
	filters.add_child(species)
	var search_mode = _option()
	search_mode.name = "PartnerSearchMode"
	search_mode.add_item("Color ID", PartnerScript.SearchMode.COLOR_ID)
	search_mode.add_item("Name", PartnerScript.SearchMode.NAME)
	search_mode.add_item("Level", PartnerScript.SearchMode.LEVEL)
	search_mode.select(search_mode.get_item_index(partner_search_mode))
	filters.add_child(search_mode)
	var male_search = _text_input(_partner_search_placeholder())
	male_search.custom_minimum_size.x = 136
	male_search.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	male_search.name = "PartnerMaleSearch"
	male_search.clear_button_enabled = true
	male_search.text = partner_search_query
	male_search.text_changed.connect(_partner_search_males)
	filters.add_child(male_search)
	species.item_selected.connect(func(index):
		partner_species_key = str(species.get_item_metadata(index))
		var current = _partner_find_creature(partner_male_id)
		if not current.is_empty() and not partner_species_key.is_empty() and current.get("species_key", "") != partner_species_key:
			partner_male_id = ""
			partner_female_id = ""
			partner_target_color = -1
			partner_searched = false
			_show_partner_finder()
		else:
			_partner_search_males(male_search.text)
	)
	search_mode.item_selected.connect(func(index):
		partner_search_mode = search_mode.get_item_id(index)
		male_search.placeholder_text = _partner_search_placeholder()
		_partner_search_males(male_search.text)
	)
	var picker_panel = _panel(Color("#091c2b"), Color("#25485a"))
	picker_section.add_child(picker_panel)
	partner_picker_scroll = ScrollContainer.new()
	partner_picker_scroll.custom_minimum_size.y = 104
	partner_picker_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	picker_panel.add_child(partner_picker_scroll)
	partner_male_picker = VBoxContainer.new()
	partner_male_picker.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	partner_male_picker.add_theme_constant_override("separation", 3)
	partner_picker_scroll.add_child(partner_male_picker)
	_paged_scroll(partner_picker_scroll)
	if partner_picker_visible:
		_partner_render_males()

	var male = _partner_find_creature(partner_male_id)
	if not male.is_empty() and not PartnerScript.can_breed(male, "Male"):
		male = {}
		partner_male_id = ""
	if male.is_empty():
		partner_searched = false
		partner_results.clear()
		partner_selected_host.add_child(_label("No male selected. Choose one from the list.", 14, MUTED))
	else:
		partner_selected_host.add_child(_partner_row(male, "Your male", true, Callable()))
	var tools = HBoxContainer.new()
	tools.add_theme_constant_override("separation", 8)
	middle.add_child(tools)
	var color_label = _label("Target color", 14, TEXT)
	tools.add_child(color_label)
	partner_color_select = _option()
	partner_color_select.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tools.add_child(partner_color_select)
	var colors = PartnerScript.colors_for_male(male) if not male.is_empty() else []
	var color_index = 0
	var target_found = false
	for entry in colors:
		var id = int(entry["id"])
		var count = int(entry["count"])
		partner_color_select.add_item("#%s · %s male regions" % [id, count], id)
		if id == partner_target_color:
			color_index = partner_color_select.item_count - 1
			target_found = true
	if colors.is_empty():
		partner_target_color = -1
		partner_color_select.add_item("Select a male first")
		partner_color_select.disabled = true
	else:
		if not target_found:
			color_index = 0
			partner_target_color = int(colors[0]["id"])
		partner_color_select.select(color_index)
	partner_color_select.item_selected.connect(_partner_color_changed)
	var search_button = _button("Find Females", true)
	search_button.name = "PartnerFindButton"
	search_button.disabled = male.is_empty() or partner_target_color < 0
	search_button.pressed.connect(_partner_run_search)
	tools.add_child(search_button)
	var matches_panel = _panel(Color("#0a1c29"), Color("#203f50"))
	matches_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	middle.add_child(matches_panel)
	var matches_stack = VBoxContainer.new()
	matches_stack.add_theme_constant_override("separation", 5)
	matches_panel.add_child(matches_stack)
	var results_heading = HBoxContainer.new()
	matches_stack.add_child(results_heading)
	var results_caption = VBoxContainer.new()
	results_caption.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	results_caption.add_theme_constant_override("separation", 1)
	results_heading.add_child(results_caption)
	var title = _label("Female partners", 18, TEXT)
	title.clip_text = true
	results_caption.add_child(title)
	partner_results_summary = _label("", 12, MUTED)
	partner_results_summary.clip_text = true
	results_caption.add_child(partner_results_summary)
	partner_clear_marks_button = _button("Clear all X marks")
	partner_clear_marks_button.name = "PartnerClearMarks"
	partner_clear_marks_button.tooltip_text = "Clear every saved X mark, including females outside these results."
	partner_clear_marks_button.pressed.connect(_partner_clear_all_marks)
	results_heading.add_child(partner_clear_marks_button)
	var result_scroll = ScrollContainer.new()
	result_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	result_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	result_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_NEVER
	matches_stack.add_child(result_scroll)
	partner_results_box = VBoxContainer.new()
	partner_results_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	partner_results_box.add_theme_constant_override("separation", 4)
	result_scroll.add_child(partner_results_box)
	partner_result_footer = HBoxContainer.new()
	partner_result_footer.custom_minimum_size.y = 31
	matches_stack.add_child(partner_result_footer)
	partner_details_host = VBoxContainer.new()
	partner_details_host.size_flags_vertical = Control.SIZE_EXPAND_FILL
	details.add_child(partner_details_host)
	if partner_searched:
		_partner_run_search()
	else:
		_partner_render_results()
		_partner_render_details()

func _partner_toggle_picker() -> void:
	partner_picker_visible = not partner_picker_visible
	_show_partner_finder()

func _partner_search_placeholder() -> String:
	match partner_search_mode:
		PartnerScript.SearchMode.NAME:
			return "Search male name"
		PartnerScript.SearchMode.LEVEL:
			return "Exact level, e.g. 79"
		_:
			return "Color ID, e.g. 79"

func _partner_query_color() -> int:
	return PartnerScript.search_color_id(partner_search_query) if partner_search_mode == PartnerScript.SearchMode.COLOR_ID else -1

func _partner_search_males(query: String) -> void:
	partner_search_query = query
	_partner_render_males()
	partner_picker_scroll.set_deferred("scroll_vertical", 0)

func _partner_render_males() -> void:
	if not is_instance_valid(partner_male_picker):
		return
	_clear(partner_male_picker)
	_partner_table_header(partner_male_picker)
	var query_color = _partner_query_color()
	var shown = 0
	for entry in PartnerScript.male_matches(data.get("creatures", []), partner_search_query, partner_search_mode, partner_species_key):
		var male: Dictionary = entry["creature"]
		var male_id = str(male.get("local_id", ""))
		if male_id.is_empty():
			continue
		var score = "%s× color #%s" % [entry["count"], entry["id"]] if query_color >= 0 or entry["count"] >= 2 else "Select male"
		var row = _partner_row(male, score, male_id == partner_male_id, _partner_select_male.bind(male_id), query_color)
		partner_male_picker.add_child(row)
		shown += 1
	if shown == 0:
		var message = "No eligible males carry color #%s in a confirmed region." % query_color if query_color >= 0 else "No males match these filters."
		partner_male_picker.add_child(_label(message, 13, MUTED))

func _partner_select_male(local_id: String) -> void:
	partner_male_id = local_id
	partner_result_page = 0
	partner_female_id = ""
	partner_target_color = _partner_query_color()
	partner_searched = false
	partner_results.clear()
	partner_picker_visible = false
	_show_partner_finder()

func _partner_color_changed(index: int) -> void:
	partner_target_color = partner_color_select.get_item_id(index)
	partner_result_page = 0
	partner_searched = false
	partner_female_id = ""
	partner_results.clear()
	_partner_render_results()
	_partner_render_details()

func _partner_run_search() -> void:
	var male = _partner_find_creature(partner_male_id)
	var ranking = PartnerScript.rank(data.get("creatures", []), male, partner_target_color)
	partner_searched = true
	partner_results = ranking.get("results", []) if ranking.get("valid", false) else []
	var current_found = false
	for item in partner_results:
		if str(item["creature"].get("local_id", "")) == partner_female_id:
			current_found = true
			break
	if not current_found:
		partner_female_id = str(partner_results[0]["creature"].get("local_id", "")) if not partner_results.is_empty() else ""
	_partner_render_results()
	_partner_render_details()

func _partner_render_results() -> void:
	if not is_instance_valid(partner_results_box):
		return
	_clear(partner_results_box)
	_partner_update_results_summary()
	_clear(partner_result_footer)
	if not partner_searched:
		var prompt = _label("Choose a target color, then click Find Females.", 14, MUTED)
		prompt.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		partner_results_box.add_child(prompt)
		return
	if partner_results.is_empty():
		var message = _label("No females carry this color in the male’s missing regions.", 14, MUTED)
		message.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		partner_results_box.add_child(message)
		return
	_partner_table_header(partner_results_box, true)
	var total = PartnerScript.active_slots(_partner_find_creature(partner_male_id)).size()
	var occupied = 348.0 if partner_picker_visible else 205.0
	var per_page = maxi(1, floori((_desktop_height() - occupied) / 40.0))
	partner_result_page = clampi(partner_result_page, 0, maxi(0, ceili(float(partner_results.size()) / float(per_page)) - 1))
	var start = partner_result_page * per_page
	_result_page_controls(partner_result_footer, partner_results.size(), partner_result_page, per_page, func(index):
		partner_result_page = index
		_partner_render_results()
	)
	for i in range(start, mini(start + per_page, partner_results.size())):
		var candidate: Dictionary = partner_results[i]
		var female: Dictionary = candidate["creature"]
		var match_id = str(female.get("local_id", ""))
		var new_slots: Array = candidate["new_slots"]
		var marker = "+%s new · %s/%s" % [candidate["new_count"], candidate["combined_count"], total]
		var cell = _partner_row(female, marker, match_id == partner_female_id, _partner_select_female.bind(match_id))
		cell.name = "PartnerFemaleRow"
		cell.tooltip_text += "\nAdds: %s\nFemale has target color in %s regions." % [_partner_slot_names(new_slots), candidate["female_count"]]
		var entry = HBoxContainer.new()
		entry.name = "PartnerFemaleEntry"
		entry.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		entry.add_theme_constant_override("separation", 5)
		partner_results_box.add_child(entry)
		entry.add_child(cell)
		# Separate sibling button: clicking X must not select the creature row.
		var mark = Button.new()
		mark.name = "PartnerUsedToggle"
		mark.custom_minimum_size = Vector2(32, 30)
		mark.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		mark.disabled = match_id.is_empty()
		_partner_update_used_button(mark, _partner_is_used(match_id))
		mark.pressed.connect(_partner_toggle_used.bind(match_id, mark))
		entry.add_child(mark)

func _partner_select_female(local_id: String) -> void:
	partner_female_id = local_id
	_partner_render_results()
	_partner_render_details()

func _partner_slot_names(slots: Array) -> String:
	if slots.is_empty():
		return "none"
	var names: Array[String] = []
	for slot in slots:
		names.append("R%s" % slot)
	return ", ".join(names)

func _partner_render_details() -> void:
	if not is_instance_valid(partner_details_host):
		return
	_clear(partner_details_host)
	var panel = _panel(Color("#0a1e2b"), Color("#255064"), "details")
	panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	partner_details_host.add_child(panel)
	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	panel.add_child(scroll)
	var content = VBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 5)
	scroll.add_child(content)
	_paged_scroll(scroll)
	_preview_heading(content, "Breeding comparison")
	var male = _partner_find_creature(partner_male_id)
	if male.is_empty():
		var hint = _label("Select a male to compare his color regions with a matching female.", 14, MUTED)
		hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		content.add_child(hint)
		return
	if not partner_searched:
		var prompt = _label("Find females for target #%s to compare coverage." % partner_target_color, 13, MUTED)
		prompt.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		content.add_child(prompt)
		return
	if partner_female_id.is_empty():
		var no_matches = _label("No females fill a missing region for #%s." % partner_target_color, 13, MUTED)
		no_matches.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		content.add_child(no_matches)
		return
	var chosen: Dictionary = {}
	for result in partner_results:
		if str(result["creature"].get("local_id", "")) == partner_female_id:
			chosen = result
			break
	if chosen.is_empty():
		return
	var female: Dictionary = chosen["creature"]
	var label = _label("%s · Lvl %s" % [female.get("name", "Unnamed"), female.get("level", "—")], 17, TEXT)
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	content.add_child(label)
	if _partner_is_used(partner_female_id):
		var used_note = _label("✕ Already used in another breeding", 13, RED)
		used_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		content.add_child(used_note)
	var picture = _preview(female, Vector2(0, 120))
	content.add_child(picture)
	if picture.texture == null:
		picture.hide()
		content.add_child(_label("Creature preview unavailable for this species.", 12, MUTED))
	var total = PartnerScript.active_slots(male).size()
	var overview = _label("Target #%s  ·  %s/%s covered together" % [partner_target_color, chosen["combined_count"], total], 17, GREEN if int(chosen["missing_count"]) == 0 else TEXT)
	overview.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	content.add_child(overview)
	content.add_child(_label("Male: %s slots   Female: %s slots" % [_partner_count_target(male, partner_target_color), chosen["female_count"]], 13, MUTED))
	content.add_child(_label("New regions from female: %s" % _partner_slot_names(chosen["new_slots"]), 14, GREEN))
	content.add_child(_label("Both parents share target: %s" % _partner_slot_names(chosen["both_slots"]), 13, MUTED))
	content.add_child(_label("Still uncovered: %s" % chosen["missing_count"], 13, RED if int(chosen["missing_count"]) > 0 else GREEN))
	content.add_child(_label("Region-by-region", 16, TEXT))
	var region_names: Array = male.get("region_names", [])
	for i in range(6):
		if i not in PartnerScript.active_slots(male):
			continue
		var male_has = PartnerScript.confirmed_color(male, i) == partner_target_color
		var female_has = PartnerScript.confirmed_color(female, i) == partner_target_color
		var status = "BOTH" if male_has and female_has else ("FEMALE adds" if female_has else ("MALE has" if male_has else "MISSING"))
		var color = GREEN if male_has and female_has else (CYAN if male_has or female_has else RED)
		var caption = "R%s · %s  —  %s" % [i, str(region_names[i]), status]
		var region_status = _label(caption, 12, color)
		region_status.clip_text = true
		region_status.tooltip_text = caption
		content.add_child(region_status)
	var warning = _label("Coverage shows where either parent carries the target. A solid-color baby depends on inheritance.", 12, MUTED)
	warning.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	content.add_child(warning)
	var open_button = _button("Open Female in Library")
	open_button.pressed.connect(_partner_open_in_library.bind(partner_female_id))
	content.add_child(open_button)

func _partner_count_target(creature: Dictionary, target_id: int) -> int:
	var count = 0
	for i in PartnerScript.active_slots(creature):
		if PartnerScript.confirmed_color(creature, i) == target_id:
			count += 1
	return count

func _partner_open_in_library(local_id: String) -> void:
	_open_carrier(local_id)
# ---- END PARTNER FINDER ----------------------------------------------------

func _show_color_table() -> void:
	selected_page = "color_table"
	_activate_nav("color_table")
	_workspace_setup()
	details.visible = color_table_show_details
	var title_bar = HBoxContainer.new()
	title_bar.add_theme_constant_override("separation", 8)
	middle.add_child(title_bar)
	var title = _label("Color Table", 23, TEXT)
	title.clip_text = true
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_bar.add_child(title)
	var projects_button = _button("Projects", true)
	projects_button.name = "ColorTableProjects"
	projects_button.tooltip_text = "Make organized otter tables with checklist notes and draggable rows."
	projects_button.pressed.connect(_show_projects)
	title_bar.add_child(projects_button)
	color_table_toggle_details = _button("Hide details" if color_table_show_details else "Show details")
	color_table_toggle_details.name = "ColorTableToggleDetails"
	color_table_toggle_details.tooltip_text = "Make more room for all six region columns."
	color_table_toggle_details.pressed.connect(func():
		_toggle_current_details()
	)
	title_bar.add_child(color_table_toggle_details)
	color_table_copy_button = _button("Copy rows")
	color_table_copy_button.name = "ColorTableCopy"
	color_table_copy_button.tooltip_text = "Copy all filtered rows as text for a spreadsheet or message. Colors are represented by IDs and names."
	color_table_copy_button.pressed.connect(_copy_color_table)
	title_bar.add_child(color_table_copy_button)
	var tools = HBoxContainer.new()
	tools.add_theme_constant_override("separation", 8)
	middle.add_child(tools)
	color_table_search = _text_input("Search name or species...")
	color_table_search.name = "ColorTableSearch"
	color_table_search.custom_minimum_size.x = 90
	color_table_search.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	color_table_search.text = color_table_query
	color_table_search.text_changed.connect(func(value): color_table_query = value; color_table_page = 0; _render_color_table())
	tools.add_child(color_table_search)
	color_table_species = _option()
	color_table_species.name = "ColorTableSpecies"
	color_table_species.custom_minimum_size.x = 125
	color_table_species.clip_text = true
	tools.add_child(color_table_species)
	_refresh_color_table_species()
	color_table_species.item_selected.connect(func(index):
		color_table_species_key = str(color_table_species_keys[index]) if index >= 0 and index < color_table_species_keys.size() else ""
		color_table_page = 0
		_render_color_table()
	)
	var clear = _button("Clear")
	clear.tooltip_text = "Clear the search, species and region filters."
	clear.pressed.connect(_clear_color_table_filters)
	tools.add_child(clear)
	var filters = HBoxContainer.new()
	filters.add_theme_constant_override("separation", 6)
	middle.add_child(filters)
	color_table_inputs = []
	for index in range(6):
		var field = _text_input("R%s · ID / name" % index)
		field.name = "ColorTableFilter%s" % index
		field.custom_minimum_size.x = 0
		field.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		field.text = str(color_table_filters[index])
		field.tooltip_text = "Region %s: enter a color ID, name, or ? for unidentified." % index
		field.text_changed.connect(func(value): _on_color_table_filter(index, value))
		filters.add_child(field)
		color_table_inputs.append(field)
	var table = _panel(Color("#0a1c29"), Color("#203f50"))
	table.size_flags_vertical = Control.SIZE_EXPAND_FILL
	middle.add_child(table)
	var table_stack = VBoxContainer.new()
	table_stack.add_theme_constant_override("separation", 5)
	table.add_child(table_stack)
	var hint = _label("Click R0–R5 to sort  •  ? unknown  •  — unused", 12, MUTED)
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	table_stack.add_child(hint)
	color_table_header_scroll = ScrollContainer.new()
	color_table_header_scroll.name = "ColorTableHeaderScroll"
	color_table_header_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	color_table_header_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	color_table_header_scroll.custom_minimum_size.y = 34
	table_stack.add_child(color_table_header_scroll)
	var header_margin = MarginContainer.new()
	header_margin.add_theme_constant_override("margin_left", 7)
	header_margin.add_theme_constant_override("margin_right", 7)
	color_table_header_scroll.add_child(header_margin)
	var header = HBoxContainer.new()
	header.add_theme_constant_override("separation", 5)
	header_margin.add_child(header)
	header_margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for spec in [["Creature", TABLE_CREATURE_WIDTH], ["Lvl", TABLE_LEVEL_WIDTH], ["Sex", TABLE_SEX_WIDTH]]:
		var heading = _label(spec[0], 13, MUTED)
		heading.custom_minimum_size.x = spec[1]
		heading.clip_text = true
		if spec[0] == "Creature":
			heading.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		header.add_child(heading)
	color_table_header_buttons = []
	for i in range(6):
		var region_index = i
		var sort_button = Button.new()
		sort_button.name = "ColorTableSort%s" % i
		sort_button.custom_minimum_size = Vector2(TABLE_REGION_WIDTH, 30)
		sort_button.add_theme_font_size_override("font_size", 13)
		sort_button.add_theme_color_override("font_color", TEXT)
		var normal = _style(Color("#153343"), Color("#315263"), 3)
		normal.content_margin_left = 3
		normal.content_margin_right = 3
		normal.content_margin_top = 2
		normal.content_margin_bottom = 2
		sort_button.add_theme_stylebox_override("normal", normal)
		var hover = normal.duplicate()
		hover.bg_color = _surface_color(Color("#1c5366"), "panels")
		hover.border_color = Appearance.accent(appearance)
		sort_button.add_theme_stylebox_override("hover", hover)
		sort_button.add_theme_stylebox_override("pressed", hover)
		sort_button.tooltip_text = "Sort by color ID in region %s. Click again to reverse." % i
		sort_button.pressed.connect(func(): _sort_color_table_region(region_index))
		header.add_child(sort_button)
		color_table_header_buttons.append(sort_button)
	color_table_scroll = ScrollContainer.new()
	color_table_scroll.name = "ColorTableScroll"
	color_table_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	color_table_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	color_table_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	color_table_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	color_table_scroll.resized.connect(func(): _color_table_height_changed.call_deferred())
	table_stack.add_child(color_table_scroll)
	color_table_rows = VBoxContainer.new()
	color_table_rows.name = "ColorTableRows"
	color_table_rows.custom_minimum_size.x = TABLE_CONTENT_WIDTH
	color_table_rows.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	color_table_rows.add_theme_constant_override("separation", 2)
	color_table_scroll.add_child(color_table_rows)
	var bottom = HBoxContainer.new()
	bottom.add_theme_constant_override("separation", 8)
	table_stack.add_child(bottom)
	color_table_page_label = _label("", 13, MUTED)
	color_table_page_label.name = "ColorTablePageLabel"
	color_table_page_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bottom.add_child(color_table_page_label)
	color_table_previous = _button("Previous")
	color_table_previous.pressed.connect(func(): color_table_page = maxi(0, color_table_page - 1); _render_color_table())
	bottom.add_child(color_table_previous)
	color_table_next = _button("Next")
	color_table_next.pressed.connect(func(): color_table_page += 1; _render_color_table())
	bottom.add_child(color_table_next)
	_render_color_table()
	_render_details()

# -------- Projects: ordered creature table and per-project checklist --------

# Drag near the table's top/bottom edge to scroll through long lists.
# Accept both otter and breeding-list drags from THIS project only.
func _process(delta: float) -> void:
	if selected_page != "projects" or not is_instance_valid(project_rows_scroll) or not project_rows_scroll.is_visible_in_tree():
		return
	var payload = get_viewport().gui_get_drag_data()
	if not (payload is Dictionary) or str(payload.get("type", "")) not in ["bloodline_project_row", "bloodline_project_list"] or str(payload.get("project_id", "")) != project_id:
		return
	var rect = project_rows_scroll.get_global_rect()
	var pointer = get_viewport().get_mouse_position()
	if not rect.has_point(pointer):
		return
	var edge = minf(64.0, rect.size.y * 0.22)
	var direction = 0.0
	if pointer.y < rect.position.y + edge:
		direction = -1.0
	elif pointer.y > rect.end.y - edge:
		direction = 1.0
	if direction != 0.0:
		var speed = 820.0 if str(payload.get("type", "")) == "bloodline_project_list" else 480.0
		project_rows_scroll.scroll_vertical += int(roundf(direction * speed * delta))

func _project_current() -> Dictionary:
	return ProjectPlans.get_projects(data).get(project_id, {})

func _save_project_data(next_data: Dictionary) -> bool:
	var saved = storage.save_data(next_data)
	if not saved.get("ok", false):
		_show_message("Could not save project", str(saved.get("error", "No changes were saved.")))
		return false
	data = next_data
	database_revision += 1
	return true

func _show_projects() -> void:
	selected_page = "projects"
	_activate_nav("projects")
	_workspace_setup()
	details.visible = false
	project_header_options = null
	project_expand_button = null
	project_heading = null
	project_color_table_button = null
	# Clear references before the old workspace controls are queued for deletion.
	project_picker = null
	project_table_rows = null
	project_add_list = null
	project_new_list_name = null
	project_notes_list = null
	project_rows_scroll = null
	var title_row = HBoxContainer.new()
	title_row.add_theme_constant_override("separation", 8)
	middle.add_child(title_row)
	var title = _label("▏ Projects", 26, TEXT)
	project_heading = title
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_row.add_child(title)
	var expand = _button("Expand workspace", true)
	expand.name = "ProjectExpandToggle"
	expand.tooltip_text = "Give notes and breeding lists more room."
	expand.pressed.connect(_toggle_project_focus)
	title_row.add_child(expand)
	project_expand_button = expand
	var go_back = _button("Color Table")
	go_back.pressed.connect(_show_color_table)
	title_row.add_child(go_back)
	project_color_table_button = go_back

	var options_row = HBoxContainer.new()
	project_header_options = options_row
	options_row.add_theme_constant_override("separation", 7)
	middle.add_child(options_row)
	project_selector = _option()
	project_selector.name = "ProjectSelector"
	project_selector.custom_minimum_size.x = 165
	project_selector.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	options_row.add_child(project_selector)
	var projects = ProjectPlans.get_projects(data)
	project_keys = projects.keys()
	project_keys.sort_custom(func(a, b): return str(projects[a].get("name", "")).to_lower() < str(projects[b].get("name", "")).to_lower())
	if not projects.has(project_id):
		project_id = str(project_keys[0]) if not project_keys.is_empty() else ""
	if project_keys.is_empty():
		project_selector.add_item("No projects yet")
		project_selector.disabled = true
	else:
		for key in project_keys:
			project_selector.add_item(str(projects[key].get("name", "Untitled project")))
		project_selector.select(project_keys.find(project_id))
	project_selector.item_selected.connect(func(index):
		if index >= 0 and index < project_keys.size():
			project_id = str(project_keys[index])
			project_add_list_id = ProjectPlans.MAIN_LIST_ID
			_show_projects()
	)
	project_name_field = _text_input("Project name: create or rename")
	project_name_field.name = "ProjectNewName"
	project_name_field.custom_minimum_size.x = 150
	project_name_field.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	project_name_field.max_length = 60
	project_name_field.text_submitted.connect(func(_submitted): _create_project())
	options_row.add_child(project_name_field)
	var create = _button("+ New project", true)
	create.name = "ProjectCreate"
	create.pressed.connect(_create_project)
	options_row.add_child(create)
	var rename = _button("Rename")
	rename.name = "ProjectRename"
	rename.disabled = project_id.is_empty()
	rename.tooltip_text = "Type a name in the field, then click Rename to rename the selected project."
	rename.pressed.connect(_rename_project)
	options_row.add_child(rename)
	var erase = _button("Delete")
	erase.name = "ProjectDelete"
	erase.disabled = project_id.is_empty()
	erase.tooltip_text = "Delete only the selected project. Your creature library will be untouched."
	erase.pressed.connect(_confirm_delete_project)
	options_row.add_child(erase)
	_apply_project_focus_layout()
	if project_id.is_empty():
		var welcome_panel = _panel(Color("#0a1e2b"), Color("#25485c"))
		welcome_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
		middle.add_child(welcome_panel)
		var welcome = VBoxContainer.new()
		welcome.add_theme_constant_override("separation", 12)
		welcome_panel.add_child(welcome)
		welcome.add_child(_label("Create your first project", 23, TEXT))
		var help = _label("Create a project to group creatures into breeding lists and keep notes.", 15, MUTED)
		help.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		welcome.add_child(help)
		return

	# The checklist sits at the top and can be collapsed per project.
	var note_panel = _panel(Color("#0a1f2d"), Color("#25495a"))
	var picker_open = bool(_project_current().get("picker_open", false))
	note_panel.visible = not (picker_open and project_picker_expanded)
	middle.add_child(note_panel)
	var note_stack = VBoxContainer.new()
	note_stack.add_theme_constant_override("separation", 5)
	note_panel.add_child(note_stack)
	var note_heading = HBoxContainer.new()
	note_heading.add_theme_constant_override("separation", 8)
	note_stack.add_child(note_heading)
	var notes = ProjectPlans.notes_of(_project_current())
	var done_count = 0
	for item in notes:
		if typeof(item) == TYPE_DICTIONARY and bool(item.get("done", false)):
			done_count += 1
	var open_notes = bool(_project_current().get("notes_open", true))
	var toggle_notes = _button(("▾ " if open_notes else "▸ ") + "Notes  ·  %s/%s done" % [done_count, notes.size()])
	toggle_notes.name = "ProjectNotesToggle"
	toggle_notes.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	toggle_notes.alignment = HORIZONTAL_ALIGNMENT_LEFT
	toggle_notes.pressed.connect(_project_toggle_notes)
	note_heading.add_child(toggle_notes)
	if open_notes:
		var notes_scroll = ScrollContainer.new()
		notes_scroll.name = "ProjectNotesScroll"
		notes_scroll.custom_minimum_size.y = mini(60, maxi(30, notes.size() * 30))
		notes_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
		note_stack.add_child(notes_scroll)
		project_notes_list = VBoxContainer.new()
		project_notes_list.name = "ProjectNotesList"
		project_notes_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		project_notes_list.add_theme_constant_override("separation", 4)
		notes_scroll.add_child(project_notes_list)
		_paged_scroll(notes_scroll)
		_render_project_notes()
		var note_entry = HBoxContainer.new()
		note_entry.add_theme_constant_override("separation", 6)
		note_stack.add_child(note_entry)
		project_note_input = _text_input("Add a task…")
		project_note_input.name = "ProjectNoteInput"
		project_note_input.max_length = 300
		project_note_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		project_note_input.text_submitted.connect(func(_v): _project_note_add())
		note_entry.add_child(project_note_input)
		var add_note = _button("+ Add note", true)
		add_note.name = "ProjectNoteAdd"
		add_note.pressed.connect(_project_note_add)
		note_entry.add_child(add_note)

	# Main table always gets the available vertical space.
	var table_panel = _panel(Color("#0a1c29"), Color("#203f50"))
	table_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	middle.add_child(table_panel)
	var table_stack = VBoxContainer.new()
	table_stack.add_theme_constant_override("separation", 5)
	table_panel.add_child(table_stack)
	var filter_row = HBoxContainer.new()
	filter_row.add_theme_constant_override("separation", 8)
	table_stack.add_child(filter_row)
	project_search = _text_input("Filter breeding lists…")
	project_search.name = "ProjectSearch"
	project_search.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	project_search.text = project_query
	project_search.text_changed.connect(func(value):
		project_query = value
		_render_project_board()
	)
	filter_row.add_child(project_search)
	project_species = _option()
	project_species.name = "ProjectSpecies"
	project_species.custom_minimum_size.x = 125
	project_species_keys = [""]
	project_species.add_item("All species")
	var names = {}
	for creature in data.get("creatures", []):
		var key = str(creature.get("species_key", ""))
		if not key.is_empty():
			names[key] = str(creature.get("species_name", "Unknown"))
	var keys = names.keys()
	keys.sort_custom(func(a, b): return str(names[a]).to_lower() < str(names[b]).to_lower())
	for key in keys:
		project_species_keys.append(str(key))
		project_species.add_item(str(names[key]))
	var selected = project_species_keys.find(project_species_key)
	if selected < 0:
		selected = 0
		project_species_key = ""
	project_species.select(selected)
	project_species.item_selected.connect(func(index):
		project_species_key = str(project_species_keys[index])
		_render_project_board()
	)
	filter_row.add_child(project_species)
	project_sex = _option()
	project_sex.name = "ProjectSex"
	for sex_label in ["Any sex", "Female", "Male", "Unknown"]:
		project_sex.add_item(sex_label)
	project_sex.select(maxi(0, ["All", "Female", "Male", "Unknown"].find(project_sex_filter)))
	project_sex.item_selected.connect(func(index):
		project_sex_filter = ["All", "Female", "Male", "Unknown"][index]
		_render_project_board()
	)
	filter_row.add_child(project_sex)
	var clear = _button("Clear filters")
	clear.name = "ProjectClearFilters"
	clear.pressed.connect(_clear_project_filters)
	filter_row.add_child(clear)

	var list_tools = HBoxContainer.new()
	list_tools.name = "ProjectListsToolbar"
	list_tools.add_theme_constant_override("separation", 7)
	table_stack.add_child(list_tools)
	var list_caption = _label("Breeding lists", 14, TEXT)
	list_tools.add_child(list_caption)
	project_new_list_name = _text_input("New list name (e.g. First Breed)")
	project_new_list_name.name = "ProjectNewListName"
	project_new_list_name.max_length = 42
	project_new_list_name.custom_minimum_size.x = 185
	project_new_list_name.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	project_new_list_name.text_submitted.connect(func(_value): _project_create_list())
	list_tools.add_child(project_new_list_name)
	var create_list_button = _button("+ New list", true)
	create_list_button.name = "ProjectNewListButton"
	create_list_button.tooltip_text = "Create a separate collapsible breeding batch inside this project."
	create_list_button.pressed.connect(_project_create_list)
	list_tools.add_child(create_list_button)
	project_board_status = _label("", 13, MUTED)
	project_board_status.clip_text = true
	table_stack.add_child(project_board_status)
	var rows_scroll = ScrollContainer.new()
	rows_scroll.name = "ProjectRowsScroll"
	rows_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	rows_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rows_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	table_stack.add_child(rows_scroll)
	project_rows_scroll = rows_scroll
	var rows_content = VBoxContainer.new()
	rows_content.custom_minimum_size.x = 746
	rows_content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rows_content.add_theme_constant_override("separation", 3)
	rows_scroll.add_child(rows_content)
	project_table_rows = VBoxContainer.new()
	project_table_rows.name = "ProjectTableRows"
	project_table_rows.add_theme_constant_override("separation", 3)
	rows_content.add_child(project_table_rows)
	_paged_scroll(rows_scroll)

	# Optional picker: it no longer steals half the table's width.
	var picker_panel = _panel(Color("#0a1f2d"), Color("#234759"))
	picker_panel.name = "ProjectCreaturePickerPanel"
	middle.add_child(picker_panel)
	var picker_stack = VBoxContainer.new()
	picker_stack.add_theme_constant_override("separation", 4)
	picker_panel.add_child(picker_stack)
	var picker_header = HBoxContainer.new()
	picker_header.add_theme_constant_override("separation", 6)
	picker_stack.add_child(picker_header)
	var toggle_picker = _button(("▾ " if picker_open else "▸ ") + "Add creatures from library")
	toggle_picker.clip_text = true
	toggle_picker.name = "ProjectPickerToggle"
	toggle_picker.alignment = HORIZONTAL_ALIGNMENT_LEFT
	toggle_picker.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	toggle_picker.pressed.connect(_project_toggle_picker)
	picker_header.add_child(toggle_picker)
	project_add_list = _option()
	project_add_list.name = "ProjectPickerList"
	project_add_list.tooltip_text = "Choose which breeding list receives new creatures."
	project_add_list.custom_minimum_size.x = 142
	project_add_list.fit_to_longest_item = false
	project_add_list.clip_text = true
	var add_to_ids: Array = []
	for entry in ProjectPlans.lists_of(_project_current()):
		project_add_list.add_item("Add to: " + str(entry["name"]))
		add_to_ids.append(str(entry["id"]))
	if not add_to_ids.has(project_add_list_id):
		project_add_list_id = ProjectPlans.MAIN_LIST_ID
	project_add_list.select(add_to_ids.find(project_add_list_id))
	project_add_list.item_selected.connect(func(index):
		if index >= 0 and index < add_to_ids.size():
			project_add_list_id = str(add_to_ids[index])
	)
	picker_header.add_child(project_add_list)
	project_add_list.visible = picker_open
	project_picker_count = _label("", 12, MUTED)
	project_picker_count.visible = picker_open
	picker_header.add_child(project_picker_count)
	if picker_open:
		var expand_picker = _button("Restore picker" if project_picker_expanded else "Expand picker")
		expand_picker.name = "ProjectPickerExpand"
		picker_header.add_child(expand_picker)
		picker_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL if project_picker_expanded else Control.SIZE_FILL
		picker_panel.size_flags_stretch_ratio = 4
		expand_picker.pressed.connect(func():
			project_picker_expanded = not project_picker_expanded
			note_panel.visible = not project_picker_expanded
			picker_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL if project_picker_expanded else Control.SIZE_FILL
			expand_picker.text = "Restore picker" if project_picker_expanded else "Expand picker"
		)
		var filters = HFlowContainer.new()
		filters.add_theme_constant_override("h_separation", 6)
		filters.add_theme_constant_override("v_separation", 4)
		picker_stack.add_child(filters)
		var name_filter = _text_input("Creature name")
		name_filter.name = "ProjectPickerName"
		name_filter.custom_minimum_size.x = 135
		name_filter.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		name_filter.text = project_picker_name
		name_filter.clear_button_enabled = true
		name_filter.text_changed.connect(func(query):
			project_picker_name = query
			_render_project_picker()
		)
		filters.add_child(name_filter)
		var sex_filter = _option()
		sex_filter.name = "ProjectPickerSex"
		var sexes = ["All", "Female", "Male", "Unknown"]
		for sex in ["Any sex", "Female", "Male", "Unknown"]:
			sex_filter.add_item(sex)
		sex_filter.select(sexes.find(project_picker_sex))
		sex_filter.item_selected.connect(func(index):
			project_picker_sex = sexes[index]
			_render_project_picker()
		)
		filters.add_child(sex_filter)
		var level_filter = _text_input("Exact level")
		level_filter.name = "ProjectPickerLevel"
		level_filter.custom_minimum_size.x = 118
		level_filter.text = project_picker_level
		level_filter.clear_button_enabled = true
		level_filter.text_changed.connect(func(query):
			project_picker_level = query
			_render_project_picker()
		)
		filters.add_child(level_filter)
		var picker_scroll = ScrollContainer.new()
		picker_scroll.name = "ProjectPickerScroll"
		picker_scroll.custom_minimum_size.y = 82
		picker_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
		picker_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
		picker_stack.add_child(picker_scroll)
		project_picker = VBoxContainer.new()
		project_picker.name = "ProjectPicker"
		project_picker.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		project_picker.add_theme_constant_override("separation", 3)
		picker_scroll.add_child(project_picker)
		_paged_scroll(picker_scroll)
	_render_project_picker()
	_render_project_board()

func _toggle_project_focus() -> void:
	if selected_page != "projects":
		return
	project_focus_expanded = not project_focus_expanded
	_apply_project_focus_layout()

func _apply_project_focus_layout() -> void:
	if selected_page != "projects":
		return
	# The same scene controls remain in place: no reparents, reloads, data writes,
	# filter resets, selection changes, or loss of table/notes scroll positions.
	if is_instance_valid(sidebar_panel):
		sidebar_panel.visible = not project_focus_expanded
	if is_instance_valid(project_header_options):
		project_header_options.visible = not project_focus_expanded
	if is_instance_valid(project_color_table_button):
		project_color_table_button.visible = not project_focus_expanded
	if is_instance_valid(project_expand_button):
		project_expand_button.text = "Restore layout" if project_focus_expanded else "Expand workspace"
		project_expand_button.tooltip_text = "Return to the normal BloodlineBank layout" if project_focus_expanded else "Use almost the entire window for planning"
	if is_instance_valid(project_heading):
		project_heading.text = "▏ %s" % str(_project_current().get("name", "Projects")) if project_focus_expanded else "▏ Projects"
		project_heading.add_theme_font_size_override("font_size", 21 if project_focus_expanded else 26)
	if is_instance_valid(middle):
		middle.add_theme_constant_override("separation", 7 if project_focus_expanded else 8)

func _create_project() -> void:
	var name = project_name_field.text.strip_edges()
	if name.is_empty():
		_show_message("Project name needed", "Enter a name before creating a project.")
		return
	var next_data = data.duplicate(true)
	var projects = ProjectPlans.get_projects(next_data)
	for existing in projects.values():
		if str(existing.get("name", "")).to_lower() == name.to_lower():
			_show_message("Project already exists", "Choose another project name.")
			return
	var key = "project_%s_%s" % [int(Time.get_unix_time_from_system()), Time.get_ticks_usec()]
	while projects.has(key):
		key += "_next"
	projects[key] = {"name": name, "members": [], "lists": [], "notes": [], "notes_open": true, "picker_open": true}
	next_data["projects"] = projects
	if _save_project_data(next_data):
		project_id = key
		project_add_list_id = ProjectPlans.MAIN_LIST_ID
		if project_species_key.is_empty() and not color_table_species_key.is_empty():
			project_species_key = color_table_species_key
		_show_projects()

func _rename_project() -> void:
	if project_id.is_empty():
		return
	var name = project_name_field.text.strip_edges()
	if name.is_empty():
		_show_message("Project name needed", "Type the new name in the project name field first.")
		return
	var next_data = data.duplicate(true)
	var projects = ProjectPlans.get_projects(next_data)
	for key in projects:
		if str(key) != project_id and str(projects[key].get("name", "")).to_lower() == name.to_lower():
			_show_message("Name in use", "Another project already uses that name.")
			return
	projects[project_id]["name"] = name
	if _save_project_data(next_data):
		_show_projects()

func _confirm_delete_project() -> void:
	if project_id.is_empty():
		return
	pending_project_delete_id = project_id
	confirm_project_delete.dialog_text = "Delete project '%s' including its saved row order and notes?\n\nLibrary creatures will NOT be deleted." % str(_project_current().get("name", "Untitled"))
	confirm_project_delete.popup_centered()

func _delete_project_confirmed() -> void:
	var next_data = data.duplicate(true)
	var projects = ProjectPlans.get_projects(next_data)
	if not projects.has(pending_project_delete_id):
		return
	projects.erase(pending_project_delete_id)
	next_data["projects"] = projects
	if _save_project_data(next_data):
		project_id = ""
		project_add_list_id = ProjectPlans.MAIN_LIST_ID
		_show_projects()
	pending_project_delete_id = ""

func _project_set_section(key: String, value: bool) -> void:
	if project_id.is_empty():
		return
	var next_data = data.duplicate(true)
	next_data["projects"][project_id][key] = value
	if _save_project_data(next_data):
		_show_projects()

func _project_toggle_notes() -> void:
	_project_set_section("notes_open", not bool(_project_current().get("notes_open", true)))

func _project_toggle_picker() -> void:
	_project_set_section("picker_open", not bool(_project_current().get("picker_open", false)))

func _clear_project_filters() -> void:
	project_query = ""
	project_species_key = ""
	project_sex_filter = "All"
	_show_projects()

func _project_creature_matches(creature: Dictionary, alias: String = "") -> bool:
	if creature.is_empty():
		return project_species_key.is_empty() and project_sex_filter == "All" and project_query.is_empty()
	if not project_species_key.is_empty() and str(creature.get("species_key", "")) != project_species_key:
		return false
	var sex = str(creature.get("sex", "Unknown"))
	if project_sex_filter != "All" and sex != project_sex_filter and not (project_sex_filter == "Unknown" and sex != "Female" and sex != "Male"):
		return false
	var q = project_query.strip_edges().to_lower()
	if q.is_empty():
		return true
	var searchable = (alias + " " + str(creature.get("name", "")) + " " + str(creature.get("species_name", "")) + " " + sex + " " + str(creature.get("level", ""))).to_lower()
	for i in range(6):
		var color_id = ColorTableScript.confirmed_id(creature, i)
		if color_id != null:
			searchable += " " + str(color_id) + " " + str(palette.get_color(int(color_id)).get("name", ""))
	return searchable.contains(q)

func _project_filtered_creatures() -> Array:
	var answer: Array = []
	var query = project_picker_name.strip_edges().to_lower()
	var level = project_picker_level.strip_edges()
	for creature in data.get("creatures", []):
		if typeof(creature) != TYPE_DICTIONARY:
			continue
		var sex = str(creature.get("sex", "Unknown"))
		if sex not in ["Male", "Female"]:
			sex = "Unknown"
		if project_picker_sex != "All" and sex != project_picker_sex:
			continue
		if not query.is_empty() and not str(creature.get("name", "")).to_lower().contains(query):
			continue
		if not level.is_empty() and (not level.is_valid_int() or creature.get("level") == null or float(creature["level"]) != int(level)):
			continue
		answer.append(creature)
	return answer

func _creature_region_chip(creature: Dictionary, index: int, large: bool = false) -> Control:
	var unused = ColorTableScript.is_unused(creature, index)
	var region = {"state": "empty", "id": null, "raw": []} if unused else ColorTableScript.region_at(creature, index).duplicate()
	if not unused and ColorTableScript.confirmed_id(creature, index) == null:
		region["id"] = null
	var chip = _swatch(region, large)
	if unused:
		chip.get_child(0).text = "—"
		chip.tooltip_text = "Region %s: unused on this species" % index
	else:
		chip.tooltip_text = "Region %s: %s" % [index, chip.tooltip_text]
	chip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return chip

func _project_creature_tooltip(creature: Dictionary) -> String:
	var output = "%s · Level %s · %s" % [creature.get("name", "Unnamed"), creature.get("level", "—"), creature.get("sex", "Unknown")]
	for i in range(6):
		var id = ColorTableScript.confirmed_id(creature, i)
		var val = "unused" if ColorTableScript.is_unused(creature, i) else "? (unknown)" if id == null else "%s %s" % [id, palette.get_color(int(id)).get("name", "")]
		output += "\nR%s: %s" % [i, val]
	return output

func _render_project_picker() -> void:
	var candidates = _project_filtered_creatures()
	var project = _project_current()
	var placed = ProjectPlans.members_of(project).size()
	if is_instance_valid(project_picker_count):
		project_picker_count.text = "%s found · %s added" % [candidates.size(), placed]
	if not is_instance_valid(project_picker):
		return
	_clear(project_picker)
	if candidates.is_empty():
		project_picker.add_child(_label("No creatures match these filters.", 14, MUTED))
		return
	for creature in candidates.slice(0, 125):
		var id = str(creature.get("local_id", ""))
		if id.is_empty():
			continue
		var item = _panel(Color("#102838"), Color("#284c5c"))
		item.name = "ProjectPickerCreature"
		project_picker.add_child(item)
		var row = HBoxContainer.new()
		row.add_theme_constant_override("separation", 6)
		item.add_child(row)
		var picture = _preview(creature, Vector2(32, 32))
		picture.mouse_filter = Control.MOUSE_FILTER_IGNORE
		row.add_child(picture)
		var item_name = _label("%s  ·  L%s  ·  %s" % [creature.get("name", "Unnamed"), creature.get("level", "—"), creature.get("sex", "Unknown")], 13, TEXT)
		item_name.custom_minimum_size.x = 100
		item_name.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		item_name.clip_text = true
		item_name.tooltip_text = _project_creature_tooltip(creature)
		row.add_child(item_name)
		for i in range(6):
			row.add_child(_creature_region_chip(creature, i))
		var already = ProjectPlans.member_index(project, id) != -1
		var add = _button("Added" if already else "+ Add")
		add.name = "ProjectPickerAdd"
		add.disabled = already
		add.custom_minimum_size.x = 65
		add.pressed.connect(func(): _project_add_creature(id))
		row.add_child(add)
	if candidates.size() > 125:
		project_picker.add_child(_label("First 125 shown. Narrow the search to see more.", 12, MUTED))

func _project_add_creature(creature_id: String, _position: Vector2 = Vector2.ZERO) -> void:
	if project_id.is_empty() or ProjectPlans.creature_by_id(data.get("creatures", []), creature_id).is_empty():
		return
	var next_data = data.duplicate(true)
	var project: Dictionary = next_data["projects"][project_id]
	var destination = project_add_list_id if ProjectPlans.list_exists(project, project_add_list_id) else ProjectPlans.MAIN_LIST_ID
	if ProjectPlans.add_member(project, creature_id, Vector2.ZERO, destination):
		ProjectPlans.set_list_open(project, destination, true)
		if _save_project_data(next_data):
			_render_project_picker()
			_render_project_board()

func _project_remove_creature(creature_id: String) -> void:
	if project_id.is_empty():
		return
	var next_data = data.duplicate(true)
	var project: Dictionary = next_data["projects"][project_id]
	if ProjectPlans.remove_member(project, creature_id) and _save_project_data(next_data):
		_render_project_picker()
		_render_project_board()

func _project_move_creature(source_id: String, target_id: String, after: bool) -> void:
	if project_id.is_empty():
		return
	var next_data = data.duplicate(true)
	var project: Dictionary = next_data["projects"][project_id]
	if ProjectPlans.move_member_to(project, source_id, target_id, after) and _save_project_data(next_data):
		_render_project_board()

func _project_move_one(creature_id: String, delta: int) -> void:
	if project_id.is_empty():
		return
	var next_data = data.duplicate(true)
	var project: Dictionary = next_data["projects"][project_id]
	if ProjectPlans.move_member_by(project, creature_id, delta) and _save_project_data(next_data):
		_render_project_board()

# Breeding list CRUD. The library is never modified by these actions.
func _project_create_list() -> void:
	if project_id.is_empty() or not is_instance_valid(project_new_list_name):
		return
	var name_value = project_new_list_name.text.strip_edges()
	if name_value.is_empty():
		return
	var next_data = data.duplicate(true)
	var project: Dictionary = next_data["projects"][project_id]
	var new_id = "batch_%s" % Time.get_ticks_usec()
	if not ProjectPlans.add_list(project, new_id, name_value):
		_show_message("Cannot create list", "Choose a different, non-empty name.")
		return
	if _save_project_data(next_data):
		project_add_list_id = new_id
		_show_projects()

func _project_rename_list(owner_project: String, list_id: String, next_name: String) -> void:
	if project_id != owner_project or list_id == ProjectPlans.MAIN_LIST_ID:
		return
	var next_data = data.duplicate(true)
	var project: Dictionary = next_data["projects"][project_id]
	if ProjectPlans.rename_list(project, list_id, next_name) and _save_project_data(next_data):
		# Picker entries also display these names.
		_show_projects()

func _project_toggle_list(list_id: String) -> void:
	if project_id.is_empty():
		return
	var next_data = data.duplicate(true)
	var project: Dictionary = next_data["projects"][project_id]
	var is_open = true
	for entry in ProjectPlans.lists_of(project):
		if str(entry["id"]) == list_id:
			is_open = bool(entry.get("open", true))
			break
	if ProjectPlans.set_list_open(project, list_id, not is_open) and _save_project_data(next_data):
		_render_project_board()

func _project_confirm_delete_list(list_id: String) -> void:
	if list_id == ProjectPlans.MAIN_LIST_ID or not ProjectPlans.list_exists(_project_current(), list_id):
		return
	pending_project_list_delete_project_id = project_id
	pending_project_list_delete_id = list_id
	var name_value = "List"
	for entry in ProjectPlans.lists_of(_project_current()):
		if str(entry["id"]) == list_id:
			name_value = str(entry["name"])
	var amount = ProjectPlans.members_in_list(_project_current(), list_id).size()
	confirm_project_list_delete.dialog_text = "Delete '%s'?\n\nIts %s creatures will move to Main List. No creature or checklist note will be deleted." % [name_value, amount]
	confirm_project_list_delete.popup_centered()

func _project_delete_list_confirmed() -> void:
	if project_id.is_empty() or project_id != pending_project_list_delete_project_id:
		return
	var next_data = data.duplicate(true)
	var project: Dictionary = next_data["projects"][project_id]
	if ProjectPlans.remove_list(project, pending_project_list_delete_id) and _save_project_data(next_data):
		if project_add_list_id == pending_project_list_delete_id:
			project_add_list_id = ProjectPlans.MAIN_LIST_ID
		_show_projects()
	pending_project_list_delete_id = ""
	pending_project_list_delete_project_id = ""

# List headers themselves are draggable now (including Main List), and the
# saved list_order changes ONLY header order, not membership or creature data.
func _project_reorder_list(source_list_id: String, target_list_id: String, after: bool) -> void:
	if project_id.is_empty():
		return
	var next_data = data.duplicate(true)
	var project: Dictionary = next_data["projects"][project_id]
	if ProjectPlans.move_list_to(project, source_list_id, target_list_id, after) and _save_project_data(next_data):
		_render_project_board()
		call_deferred("_reveal_project_list", source_list_id, project_id)

# Forgiving shortcut: dropping a list on ANY otter row in another group puts
# the dragged list adjacent to that entire group, in the direction of travel.
# No need to aim for a distant 50px header above dozens of creature rows.
func _project_reorder_list_onto_group(source_list_id: String, target_list_id: String) -> void:
	if project_id.is_empty() or source_list_id == target_list_id:
		return
	var order: Array = []
	for entry in ProjectPlans.lists_of(_project_current()):
		order.append(str(entry["id"]))
	var source_index = order.find(source_list_id)
	var target_index = order.find(target_list_id)
	if source_index < 0 or target_index < 0:
		return
	_project_reorder_list(source_list_id, target_list_id, source_index < target_index)

func _project_move_list_by(list_id: String, delta: int) -> void:
	if project_id.is_empty():
		return
	var next_data = data.duplicate(true)
	var project: Dictionary = next_data["projects"][project_id]
	if ProjectPlans.move_list_by(project, list_id, delta) and _save_project_data(next_data):
		_render_project_board()
		call_deferred("_reveal_project_list", list_id, project_id)

func _reveal_project_list(list_id: String, expected_project: String) -> void:
	await get_tree().process_frame
	if project_id != expected_project or not is_instance_valid(project_table_rows) or not is_instance_valid(project_rows_scroll):
		return
	for header in project_table_rows.get_children():
		if header.name != "ProjectListHeader":
			continue
		var toggle = header.get_node_or_null("ProjectListToggle")
		if toggle != null and str(toggle.get("list_id")) == list_id:
			project_rows_scroll.ensure_control_visible(toggle)
			return

# List headers accept otter drops, including empty and collapsed lists.
# The model keeps one reference per creature; dropping NEVER creates a copy.
func _project_drop_into_list(creature_id: String, list_id: String) -> void:
	if project_id.is_empty():
		return
	var next_data = data.duplicate(true)
	var project: Dictionary = next_data["projects"][project_id]
	if not ProjectPlans.list_exists(project, list_id):
		return
	var index = ProjectPlans.member_index(project, creature_id)
	if index < 0:
		return
	var current_list = ProjectPlans.member_list_id(project, ProjectPlans.members_of(project)[index])
	var changed = false
	if current_list == list_id:
		# Same-group drop means put this otter at the bottom of that group.
		changed = ProjectPlans.move_member_to_position(project, creature_id, ProjectPlans.members_in_list(project, list_id).size())
	else:
		changed = ProjectPlans.move_member_to_list(project, creature_id, list_id)
	if not changed:
		return
	ProjectPlans.set_list_open(project, list_id, true)
	if _save_project_data(next_data):
		_render_project_board()

func _project_move_to_list(creature_id: String, list_id: String) -> void:
	if project_id.is_empty():
		return
	var next_data = data.duplicate(true)
	var project: Dictionary = next_data["projects"][project_id]
	if ProjectPlans.move_member_to_list(project, creature_id, list_id):
		ProjectPlans.set_list_open(project, list_id, true)
		if _save_project_data(next_data):
			_render_project_board()

func _project_set_position(owner_project: String, creature_id: String, raw_position: String) -> void:
	if project_id.is_empty() or project_id != owner_project:
		return
	var trimmed = raw_position.strip_edges()
	if trimmed.is_empty() or not trimmed.is_valid_int():
		return
	var next_data = data.duplicate(true)
	var project: Dictionary = next_data["projects"][project_id]
	if ProjectPlans.move_member_to_position(project, creature_id, int(trimmed)):
		if _save_project_data(next_data):
			_render_project_board()

# Preserved for reading existing project-only names in search and display.
func _project_set_alias(owner_project_id: String, creature_id: String, value: String) -> void:
	if project_id.is_empty() or project_id != owner_project_id:
		return
	var next_data = data.duplicate(true)
	var project: Dictionary = next_data["projects"][project_id]
	if ProjectPlans.rename_member(project, creature_id, value) and _save_project_data(next_data):
		_render_project_board()

func _project_table_header(parent: VBoxContainer) -> void:
	var table_header = HBoxContainer.new()
	table_header.name = "ProjectTableHeader"
	table_header.add_theme_constant_override("separation", 4)
	parent.add_child(table_header)
	for spec in [["Move", 32], ["Creature", 154], ["Position", 55], ["Lvl", 34], ["Sex", 28]]:
		var heading = _label(str(spec[0]), 12, MUTED)
		heading.custom_minimum_size.x = int(spec[1])
		if spec[0] == "Creature":
			heading.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		table_header.add_child(heading)
	for i in range(6):
		var region_head = _label("R%s" % i, 12, MUTED)
		region_head.custom_minimum_size.x = 30
		table_header.add_child(region_head)
	var list_head = _label("Move to list", 12, MUTED)
	list_head.custom_minimum_size.x = 105
	table_header.add_child(list_head)
	var actions = _label("Order", 12, MUTED)
	actions.custom_minimum_size.x = 64
	table_header.add_child(actions)
	var remove_heading = _label("", 12, MUTED)
	remove_heading.custom_minimum_size.x = 32
	table_header.add_child(remove_heading)

func _render_project_group_header(group: Dictionary, members: Array, parent: VBoxContainer) -> void:
	var list_id = str(group["id"])
	var name_value = str(group["name"])
	var open_list = bool(group.get("open", true))
	var female = 0
	var male = 0
	for member in members:
		var creature = ProjectPlans.creature_by_id(data.get("creatures", []), str(member.get("id", "")))
		if str(creature.get("sex", "")) == "Female":
			female += 1
		elif str(creature.get("sex", "")) == "Male":
			male += 1
	var line = HBoxContainer.new()
	line.name = "ProjectListHeader"
	line.add_theme_constant_override("separation", 6)
	parent.add_child(line)
	var toggle = ProjectListDropTargetScript.new()
	toggle.text = "↕  " + ("▾ " if open_list else "▸ ") + "%s  ·  %s creatures  ·  ♀ %s  ♂ %s" % [name_value, members.size(), female, male]
	toggle.name = "ProjectListToggle"
	toggle.project_id = project_id
	toggle.list_id = list_id
	toggle.list_name = name_value
	toggle.allow_list_reorder = true
	toggle.mouse_default_cursor_shape = Control.CURSOR_MOVE
	toggle.custom_minimum_size.y = 34
	toggle.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	toggle.alignment = HORIZONTAL_ALIGNMENT_LEFT
	toggle.tooltip_text = "Click to show or hide this list. Drag the heading to reorder lists, or drop a creature here to move it into the list."
	toggle.add_theme_font_size_override("font_size", 15)
	toggle.add_theme_color_override("font_color", TEXT)
	toggle.add_theme_color_override("font_hover_color", TEXT)
	toggle.add_theme_stylebox_override("normal", _style(Color("#103747"), Color("#2f8fa2"), 4))
	toggle.add_theme_stylebox_override("hover", _style(Color("#176071"), CYAN, 4))
	toggle.add_theme_stylebox_override("pressed", _style(Color("#104454"), CYAN, 4))
	toggle.pressed.connect(func(): _project_toggle_list(list_id))
	toggle.creature_dropped.connect(_project_drop_into_list)
	toggle.list_dropped.connect(_project_reorder_list)
	line.add_child(toggle)
	# Explicit fallback when dragging through a long project is inconvenient.
	var group_order: Array = []
	for entry in ProjectPlans.lists_of(_project_current()):
		group_order.append(str(entry["id"]))
	var group_pos = group_order.find(list_id)
	var group_up = _button("↑")
	group_up.name = "ProjectListUp"
	group_up.custom_minimum_size.x = 31
	group_up.disabled = group_pos <= 0
	group_up.tooltip_text = "Move this entire breeding list up one section"
	group_up.pressed.connect(func(): _project_move_list_by(list_id, -1))
	line.add_child(group_up)
	var group_down = _button("↓")
	group_down.name = "ProjectListDown"
	group_down.custom_minimum_size.x = 31
	group_down.disabled = group_pos < 0 or group_pos >= group_order.size() - 1
	group_down.tooltip_text = "Move this entire breeding list down one section"
	group_down.pressed.connect(func(): _project_move_list_by(list_id, 1))
	line.add_child(group_down)
	if list_id != ProjectPlans.MAIN_LIST_ID:
		var rename = _text_input("List name")
		rename.name = "ProjectListRename"
		rename.custom_minimum_size.x = 165
		rename.max_length = 42
		rename.text = name_value
		rename.tooltip_text = "Rename this breeding batch. Press Enter or click elsewhere to save."
		var owner_id = project_id
		rename.text_submitted.connect(func(value): _project_rename_list(owner_id, list_id, value))
		rename.focus_exited.connect(func():
			if is_instance_valid(rename):
				_project_rename_list(owner_id, list_id, rename.text)
		)
		line.add_child(rename)
		var remove_list_btn = _button("Delete list")
		remove_list_btn.name = "ProjectListDelete"
		remove_list_btn.tooltip_text = "Move all creatures to Main List; never delete their library records."
		remove_list_btn.pressed.connect(func(): _project_confirm_delete_list(list_id))
		line.add_child(remove_list_btn)

func _render_project_creature_row(member: Dictionary, project: Dictionary, group_id: String, group_members: Array, ordinal: int) -> void:
	var id = str(member.get("id", ""))
	var creature = ProjectPlans.creature_by_id(data.get("creatures", []), id)
	var row = ProjectTableRowScript.new()
	row.name = "ProjectTableRow"
	row.project_id = project_id
	row.creature_id = id
	row.list_id = group_id
	row.reordered.connect(_project_move_creature)
	row.list_dropped_on_group.connect(_project_reorder_list_onto_group)
	row.add_theme_stylebox_override("panel", _style(Color("#102636") if ordinal % 2 == 0 else Color("#0d2231"), Color("#204253"), 4))
	project_table_rows.add_child(row)
	var line = HBoxContainer.new()
	line.add_theme_constant_override("separation", 4)
	line.mouse_filter = Control.MOUSE_FILTER_PASS
	row.add_child(line)
	var drag = ProjectRowHandleScript.new()
	drag.name = "ProjectRowDragHandle"
	drag.text = "↕"
	drag.project_id = project_id
	drag.creature_id = id
	drag.mouse_filter = Control.MOUSE_FILTER_STOP
	drag.custom_minimum_size = Vector2(32, 31)
	drag.add_theme_color_override("font_color", Appearance.accent(appearance))
	drag.add_theme_font_size_override("font_size", 22)
	drag.tooltip_text = "Drag me or the otter picture/name onto a wide breeding-list heading, or another otter row."
	line.add_child(drag)
	var creature_box = ProjectRowDragAreaScript.new()
	creature_box.name = "ProjectRowDragArea"
	creature_box.project_id = project_id
	creature_box.creature_id = id
	creature_box.list_id = group_id
	creature_box.creature_label = str(creature.get("name", "Missing creature"))
	creature_box.reordered.connect(_project_move_creature)
	creature_box.list_dropped_on_group.connect(_project_reorder_list_onto_group)
	creature_box.custom_minimum_size.x = 154
	creature_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	creature_box.add_theme_constant_override("separation", 5)
	creature_box.mouse_filter = Control.MOUSE_FILTER_STOP
	creature_box.mouse_default_cursor_shape = Control.CURSOR_MOVE
	creature_box.tooltip_text = "Grab picture/name and drag onto ANY breeding-list heading, even an empty or collapsed one."
	line.add_child(creature_box)
	if not creature.is_empty():
		var preview = _preview(creature, Vector2(26, 26))
		preview.mouse_filter = Control.MOUSE_FILTER_IGNORE
		creature_box.add_child(preview)
	var alias_value = str(member.get("alias", ""))
	var name_value = str(creature.get("name", "Missing creature"))
	var displayed_name = alias_value if not alias_value.is_empty() else name_value
	var label_name = _label(displayed_name, 13, RED if creature.is_empty() else TEXT)
	label_name.custom_minimum_size.x = 72
	label_name.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	label_name.clip_text = true
	label_name.tooltip_text = ("Library: " + name_value + ("\nProject label: " + alias_value if not alias_value.is_empty() else "") + "\n" + _project_creature_tooltip(creature)) if not creature.is_empty() else "Creature missing from library"
	label_name.mouse_filter = Control.MOUSE_FILTER_IGNORE
	creature_box.add_child(label_name)
	var position = _text_input("#")
	position.name = "ProjectRowPosition"
	position.custom_minimum_size.x = 55
	position.max_length = 5
	position.text = str(ProjectPlans.member_position(project, id))
	position.alignment = HORIZONTAL_ALIGNMENT_CENTER
	position.tooltip_text = "Position within THIS list. Type 1 and press Enter to move to the top; type 5 for fifth."
	var owner = project_id
	position.text_submitted.connect(func(value):
		_project_set_position(owner, id, value)
		if is_instance_valid(position) and not position.is_queued_for_deletion():
			position.text = str(ProjectPlans.member_position(_project_current(), id))
	)
	position.focus_exited.connect(func():
		if is_instance_valid(position) and not position.is_queued_for_deletion():
			_project_set_position(owner, id, position.text)
			# Invalid input or an unchanged number should not redraw the whole table.
			if is_instance_valid(position) and not position.is_queued_for_deletion():
				position.text = str(ProjectPlans.member_position(_project_current(), id))
	)
	line.add_child(position)
	var level = _label(str(creature.get("level", "—")), 13, TEXT)
	level.custom_minimum_size.x = 34
	level.mouse_filter = Control.MOUSE_FILTER_IGNORE
	line.add_child(level)
	var sex = str(creature.get("sex", "Unknown"))
	var gender_label: Control = SexSymbolScript.new(sex) if sex == "Female" or sex == "Male" else _label("?", 17, MUTED)
	gender_label.custom_minimum_size.x = 28
	gender_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	line.add_child(gender_label)
	for i in range(6):
		var chip = _creature_region_chip(creature, i) if not creature.is_empty() else _swatch({"state":"unknown", "id":null, "raw":[]}, false)
		chip.custom_minimum_size.x = 30
		line.add_child(chip)
	var transfer = _option()
	transfer.name = "ProjectRowList"
	transfer.custom_minimum_size.x = 105
	transfer.fit_to_longest_item = false
	transfer.tooltip_text = "Move this otter to another breeding list without duplicating it."
	var group_ids: Array = []
	for group in ProjectPlans.lists_of(project):
		transfer.add_item(str(group["name"]))
		group_ids.append(str(group["id"]))
	transfer.select(group_ids.find(group_id))
	transfer.item_selected.connect(func(index):
		if index >= 0 and index < group_ids.size():
			_project_move_to_list(id, str(group_ids[index]))
	)
	line.add_child(transfer)
	var order_actions = HBoxContainer.new()
	order_actions.custom_minimum_size.x = 64
	order_actions.add_theme_constant_override("separation", 1)
	line.add_child(order_actions)
	var up = _button("↑")
	up.name = "ProjectRowUp"
	up.custom_minimum_size.x = 29
	up.disabled = ProjectPlans.member_position(project, id) == 1
	up.tooltip_text = "Move up within this list"
	up.pressed.connect(func(): _project_move_one(id, -1))
	order_actions.add_child(up)
	var down = _button("↓")
	down.name = "ProjectRowDown"
	down.custom_minimum_size.x = 29
	down.disabled = ProjectPlans.member_position(project, id) == group_members.size()
	down.tooltip_text = "Move down within this list"
	down.pressed.connect(func(): _project_move_one(id, 1))
	order_actions.add_child(down)
	var remove = _button("×")
	remove.name = "ProjectRowRemove"
	remove.tooltip_text = "Remove from the project, NOT from your creature library."
	remove.custom_minimum_size.x = 32
	remove.pressed.connect(func(): _project_remove_creature(id))
	line.add_child(remove)

func _render_project_board() -> void:
	if not is_instance_valid(project_table_rows):
		return
	var previous_scroll = project_rows_scroll.scroll_vertical if is_instance_valid(project_rows_scroll) else 0
	_clear(project_table_rows)
	var project = _project_current()
	var members = ProjectPlans.members_of(project)
	var lists = ProjectPlans.lists_of(project)
	var female = 0
	var male = 0
	var missing = 0
	var shown = 0
	for member in members:
		if typeof(member) != TYPE_DICTIONARY:
			continue
		var creature = ProjectPlans.creature_by_id(data.get("creatures", []), str(member.get("id", "")))
		if creature.is_empty():
			missing += 1
		elif str(creature.get("sex", "")) == "Male":
			male += 1
		elif str(creature.get("sex", "")) == "Female":
			female += 1
	for group in lists:
		var group_id = str(group["id"])
		var group_members = ProjectPlans.members_in_list(project, group_id)
		_render_project_group_header(group, group_members, project_table_rows)
		if not bool(group.get("open", true)):
			continue
		_project_table_header(project_table_rows)
		var local_shown = 0
		for member in group_members:
			var creature = ProjectPlans.creature_by_id(data.get("creatures", []), str(member.get("id", "")))
			if not _project_creature_matches(creature, str(member.get("alias", ""))):
				continue
			local_shown += 1
			shown += 1
			_render_project_creature_row(member, project, group_id, group_members, local_shown)
		if group_members.is_empty():
			var empty_target = ProjectListDropTargetScript.new()
			empty_target.name = "ProjectEmptyListDropTarget"
			empty_target.project_id = project_id
			empty_target.list_id = group_id
			empty_target.text = "↧  Drop a creature here to add it to this list"
			empty_target.alignment = HORIZONTAL_ALIGNMENT_CENTER
			empty_target.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			empty_target.custom_minimum_size.y = 68
			empty_target.add_theme_font_size_override("font_size", 14)
			empty_target.add_theme_color_override("font_color", Appearance.accent(appearance))
			empty_target.add_theme_stylebox_override("normal", _style(Color("#0c2838"), Color("#2e7790"), 4))
			empty_target.add_theme_stylebox_override("hover", _style(Color("#155266"), CYAN, 4))
			empty_target.creature_dropped.connect(_project_drop_into_list)
			empty_target.pressed.connect(func(): _project_toggle_list(group_id))
			project_table_rows.add_child(empty_target)
		elif local_shown == 0:
			project_table_rows.add_child(_label("No creatures match the list filters.", 13, MUTED))
	if is_instance_valid(project_board_status):
		project_board_status.text = "%s lists · %s creatures · ♀ %s · ♂ %s" % [lists.size(), members.size(), female, male]
		if shown != members.size() - missing:
			project_board_status.text += " · %s shown" % shown
		if missing > 0:
			project_board_status.text += " · %s missing" % missing
	call_deferred("_restore_project_scroll", previous_scroll, project_id)

func _restore_project_scroll(position: int, project_key: String) -> void:
	await get_tree().process_frame
	if is_instance_valid(project_rows_scroll) and project_id == project_key:
		project_rows_scroll.scroll_vertical = position

func _render_project_notes() -> void:
	if not is_instance_valid(project_notes_list):
		return
	_clear(project_notes_list)
	var notes = ProjectPlans.notes_of(_project_current())
	if notes.is_empty():
		project_notes_list.add_child(_label("Nothing planned yet. Add a task below, then tick it when done.", 13, MUTED))
		return
	for note in notes:
		if typeof(note) != TYPE_DICTIONARY:
			continue
		var note_id = str(note.get("id", ""))
		var text_value = str(note.get("text", ""))
		var is_done = bool(note.get("done", false))
		var note_line = HBoxContainer.new()
		note_line.add_theme_constant_override("separation", 6)
		project_notes_list.add_child(note_line)
		var mark = CheckBox.new()
		mark.name = "ProjectNoteDone"
		mark.button_pressed = is_done
		mark.tooltip_text = "Mark this task as done / not done"
		mark.toggled.connect(func(checked): _project_note_toggle(note_id, checked))
		note_line.add_child(mark)
		var line_text = RichTextLabel.new()
		line_text.name = "ProjectNoteText"
		line_text.bbcode_enabled = true
		line_text.scroll_active = false
		line_text.custom_minimum_size.y = 27
		line_text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		line_text.mouse_filter = Control.MOUSE_FILTER_IGNORE
		line_text.add_theme_font_size_override("normal_font_size", 14)
		var safe_text = text_value.replace("[", "[lb]")
		line_text.text = "[color=#7e9baa][s]" + safe_text + "[/s][/color]" if is_done else "[color=#eaf5fa]" + safe_text + "[/color]"
		note_line.add_child(line_text)
		var edit_field = _text_input("Edit note")
		edit_field.name = "ProjectNoteEditField"
		edit_field.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		edit_field.max_length = 300
		edit_field.text = text_value
		edit_field.visible = false
		edit_field.text_submitted.connect(func(new_text): _project_note_edit(note_id, new_text))
		edit_field.focus_exited.connect(func():
			if is_instance_valid(edit_field) and edit_field.visible:
				_project_note_edit(note_id, edit_field.text)
		)
		note_line.add_child(edit_field)
		var edit = _button("Edit")
		edit.name = "ProjectNoteEdit"
		edit.pressed.connect(func():
			line_text.visible = false
			edit_field.visible = true
			edit_field.grab_focus()
		)
		note_line.add_child(edit)
		var remove = _button("×")
		remove.name = "ProjectNoteRemove"
		remove.tooltip_text = "Delete this checklist line"
		remove.pressed.connect(func(): _project_note_delete(note_id))
		note_line.add_child(remove)

func _project_note_add() -> void:
	if project_id.is_empty() or not is_instance_valid(project_note_input):
		return
	var text_value = project_note_input.text.strip_edges()
	if text_value.is_empty():
		return
	var next_data = data.duplicate(true)
	var note_id = "note_%s" % Time.get_ticks_usec()
	var project: Dictionary = next_data["projects"][project_id]
	if ProjectPlans.add_note(project, note_id, text_value) and _save_project_data(next_data):
		project_note_input.clear()
		_show_projects()
		if is_instance_valid(project_note_input):
			project_note_input.grab_focus()

func _project_note_toggle(note_id: String, checked: bool) -> void:
	if project_id.is_empty():
		return
	var next_data = data.duplicate(true)
	var project: Dictionary = next_data["projects"][project_id]
	var idx = ProjectPlans.note_index(project, note_id)
	if idx < 0:
		return
	var note: Dictionary = ProjectPlans.notes_of(project)[idx]
	if ProjectPlans.update_note(project, note_id, str(note.get("text", "")), checked) and _save_project_data(next_data):
		_show_projects()

func _project_note_edit(note_id: String, next_text: String) -> void:
	if project_id.is_empty() or next_text.strip_edges().is_empty():
		return
	var next_data = data.duplicate(true)
	var project: Dictionary = next_data["projects"][project_id]
	var idx = ProjectPlans.note_index(project, note_id)
	if idx < 0:
		return
	var note: Dictionary = ProjectPlans.notes_of(project)[idx]
	if ProjectPlans.update_note(project, note_id, next_text, bool(note.get("done", false))):
		if _save_project_data(next_data):
			_show_projects()
	else:
		_render_project_notes()

func _project_note_delete(note_id: String) -> void:
	if project_id.is_empty():
		return
	var next_data = data.duplicate(true)
	var project: Dictionary = next_data["projects"][project_id]
	if ProjectPlans.remove_note(project, note_id) and _save_project_data(next_data):
		_show_projects()

func _refresh_color_table_species() -> void:
	if not is_instance_valid(color_table_species):
		return
	color_table_species.clear()
	color_table_species_keys = [""]
	color_table_species.add_item("All species")
	var names: Dictionary = {}
	for creature in data.get("creatures", []):
		var key = str(creature.get("species_key", ""))
		if not key.is_empty() and not names.has(key):
			names[key] = str(creature.get("species_name", "Unknown"))
	var keys: Array = names.keys()
	keys.sort_custom(func(a, b):
		var left = str(names[a]).to_lower()
		var right = str(names[b]).to_lower()
		return str(a) < str(b) if left == right else left < right
	)
	for key in keys:
		color_table_species_keys.append(key)
		color_table_species.add_item(str(names[key]))
	var selected = color_table_species_keys.find(color_table_species_key)
	if selected < 0:
		color_table_species_key = ""
		selected = 0
	color_table_species.select(selected)

func _on_color_table_filter(index: int, value: String) -> void:
	color_table_filters[index] = value
	color_table_page = 0
	_render_color_table()

func _clear_color_table_filters() -> void:
	color_table_query = ""
	color_table_species_key = ""
	color_table_page = 0
	color_table_search.text = ""
	color_table_species.select(0)
	for i in range(6):
		color_table_filters[i] = ""
		color_table_inputs[i].text = ""
	_render_color_table()

func _sort_color_table_region(index: int) -> void:
	if color_table_sort_region == index:
		color_table_descending = not color_table_descending
	else:
		color_table_sort_region = index
		color_table_descending = false
	color_table_page = 0
	_render_color_table()

func _color_table_filtered() -> Array:
	return ColorTableScript.filtered(data.get("creatures", []), color_table_species_key, color_table_query, color_table_filters, color_table_sort_region, color_table_descending, palette)

func _render_color_table() -> void:
	if not is_instance_valid(color_table_rows):
		return
	_clear(color_table_rows)
	for i in range(color_table_header_buttons.size()):
		var arrow = " ↓" if color_table_descending else " ↑"
		color_table_header_buttons[i].text = "R%s%s" % [i, arrow if i == color_table_sort_region else ""]
	var creatures = _color_table_filtered()
	var pages = maxi(1, int(ceil(float(creatures.size()) / float(color_table_rows_per_page))))
	color_table_page = clampi(color_table_page, 0, pages - 1)
	var start = color_table_page * color_table_rows_per_page
	for i in range(start, mini(start + color_table_rows_per_page, creatures.size())):
		color_table_rows.add_child(_color_table_row(creatures[i]))
	if creatures.is_empty():
		var empty = _label("No creatures match these filters.", 15, MUTED)
		empty.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		color_table_rows.add_child(empty)
	color_table_page_label.text = "%s creatures  •  Page %s of %s" % [creatures.size(), color_table_page + 1, pages]
	color_table_previous.disabled = color_table_page == 0
	color_table_next.disabled = color_table_page >= pages - 1
	color_table_copy_button.disabled = creatures.is_empty()
	color_table_copy_button.text = "Copy rows"

func _color_table_row(creature: Dictionary) -> Control:
	var local_id = str(creature.get("local_id", ""))
	var button = Button.new()
	button.name = "ColorTableCreatureRow"
	button.custom_minimum_size.y = DESKTOP_ROW_HEIGHT
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var tooltip_lines: Array = ["%s · Lvl %s · %s" % [str(creature.get("name", "Unnamed")), str(creature.get("level", "—")), str(creature.get("sex", "Unknown"))]]
	for i in range(6):
		var tip = "R%s: " % i
		if ColorTableScript.is_unused(creature, i):
			tip += "unused"
		else:
			var id = ColorTableScript.confirmed_id(creature, i)
			if id == null:
				tip += "unknown"
			else:
				tip += "#%s %s" % [id, palette.get_color(int(id)).get("name", "Color name unavailable")]
		tooltip_lines.append(tip)
	tooltip_lines.append("Select to view the creature's details.")
	button.tooltip_text = "\n".join(tooltip_lines)
	button.add_theme_stylebox_override("normal", _style(Color("#104656") if local_id == selected_id else Color("#0c202e"), CYAN if local_id == selected_id else Color("#173544"), 4))
	button.add_theme_stylebox_override("hover", _style(Color("#154254"), CYAN, 4))
	button.add_theme_stylebox_override("pressed", _style(Color("#104656"), CYAN, 4))
	button.disabled = local_id.is_empty()
	button.pressed.connect(func():
		selected_id = local_id
		color_table_show_details = true
		_render_color_table()
		_render_details()
	)
	var row = HBoxContainer.new()
	row.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	row.offset_left = 7
	row.offset_right = -7
	row.add_theme_constant_override("separation", 5)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	button.add_child(row)
	var name_box = HBoxContainer.new()
	name_box.custom_minimum_size.x = TABLE_CREATURE_WIDTH
	name_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(name_box)
	var icon = _preview(creature, Vector2(27, 27))
	icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if icon.texture == null:
		icon.free()
		var no_icon = _label("?", 17, MUTED)
		no_icon.custom_minimum_size = Vector2(27, 27)
		no_icon.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		no_icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
		name_box.add_child(no_icon)
	else:
		name_box.add_child(icon)
	var display = _label(str(creature.get("name", "Unnamed")), 13, TEXT)
	display.clip_text = true
	display.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	display.mouse_filter = Control.MOUSE_FILTER_IGNORE
	name_box.add_child(display)
	var level_value = creature.get("level", null)
	var level = _label(str(int(level_value)) if level_value != null else "—", 13, TEXT)
	level.custom_minimum_size.x = TABLE_LEVEL_WIDTH
	level.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(level)
	var sex = str(creature.get("sex", "Unknown"))
	var gender: Control = SexSymbolScript.new(sex) if sex == "Female" or sex == "Male" else _label("?", 17, MUTED)
	gender.custom_minimum_size.x = TABLE_SEX_WIDTH
	gender.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(gender)
	for i in range(6):
		var cell_box = CenterContainer.new()
		cell_box.custom_minimum_size.x = TABLE_REGION_WIDTH
		cell_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
		row.add_child(cell_box)
		var unused = ColorTableScript.is_unused(creature, i)
		var region = {"state": "empty", "id": null, "raw": []} if unused else ColorTableScript.region_at(creature, i).duplicate()
		if not unused and ColorTableScript.confirmed_id(creature, i) == null:
			region["id"] = null
		var cell = _swatch(region, false)
		cell.mouse_filter = Control.MOUSE_FILTER_IGNORE
		if unused:
			cell.get_child(0).text = "—"
			cell.get_child(0).add_theme_color_override("font_color", MUTED)
		cell_box.add_child(cell)
	return button

func _copy_color_table() -> void:
	var creatures = _color_table_filtered()
	if creatures.is_empty():
		return
	DisplayServer.clipboard_set(ColorTableScript.copied_rows(creatures, palette))
	color_table_copy_button.text = "Copied!"

func _on_search(_new_text: String) -> void:
	page_index = 0
	_render_rows()

func _on_library_search_mode_changed(index: int) -> void:
	library_search_mode = search_mode_picker.get_item_id(index)
	_update_library_search_controls()
	_on_search(search_field.text)

func _update_library_search_controls() -> void:
	search_region.visible = library_search_mode == LibrarySearchMode.COLOR_ID
	match library_search_mode:
		LibrarySearchMode.NAME:
			search_field.placeholder_text = "Creature or species name"
		LibrarySearchMode.COLOR_ID:
			search_field.placeholder_text = "Color ID, e.g. 79"
		LibrarySearchMode.LEVEL:
			search_field.placeholder_text = "Exact level, e.g. 41"

func _matches_query(creature: Dictionary, query: String) -> bool:
	if query.is_empty():
		return true
	match library_search_mode:
		LibrarySearchMode.NAME:
			var creature_name = str(creature.get("name", "")).to_lower()
			var species_name = str(creature.get("species_name", "")).to_lower()
			return creature_name.contains(query) or species_name.contains(query)
		LibrarySearchMode.COLOR_ID:
			var color = query.trim_prefix("#")
			if not color.is_valid_int():
				return false
			var id = int(color)
			if search_region.selected > 0:
				return ColorTableScript.confirmed_id(creature, search_region.selected - 1) == id
			for i in range(6):
				if ColorTableScript.confirmed_id(creature, i) == id:
					return true
		LibrarySearchMode.LEVEL:
			var level = creature.get("level", null)
			return query.is_valid_int() and level != null and float(level) == int(query)
	return false

func _stat_number(creature: Dictionary, name: String):
	var stats: Dictionary = creature.get("stats", {})
	if not stats.has(name):
		return null
	var value = float(stats[name])
	if name == "melee damage" or name == "movement speed":
		return (value + 1.0) * 100.0
	return value

func _stat_display(creature: Dictionary, name: String) -> String:
	var value = _stat_number(creature, name)
	if value == null:
		return "—"
	if name == "melee damage" or name == "movement speed":
		return "%.1f%%" % value
	return "%.1f" % value

func _filtered() -> Array:
	var result: Array = []
	var q = search_field.text.strip_edges().to_lower()
	for creature in data.get("creatures", []):
		if not library_species_key.is_empty() and creature.get("species_key", "") != library_species_key:
			continue
		if _matches_query(creature, q):
			result.append(creature)
	var mode = sort_field.selected
	if mode == 1:
		result.sort_custom(func(a, b): return str(a.get("name", "")).to_lower() < str(b.get("name", "")).to_lower())
	elif mode == 2:
		result.sort_custom(func(a, b): return int(a.get("level", 0) if a.get("level", null) != null else -1) > int(b.get("level", 0) if b.get("level", null) != null else -1))
	elif mode == 3:
		result.sort_custom(func(a, b): return float(_stat_number(a, "health") if _stat_number(a, "health") != null else -1) > float(_stat_number(b, "health") if _stat_number(b, "health") != null else -1))
	elif mode == 4:
		result.sort_custom(func(a, b): return float(_stat_number(a, "melee damage") if _stat_number(a, "melee damage") != null else -1) > float(_stat_number(b, "melee damage") if _stat_number(b, "melee damage") != null else -1))
	else:
		result.reverse()
	return result

func _render_rows() -> void:
	if not is_instance_valid(list_box):
		return
	_clear(list_box)
	var filtered = _filtered()
	var page_count = maxi(1, int(ceil(float(filtered.size()) / float(library_rows_per_page))))
	page_index = clampi(page_index, 0, page_count - 1)
	var start = page_index * library_rows_per_page
	var finish = mini(start + library_rows_per_page, filtered.size())
	if filtered.is_empty():
		var message = "No creatures match this search." if not data.get("creatures", []).is_empty() else "No creatures yet. Import your ARK .ini file or ZIP."
		var msg = _label(message, 16, MUTED)
		msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		list_box.add_child(msg)
	for i in range(start, finish):
		list_box.add_child(_creature_row(filtered[i]))
	page_label.text = "%s creatures  •  Page %s of %s" % [filtered.size(), page_index + 1, page_count]
	previous_button.disabled = page_index == 0
	next_button.disabled = page_index >= page_count - 1

func _creature_row(creature: Dictionary) -> Control:
	var local_id = str(creature.get("local_id", ""))
	var button = Button.new()
	button.custom_minimum_size.y = DESKTOP_ROW_HEIGHT
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.tooltip_text = str(creature.get("name", "Unnamed"))
	button.add_theme_stylebox_override("normal", _style(Color("#104656") if local_id == selected_id else Color("#0c202e"), CYAN if local_id == selected_id else Color("#173544"), 5))
	button.add_theme_stylebox_override("hover", _style(Color("#154254"), CYAN, 5))
	button.add_theme_stylebox_override("pressed", _style(Color("#104656"), CYAN, 5))
	button.pressed.connect(func():
		selected_id = local_id
		library_preview_open = true
		_render_rows()
		_render_details()
	)
	var row = HBoxContainer.new()
	row.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	row.offset_left = 7
	row.offset_right = -7
	row.add_theme_constant_override("separation", 5)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	button.add_child(row)
	var name_box = HBoxContainer.new()
	name_box.custom_minimum_size.x = COLUMN_NAME
	name_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(name_box)
	var icon = _preview(creature, Vector2(27, 27))
	icon.custom_minimum_size = Vector2(27, 27)
	icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
	name_box.add_child(icon)
	var display = _label(str(creature.get("name", "Unnamed")), 14, TEXT)
	display.clip_text = true
	display.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	display.mouse_filter = Control.MOUSE_FILTER_IGNORE
	name_box.add_child(display)
	var level = creature.get("level", null)
	var lvl = _label(str(int(level)) if level != null else "—", 14, TEXT)
	lvl.custom_minimum_size.x = COLUMN_LEVEL
	lvl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(lvl)
	var sex = str(creature.get("sex", "Unknown"))
	var gender_label: Control = SexSymbolScript.new(sex) if sex == "Female" or sex == "Male" else _label("?", 20, MUTED)
	gender_label.custom_minimum_size.x = COLUMN_SEX
	gender_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(gender_label)
	var region_row = HBoxContainer.new()
	region_row.custom_minimum_size.x = COLUMN_COLORS
	region_row.add_theme_constant_override("separation", 2)
	region_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for i in range(6):
		region_row.add_child(_creature_region_chip(creature, i))
	row.add_child(region_row)
	for spec in [["health", COLUMN_HEALTH], ["melee damage", COLUMN_MELEE]]:
		var stat = _label(_stat_display(creature, spec[0]), 14, TEXT)
		stat.custom_minimum_size.x = spec[1]
		stat.clip_text = true
		stat.mouse_filter = Control.MOUSE_FILTER_IGNORE
		row.add_child(stat)
	return button

func _swatch(region: Dictionary, large: bool) -> Control:
	var raw: Array = region.get("raw", [])
	var color = PaletteScript.display_color(raw)
	if str(region.get("state", "unknown")) == "empty":
		color = Color("#192a34")
	var panel = PanelContainer.new()
	panel.custom_minimum_size = Vector2(44, 30) if large else Vector2(25, 24)
	if not large:
		panel.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var swatch_style = _style(color, Color("#435b68"), 3, "")
	swatch_style.content_margin_left = 2
	swatch_style.content_margin_right = 2
	swatch_style.content_margin_top = 1
	swatch_style.content_margin_bottom = 1
	panel.add_theme_stylebox_override("panel", swatch_style)
	var id = region.get("id", null)
	var state = str(region.get("state", "unknown"))
	var color_item: Dictionary = palette.get_color(int(id)) if id != null else {}
	if not color_item.is_empty():
		panel.tooltip_text = "%s · ID %s" % [str(color_item.get("name", "Color")), str(id)]
	elif state == "ambiguous":
		panel.tooltip_text = "Possible color IDs: " + str(region.get("candidates", []))
	elif state == "unknown":
		panel.tooltip_text = "Color ID not identified. Raw RGBA: " + str(raw)
	else:
		panel.tooltip_text = "No color data for this region."
	var label = _label(str(int(id)) if id != null else "?", 14 if large else 11, Color.BLACK if color.get_luminance() > 0.45 else Color.WHITE)
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(label)
	return panel

func _preview(creature: Dictionary, minimum: Vector2 = Vector2(0, 250)) -> TextureRect:
	return CreaturePreview.build(creature, registry.images_for(creature), minimum, minimum.x < 1.0)

func _selected():
	for creature in data.get("creatures", []):
		if str(creature.get("local_id", "")) == selected_id:
			return creature
	return null

func _fit_library_preview(holder: Control, picture: TextureRect) -> void:
	if not is_instance_valid(holder) or not is_instance_valid(picture):
		return
	var side = maxf(0.0, minf(LIBRARY_PREVIEW_MAX_SIZE, minf(holder.size.x, holder.size.y)))
	picture.size = Vector2(side, side)
	picture.position = (holder.size - picture.size) * 0.5

func _render_details() -> void:
	if not is_instance_valid(details):
		return
	_clear(details)
	var panel = _panel(Color("#0a1e2b"), Color("#255064"), "details")
	panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	details.add_child(panel)
	var details_scroll = ScrollContainer.new()
	details_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	details_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	details_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	details_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	panel.add_child(details_scroll)
	var box = VBoxContainer.new()
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	box.add_theme_constant_override("separation", 6)
	details_scroll.add_child(box)
	var creature = _selected()
	details.visible = creature != null and (library_preview_open if selected_page == "library" else color_table_show_details)
	if selected_page == "library" and is_instance_valid(library_preview_button):
		library_preview_button.disabled = creature == null
		library_preview_button.text = "Hide preview" if details.visible else "Preview"
	elif selected_page == "color_table" and is_instance_valid(color_table_toggle_details):
		color_table_toggle_details.disabled = creature == null
		color_table_toggle_details.text = "Hide details" if details.visible else "Show details"
	if creature == null:
		box.add_child(_label("Creature Preview", 25, TEXT))
		var hint = _label("Select a creature to see its colors and stats.", 16, MUTED)
		hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		box.add_child(hint)
		return
	_preview_heading(box, str(creature.get("name", "Unnamed")))
	var level = creature.get("level", null)
	var creature_info = _label("%s · Lv. %s · %s" % [creature.get("species_name", "Unknown"), int(level) if level != null else "—", creature.get("sex", "Unknown")], 13, MUTED)
	creature_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(creature_info)
	if creature.get("is_demo", false):
		box.add_child(_label("DEMO DATA — example only", 13, Color("#f6ca76")))
	var picture_holder = Control.new()
	picture_holder.name = "LibraryPreviewHolder"
	picture_holder.custom_minimum_size = Vector2(0, 138)
	picture_holder.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	picture_holder.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var picture = _preview(creature, Vector2.ZERO)
	picture.name = "LibraryCreaturePreview"
	picture_holder.add_child(picture)
	picture_holder.resized.connect(func(): _fit_library_preview(picture_holder, picture))
	box.add_child(picture_holder)
	call_deferred("_fit_library_preview", picture_holder, picture)
	var poses: Array = registry.poses_for(creature)
	if poses.size() > 1:
		var pose = CreaturePreview.pose_selector(poses, registry.default_pose(creature), func(index: int):
			CreaturePreview.set_pose(picture, creature, registry.images_for(creature, index), true)
		)
		pose.name = "LibraryCreaturePose"
		box.add_child(pose)
	if picture.texture == null:
		picture_holder.hide()
		var no_image = _label("No matching preview image included yet.", 14, MUTED)
		no_image.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		box.add_child(no_image)
	box.add_child(_label("Color Regions", 19, TEXT))
	var slots = HBoxContainer.new()
	slots.add_theme_constant_override("separation", 5)
	box.add_child(slots)
	for i in range(6):
		var one = VBoxContainer.new()
		one.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var number = _label(str(i), 12, MUTED)
		number.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		one.add_child(number)
		var swatch = _creature_region_chip(creature, i)
		one.tooltip_text = swatch.tooltip_text
		one.add_child(swatch)
		slots.add_child(one)
	if registry.can_use_lab(creature):
		var try_colors = _button("Open in Color Lab")
		try_colors.name = "LibraryTryCreatureColors"
		try_colors.pressed.connect(_show_color_lab.bind(creature))
		box.add_child(try_colors)
	box.add_child(_label("Stats  ·  exported values", 19, TEXT))
	var stat_grid = GridContainer.new()
	stat_grid.columns = 2
	stat_grid.add_theme_constant_override("h_separation", 9)
	stat_grid.add_theme_constant_override("v_separation", 6)
	box.add_child(stat_grid)
	for stat in [["Health", "health"], ["Melee", "melee damage"], ["Stamina", "stamina"], ["Weight", "weight"], ["Oxygen", "oxygen"], ["Food", "food"]]:
		var label = _label("%s   %s" % [stat[0], _stat_display(creature, stat[1])], 14, TEXT)
		label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		label.clip_text = true
		stat_grid.add_child(label)
	var footer = HBoxContainer.new()
	box.add_child(footer)
	var warning = _label("Stats are exported values.", 11, MUTED)
	warning.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	footer.add_child(warning)
	var menu = MenuButton.new()
	menu.text = "⋯"
	menu.tooltip_text = "Creature actions"
	menu.get_popup().add_item("Remove creature", 0)
	menu.get_popup().id_pressed.connect(func(_id):
		confirm_delete.dialog_text = "Remove this record from BloodlineBank? Reimport the ARK export to restore it."
		confirm_delete.popup_centered()
	)
	footer.add_child(menu)

func _open_import() -> void:
	if is_importing:
		_show_message("Import in progress", "Please wait for the current ZIP or INI to finish checking.")
		return
	file_dialog.popup_centered_ratio(0.78)

func _start_import(path: String) -> void:
	if is_importing:
		return
	is_importing = true
	pending_import_path = path
	pending_revision = database_revision
	var snapshot: Array = data.get("creatures", []).duplicate(true)
	import_thread = Thread.new()
	var error = import_thread.start(_prepare_import_thread.bind(path, snapshot, pending_revision))
	if error != OK:
		is_importing = false
		_show_message("Import error", "Could not start import (error %s)." % error)
	else:
		_show_message("Checking files", "Reading the selected file. The import preview will appear when checking is complete.")

func _prepare_import_thread(path: String, snapshot: Array, revision: int) -> void:
	var result = importer.prepare(path, snapshot)
	if path.get_extension().to_lower() == "zip":
		var inspection = ZipGuardScript.inspect(path, true)
		if not result.get("ok", false) and str(result.get("error", "")) == "No INI files were found in this archive." and inspection.get("ok", false):
			result = {"ok": true, "records": [], "errors": [], "counts": {"new": 0, "update": 0, "unchanged": 0, "conflict": 0}, "archive": path.get_file()}
		result["extraction_preview"] = inspection
	call_deferred("_import_ready", result, revision)

func _import_ready(result: Dictionary, revision: int) -> void:
	if import_thread != null and import_thread.is_started():
		import_thread.wait_to_finish()
	is_importing = false
	if message_dialog.visible and message_dialog.title == "Checking files":
		message_dialog.hide()
	if revision != database_revision:
		_show_message("Library changed", "The library changed while the file was being checked. Please choose the file again so updates are reviewed safely.")
		return
	if not result.get("ok", false):
		_show_message("Import could not continue", str(result.get("error", "Unknown import error.")))
		return
	var records: Array = result.get("records", [])
	var errors: Array = result.get("errors", [])
	var counts: Dictionary = result.get("counts", {})
	var body = "%s\n\nNew: %s   •   Updates: %s   •   Unchanged: %s\nConflicts: %s   •   Invalid: %s\n" % [str(result.get("archive", "Import")), counts.get("new", 0), counts.get("update", 0), counts.get("unchanged", 0), counts.get("conflict", 0), errors.size()]
	body += "\nConflicts and invalid files are not imported. Existing records are updated only when you confirm.\n"
	var extraction: Dictionary = result.get("extraction_preview", {})
	if not extraction.is_empty():
		if extraction.get("ok", false):
			body += "\nAfter confirmation, %s ZIP files will be extracted into the selected export folder.\n" % extraction.get("entries", []).size()
		else:
			body += "\nZIP extraction cannot finish: " + str(extraction.get("error", "Unknown error.")) + "\n"
	if not records.is_empty():
		body += "\nFirst records:\n"
		for i in range(mini(6, records.size())):
			var item: Dictionary = records[i]
			var creature: Dictionary = item["creature"]
			body += "• %s — %s (%s)\n" % [str(item["action"]).capitalize(), str(creature.get("name", "Unnamed")), str(creature.get("sex", "Unknown"))]
			var warnings: Array = creature.get("warnings", [])
			if not warnings.is_empty():
				body += "  " + "; ".join(warnings.slice(0, 2)) + "\n"
	if not errors.is_empty():
		body += "\nFiles needing attention:\n"
		for i in range(mini(5, errors.size())):
			body += "• " + str(errors[i]) + "\n"
		if errors.size() > 5:
			body += "• And %s more.\n" % (errors.size() - 5)
	if int(counts.get("new", 0)) + int(counts.get("update", 0)) == 0:
		if int(counts.get("conflict", 0)) == 0 and errors.is_empty():
			_mark_manual_review_complete(pending_import_path)
		if pending_import_path.get_extension().to_lower() != "zip":
			_show_message("Import review", body + "\nNo new or changed records to import.")
			return
		body += "\nNo new or changed creatures. Confirm to extract the ZIP files."
	pending_import = result
	pending_revision = revision
	confirm_import.ok_button_text = "Extract ZIP files" if int(counts.get("new", 0)) + int(counts.get("update", 0)) == 0 else "Import reviewed entries"
	confirm_import.dialog_text = body
	confirm_import.popup_centered()

func _commit_import() -> void:
	if pending_import.is_empty():
		return
	if pending_revision != database_revision:
		pending_import.clear()
		_show_message("Library changed", "Please choose the import file again.")
		return
	var counts: Dictionary = pending_import.get("counts", {})
	if int(counts.get("new", 0)) + int(counts.get("update", 0)) > 0:
		var next_data = importer.apply_plan(pending_import, data)
		var saved = storage.save_data(next_data)
		if not saved.get("ok", false):
			_show_message("Could not save", str(saved.get("error", "The library was not changed.")))
			return
		data = next_data
		database_revision += 1
		_unsuppress_imported_records(pending_import.get("records", []))
		_mark_manual_review_complete(pending_import_path)
	var completed_path = pending_import_path
	pending_import.clear()
	if not data.get("creatures", []).is_empty():
		selected_id = str(data["creatures"].back().get("local_id", ""))
	page_index = 0
	library_species_key = ""
	_show_library()
	var summary = "%s new records and %s updates saved.\nOriginal ZIP and INI files were not changed." % [counts.get("new", 0), counts.get("update", 0)]
	if completed_path.get_extension().to_lower() == "zip":
		_start_manual_extraction(completed_path, summary)
	else:
		_show_message("Import complete", summary)

func _start_manual_extraction(path: String, summary: String) -> void:
	is_importing = true
	import_thread = Thread.new()
	var error = import_thread.start(_manual_extraction_worker.bind(path, export_folder, summary))
	if error != OK:
		is_importing = false
		_show_message("ZIP extraction failed", summary + "\nCould not start extraction (error %s)." % error)
	else:
		_show_message("Extracting ZIP", "Copying files into the Exported Dino folder.")

func _manual_extraction_worker(path: String, folder: String, summary: String) -> void:
	var result = ArchiveExtractScript.extract_archive(path, folder)
	call_deferred("_manual_extraction_ready", result, summary)

func _manual_extraction_ready(result: Dictionary, summary: String) -> void:
	if import_thread != null and import_thread.is_started():
		import_thread.wait_to_finish()
	is_importing = false
	if message_dialog.visible and message_dialog.title == "Extracting ZIP":
		message_dialog.hide()
	if result.get("ok", false):
		summary += "\nZIP: %s files copied, %s already present." % [result.get("copied", 0), result.get("unchanged", 0)]
	else:
		summary += "\nZIP extraction needs attention: " + str(result.get("error", "Unknown error."))
	_show_message("Import complete", summary)
	call_deferred("_start_scan", false)

func _delete_selected() -> void:
	if data.get("read_only", false):
		_show_message("Read-only recovery", "The library cannot be changed in recovery mode.")
		return
	var next_data: Dictionary = data.duplicate(true)
	var creatures: Array = next_data.get("creatures", [])
	var identity = ""
	for i in range(creatures.size() - 1, -1, -1):
		if str(creatures[i].get("local_id", "")) == selected_id:
			identity = str(creatures[i].get("identity", ""))
			creatures.remove_at(i)
			break
	var next_state = scan_state.duplicate(true)
	if not identity.is_empty():
		if not scan_block_reason.is_empty():
			_show_message("Could not remove", "The scan manifest needs attention before this creature can be removed safely.")
			return
		if typeof(next_state.get("suppressed")) != TYPE_DICTIONARY:
			next_state["suppressed"] = {}
		next_state["suppressed"][identity] = true
		var marker = scan_settings.save_state(next_state)
		if not marker.get("ok", false):
			_show_message("Could not remove", "The scan state could not be saved; the creature remains in the library.")
			return
	var saved = storage.save_data(next_data)
	if not saved.get("ok", false):
		if not identity.is_empty():
			scan_settings.save_state(scan_state)
		_show_message("Could not save", str(saved.get("error", "The record was not removed.")))
		return
	data = next_data
	scan_state = next_state
	database_revision += 1
	selected_id = ""
	if selected_page == "color_table":
		_refresh_color_table_species()
		_render_color_table()
		_render_details()
	else:
		_show_library()

func _show_message(title_text: String, body: String) -> void:
	message_dialog.title = title_text
	message_dialog.dialog_text = body
	message_dialog.popup_centered()

func _show_about() -> void:
	var body = "BloodlineBank 0.6.3 — desktop prototype\n\n"
	body += "The saved library is local to this computer. Backups are kept beside the library file. The original bot database and import files are not modified.\n\n"
	body += "Creature pictures currently included: X-Otter, Yutyrannus, Magmasaur. Other recognized species remain usable with an empty image preview.\n\n"
	body += "Displayed stat values are not confirmed inheritable breeding points. Species and region data comes from Smart Breeding metadata and needs comparison against actual ASA exports.\n\n"
	body += "Color Bingo checks collection coverage, not a guaranteed breeding pair. Automatic scanning discovers ARK DinoExports when available and reads it every 45 seconds by default.\n\n"
	body += "A demo ZIP is in the examples folder. Its two dinos are fictional and labeled DEMO."
	_show_message("About this prototype", body)

func _set_scan_summary(value: String) -> void:
	scan_summary = value
	if is_instance_valid(scan_status_label):
		scan_status_label.text = value
	if is_instance_valid(settings_scan_summary_label):
		settings_scan_summary_label.text = "Last scan: " + value

func _automatic_scan_tick() -> void:
	if is_importing or folder_dialog.visible or not scan_settings.load_auto_sync():
		return
	# If ARK was installed after BloodlineBank opened, discover it on the next tick.
	# Respect an explicitly selected folder even if another Steam library exists.
	if not scan_settings.has_explicit_folder():
		var detected = scan_settings.detect_ark_folder()
		if not detected.is_empty() and detected != export_folder:
			_set_export_folder(detected)
			if scan_block_reason.begins_with("Could not create the default"):
				scan_block_reason = ""
	_start_scan(false)

func _set_auto_sync_enabled(enabled: bool) -> void:
	if scan_settings.save_auto_sync(enabled) != OK:
		_show_message("Setting not saved", "Could not save the automatic sync preference.")
		_refresh_file_settings()
		return
	if enabled and OS.get_environment("BLOODLINEBANK_DISABLE_AUTOSCAN") != "1":
		auto_scan_timer.start()
		_automatic_scan_tick()
	else:
		auto_scan_timer.stop()

func _use_detected_ark_folder() -> void:
	if is_importing:
		_show_message("Scan running", "Finish the current scan before changing the source folder.")
		return
	var detected = scan_settings.detect_ark_folder()
	if detected.is_empty():
		_show_message("ARK not found", "BloodlineBank could not find the standard Steam installation. Use Choose folder and select ShooterGame/Saved/DinoExports.")
		return
	_folder_selected(detected)

func _start_scan(show_notice: bool = false) -> void:
	if is_importing:
		if show_notice:
			_show_message("Import in progress", "Wait for the current import or scan to finish.")
		return
	if data.get("read_only", false):
		_set_scan_summary("Auto scan paused: library recovery mode.")
		if show_notice:
			_show_message("Scan paused", "The library is in read-only recovery mode. Existing files were not changed.")
		return
	if not scan_block_reason.is_empty():
		_set_scan_summary("Auto scan paused. Open Settings / Data.")
		if show_notice:
			_show_message("Scan paused", scan_block_reason)
		return
	is_importing = true
	var revision = database_revision
	var snapshot: Array = data.get("creatures", []).duplicate(true)
	var state_snapshot = scan_state.duplicate(true)
	import_thread = Thread.new()
	var error = import_thread.start(_scan_worker.bind(export_folder, snapshot, state_snapshot, revision, show_notice))
	if error != OK:
		is_importing = false
		_set_scan_summary("Scan could not start.")
		if show_notice:
			_show_message("Scan error", "Could not start the background scan (error %s)." % error)
	else:
		_set_scan_summary("Scanning Exported Dino...")

func _scan_worker(folder: String, snapshot: Array, state_snapshot: Dictionary, revision: int, show_notice: bool) -> void:
	# Never extract ZIPs or write into ARK's installation directory.
	var read_only_ark_source = scan_settings.is_ark_exports_folder(folder)
	var result = folder_scanner.scan(folder, snapshot, state_snapshot, not read_only_ark_source)
	call_deferred("_scan_ready", result, revision, show_notice)

func _scan_ready(result: Dictionary, revision: int, show_notice: bool) -> void:
	if import_thread != null and import_thread.is_started():
		import_thread.wait_to_finish()
	is_importing = false
	if revision != database_revision:
		_set_scan_summary("Library changed during scan; scan again.")
		if show_notice:
			_show_message("Scan needs retry", "The library changed during the scan. Scan again to safely review the current data.")
		return
	if not result.get("ok", false):
		_set_scan_summary("Scan failed. Open Settings / Data.")
		scan_issues = [str(result.get("error", "The folder could not be scanned."))]
		if show_notice:
			_show_message("Scan failed", str(result.get("error", "The folder could not be scanned.")))
		_refresh_file_settings()
		return
	var records: Array = result.get("records", [])
	if not records.is_empty():
		var next_data = importer.apply_plan({"records": records}, data)
		var saved = storage.save_data(next_data)
		if not saved.get("ok", false):
			_set_scan_summary("Scan could not save. Open Settings.")
			_show_message("Scan could not save", str(saved.get("error", "The library was not changed.")))
			return
		data = next_data
		database_revision += 1
		if selected_page == "color_lab" and is_instance_valid(color_lab):
			color_lab.set_library(data)
		if selected_id.is_empty():
			selected_id = str(data["creatures"].back().get("local_id", ""))
	# Don't rewrite the manifest every 45 seconds when no source changed.
	if result.get("state", {}) != scan_state:
		var save_state = scan_settings.save_state(result.get("state", {}))
		if not save_state.get("ok", false):
			_set_scan_summary("Library saved; scan state needs attention.")
			_show_message("Scan state not saved", str(save_state.get("error", "Please scan again.")))
			return
	scan_state = result["state"]
	var new_pending: Array = result.get("pending", [])
	var review_changed = scan_pending != new_pending or scan_issues != result.get("errors", [])
	scan_pending = new_pending
	var counts: Dictionary = result.get("counts", {})
	var errors: Array = result.get("errors", [])
	scan_issues = errors.duplicate()
	var summary = "%s new · %s unchanged · %s review" % [counts.get("new", 0), counts.get("unchanged", 0), counts.get("review", 0)]
	if not errors.is_empty():
		summary += " · %s issues" % errors.size()
	_set_scan_summary(summary)
	# A no-op sync must not discard a search, interrupt a drag, or reset filters.
	if not records.is_empty():
		if selected_page == "library":
			_fill_species_options(library_species, library_species_key)
			library_species_key = str(library_species.get_selected_metadata())
			_render_rows()
			_render_details()
		elif selected_page == "color_table":
			_refresh_color_table_species()
			_render_color_table()
			_render_details()
		elif selected_page == "projects":
			_show_projects()
		elif selected_page == "partner":
			_show_partner_finder()
		elif selected_page == "bingo":
			_bingo_species_changed(bingo_species.selected)
	if review_changed:
		_refresh_file_settings()
	if show_notice:
		var body = summary + "\nExtracted %s new files from %s ZIPs." % [counts.get("extracted", 0), counts.get("archives", 0)]
		if not errors.is_empty():
			body += "\n\nIssues:\n" + "\n".join(errors.slice(0, 5))
			if errors.size() > 5:
				body += "\nAnd %s more." % (errors.size() - 5)
		if not scan_pending.is_empty():
			body += "\n\nUse Settings / Data to review changed or unidentified creatures."
		_show_message("Scan complete", body)

func _open_export_folder_picker() -> void:
	if is_importing:
		_show_message("Scan in progress", "Wait until the current scan or import finishes before changing folders.")
		return
	if DirAccess.dir_exists_absolute(export_folder):
		folder_dialog.current_dir = export_folder
	folder_dialog.popup_centered_ratio(0.75)

func _set_export_folder(path: String) -> void:
	export_folder = path
	if is_instance_valid(library_folder_button):
		library_folder_button.tooltip_text = path
	if selected_page == "settings" and is_instance_valid(settings_files_box):
		var path_label = settings_files_box.get_node_or_null("ExportFolderPath") as Label
		if path_label != null:
			path_label.text = path

func _folder_selected(path: String) -> void:
	if is_importing:
		_show_message("Scan in progress", "Wait until the current scan or import finishes before changing folders.")
		return
	if DirAccess.open(path) == null:
		_show_message("Folder unavailable", "Choose an existing folder that BloodlineBank can read.")
		return
	if scan_settings.save_folder(path) != OK:
		_show_message("Folder not saved", "The folder preference could not be saved.")
		return
	_set_export_folder(path)
	if scan_block_reason.begins_with("Could not create the default"):
		scan_block_reason = ""
	_refresh_file_settings()
	_start_scan(true)

func _mark_manual_review_complete(path: String) -> void:
	if path.is_empty() or not scan_block_reason.is_empty():
		return
	var files: Dictionary = scan_state.get("files", {})
	if not files.has(path) or files[path].get("status", "") != "review":
		return
	if FileAccess.get_sha256(path) != str(files[path].get("hash", "")):
		return
	var next = scan_state.duplicate(true)
	next["files"][path]["status"] = "manual"
	next["files"][path].erase("reason")
	if not scan_settings.save_state(next).get("ok", false):
		return
	scan_state = next
	for i in range(scan_pending.size() - 1, -1, -1):
		if str(scan_pending[i].get("path", "")) == path:
			scan_pending.remove_at(i)

func _unsuppress_imported_records(records: Array) -> void:
	if not scan_block_reason.is_empty() or typeof(scan_state.get("suppressed")) != TYPE_DICTIONARY:
		return
	var next = scan_state.duplicate(true)
	var changed = false
	for record in records:
		if record.get("action", "") != "new" and record.get("action", "") != "update":
			continue
		var identity = str(record.get("creature", {}).get("identity", ""))
		if not identity.is_empty() and next["suppressed"].has(identity):
			next["suppressed"].erase(identity)
			changed = true
	if changed and scan_settings.save_state(next).get("ok", false):
		scan_state = next

func _show_settings() -> void:
	selected_page = "settings"
	_activate_nav("settings")
	_workspace_setup()
	details.hide()
	middle.add_child(_label("▏ Settings / Data", 26, TEXT))
	var tabs = TabContainer.new()
	tabs.name = "SettingsTabs"
	tabs.size_flags_vertical = Control.SIZE_EXPAND_FILL
	tabs.add_theme_stylebox_override("panel", _style(Color("#0a1e2b"), Color("#25485c")))
	tabs.add_theme_stylebox_override("tab_selected", _style(Color("#103747"), CYAN))
	tabs.add_theme_stylebox_override("tab_unselected", _style(PANEL_LIGHT, Color("#315263")))
	tabs.add_theme_stylebox_override("tab_hovered", _style(Color("#1c5366"), CYAN))
	tabs.add_theme_color_override("font_selected_color", TEXT)
	tabs.add_theme_color_override("font_unselected_color", MUTED)
	middle.add_child(tabs)
	_add_appearance_settings(_add_settings_tab(tabs, "Appearance"))
	_add_display_settings(_add_settings_tab(tabs, "Display"))
	settings_files_box = _add_settings_tab(tabs, "Files")
	_refresh_file_settings()
	_add_layout_settings(_add_settings_tab(tabs, "Layout"))
	tabs.current_tab = settings_tab
	tabs.tab_changed.connect(func(index): settings_tab = index as SettingsTab)

func _add_settings_tab(tabs: TabContainer, title: String) -> VBoxContainer:
	var scroll = ScrollContainer.new()
	var tab = VBoxContainer.new()
	tab.name = title
	tabs.add_child(tab)
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	tab.add_child(scroll)
	_paged_scroll(scroll)
	var box = VBoxContainer.new()
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.add_theme_constant_override("separation", 7)
	scroll.add_child(box)
	return box

func _add_layout_settings(box: VBoxContainer) -> void:
	box.add_child(_label("Navigation position", 19))
	var edge = _option()
	edge.name = "LayoutNavigationPosition"
	for i in range(LayoutSettings.EDGES.size()):
		edge.add_item(LayoutSettings.EDGES[i], i)
	edge.select(int(layout["dock"]))
	box.add_child(edge)
	var labels = CheckButton.new()
	labels.name = "LayoutShowNavigationText"
	layout_text_toggle = labels
	labels.text = "Show icons and text"
	labels.button_pressed = not layout["icons"]
	box.add_child(labels)
	box.add_child(_label("Default preview width", 19))
	var width_row = HBoxContainer.new()
	box.add_child(width_row)
	var width = HSlider.new()
	width.name = "LayoutPreviewWidth"
	width.min_value = LayoutSettings.MIN_PREVIEW
	width.max_value = LayoutSettings.MAX_PREVIEW
	width.step = 1
	width.value = layout["preview"]
	width.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	width_row.add_child(width)
	var pixels = _label("%s px" % int(width.value), 13, MUTED)
	width_row.add_child(pixels)
	var reset = _button("Reset layout")
	reset.name = "LayoutReset"
	box.add_child(reset)
	edge.item_selected.connect(func(i):
		layout["dock"] = i
		_save_navigation_layout()
	)
	labels.toggled.connect(func(value):
		layout["icons"] = not value
		_save_navigation_layout()
	)
	width.value_changed.connect(func(value):
		layout["preview"] = roundi(value)
		pixels.text = "%s px" % int(layout["preview"])
		LayoutSettings.save_layout(layout)
	)
	reset.pressed.connect(func():
		layout = LayoutSettings.DEFAULTS.duplicate()
		_save_navigation_layout()
		_show_settings()
	)

func _add_display_settings(box: VBoxContainer) -> void:
	box.add_child(_label("Window mode", 21, TEXT))
	display_mode_picker = _option()
	display_mode_picker.name = "DisplayWindowMode"
	for index in range(DisplaySettings.MODE_LABELS.size()):
		display_mode_picker.add_item(DisplaySettings.MODE_LABELS[index], index)
	display_mode_picker.select(window_mode)
	var actions = HFlowContainer.new()
	actions.add_theme_constant_override("h_separation", 8)
	actions.add_theme_constant_override("v_separation", 6)
	box.add_child(actions)
	actions.add_child(display_mode_picker)
	var apply = _button("Apply mode", true)
	apply.name = "DisplayApplyMode"
	apply.pressed.connect(func(): _set_window_mode(display_mode_picker.get_selected_id() as DisplaySettings.Mode))
	actions.add_child(apply)
	var minimize = _button("Minimize window")
	minimize.name = "DisplayMinimize"
	minimize.pressed.connect(func(): get_window().mode = Window.MODE_MINIMIZED)
	actions.add_child(minimize)
	display_mode_status = _label("Saved mode: " + DisplaySettings.MODE_LABELS[window_mode], 14, MUTED)
	box.add_child(display_mode_status)
	var borderless_hint = _label("Borderless window hides the title bar. Fullscreen fills the monitor.", 14, MUTED)
	borderless_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(borderless_hint)
	var shortcut = _label("Press F11 to switch between Windowed and Fullscreen. From other modes, F11 returns to Windowed.", 14, MUTED)
	shortcut.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(shortcut)
	box.add_child(HSeparator.new())
	box.add_child(_label("Custom resolution", 21, TEXT))
	var size_help = _label("Sets the window size in pixels for Windowed and Borderless modes. Fullscreen uses the monitor size.", 14, MUTED)
	size_help.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(size_help)
	var size_row = HFlowContainer.new()
	size_row.add_theme_constant_override("h_separation", 8)
	size_row.add_theme_constant_override("v_separation", 6)
	box.add_child(size_row)
	var current_size = custom_window_size if custom_window_size != Vector2i.ZERO else DisplaySettings.default_size()
	var width_input = _window_dimension(size_row, "Width (px)", "DisplayWindowWidth", current_size.x)
	var height_input = _window_dimension(size_row, "Height (px)", "DisplayWindowHeight", current_size.y)
	var size_actions = HBoxContainer.new()
	box.add_child(size_actions)
	var apply_size = _button("Apply size", true)
	apply_size.name = "DisplayApplySize"
	size_actions.add_child(apply_size)
	apply_size.pressed.connect(_save_window_dimensions.bind(width_input, height_input))
	width_input.text_submitted.connect(func(_text): _save_window_dimensions(width_input, height_input))
	height_input.text_submitted.connect(func(_text): _save_window_dimensions(width_input, height_input))
	var reset_size = _button("Default size")
	reset_size.name = "DisplayDefaultSize"
	size_actions.add_child(reset_size)
	reset_size.pressed.connect(func():
		var default = DisplaySettings.default_size()
		if _set_window_size(default):
			width_input.text = str(default.x)
			height_input.text = str(default.y)
	)
	window_size_status = _label("", 14, MUTED)
	window_size_status.name = "DisplayWindowSizeStatus"
	window_size_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(window_size_status)
	_update_window_size_status()

func _window_dimension(parent: HFlowContainer, label_text: String, control_name: String, value: int) -> LineEdit:
	var column = VBoxContainer.new()
	parent.add_child(column)
	column.add_child(_label(label_text, 13, MUTED))
	var field = _text_input()
	field.name = control_name
	field.text = str(value)
	field.max_length = 5
	field.custom_minimum_size.x = 104
	column.add_child(field)
	return field

func _save_window_dimensions(width: LineEdit, height: LineEdit) -> void:
	var width_text = width.text.strip_edges()
	var height_text = height.text.strip_edges()
	_set_window_size(Vector2i(
		int(width_text) if width_text.is_valid_int() else 0,
		int(height_text) if height_text.is_valid_int() else 0
	))

func _set_window_size(size: Vector2i) -> bool:
	if not DisplaySettings.valid_size(size):
		var minimum = DisplaySettings.MIN_SIZE
		var maximum = DisplaySettings.MAX_SIZE
		window_size_status.text = "Enter a size from %s × %s up to %s × %s." % [minimum.x, minimum.y, maximum.x, maximum.y]
		return false
	if DisplaySettings.save_size(size) != OK:
		window_size_status.text = "Could not save the window size."
		return false
	custom_window_size = size
	if DisplaySettings.uses_custom_size(window_mode):
		_apply_display_preferences()
	else:
		_update_window_size_status()
	return true

func _apply_display_preferences() -> void:
	var window = get_window()
	DisplaySettings.apply(window, window_mode)
	var applied = Vector2i.ZERO
	if custom_window_size != Vector2i.ZERO and DisplaySettings.uses_custom_size(window_mode):
		applied = DisplaySettings.apply_size(window, custom_window_size)
	_update_window_size_status(applied)

func _update_window_size_status(applied: Vector2i = Vector2i.ZERO) -> void:
	if selected_page != "settings" or not is_instance_valid(window_size_status):
		return
	if custom_window_size == Vector2i.ZERO:
		window_size_status.text = ""
		return
	window_size_status.text = "Saved size: %s × %s" % [custom_window_size.x, custom_window_size.y]
	if not DisplaySettings.uses_custom_size(window_mode):
		window_size_status.text += " · Applies in Windowed and Borderless"
	elif applied != Vector2i.ZERO and applied != custom_window_size:
		window_size_status.text += " · Fits this monitor at %s × %s" % [applied.x, applied.y]

func _set_window_mode(mode: DisplaySettings.Mode) -> void:
	if DisplaySettings.save_mode(mode) != OK:
		_show_message("Window mode not saved", "Could not save your display preference.")
		return
	window_mode = mode
	_apply_display_preferences()
	if selected_page == "settings" and is_instance_valid(display_mode_picker):
		display_mode_picker.select(window_mode)
		display_mode_status.text = "Saved mode: " + DisplaySettings.MODE_LABELS[window_mode]

func _input(event: InputEvent) -> void:
	if not is_instance_valid(workspace):
		return
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_F11:
		get_viewport().set_input_as_handled()
		var next = DisplaySettings.Mode.FULLSCREEN if window_mode == DisplaySettings.Mode.WINDOWED else DisplaySettings.Mode.WINDOWED
		_set_window_mode(next)

func _unhandled_key_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE and is_instance_valid(details) and details.visible:
		_toggle_current_details()
		get_viewport().set_input_as_handled()

func _refresh_file_settings() -> void:
	if selected_page != "settings" or not is_instance_valid(settings_files_box):
		return
	var box = settings_files_box
	_clear(box)
	box.add_child(_label("Export and extraction folder", 21, TEXT))
	var info = _label("BloodlineBank scans this folder for creature exports and uses it when extracting files from imported ZIPs.", 14, MUTED)
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(info)
	var path_label = _label(export_folder, 14, CYAN)
	path_label.name = "ExportFolderPath"
	path_label.autowrap_mode = TextServer.AUTOWRAP_ARBITRARY
	box.add_child(path_label)
	var actions = HFlowContainer.new()
	actions.add_theme_constant_override("h_separation", 8)
	actions.add_theme_constant_override("v_separation", 6)
	box.add_child(actions)
	var choose = _button("Choose folder")
	choose.pressed.connect(_open_export_folder_picker)
	actions.add_child(choose)
	var detect = _button("Use ARK folder")
	detect.disabled = scan_settings.detect_ark_folder().is_empty()
	detect.tooltip_text = "Find the standard ARK Survival Ascended Steam export location. If your Steam library is elsewhere, choose the folder manually."
	detect.pressed.connect(_use_detected_ark_folder)
	actions.add_child(detect)
	var show = _button("Show folder")
	show.pressed.connect(func():
		var code = OS.shell_show_in_file_manager(export_folder, true)
		if code != OK:
			_show_message("Could not open folder", export_folder)
	)
	actions.add_child(show)
	var scan = _button("Scan now", true)
	scan.pressed.connect(func(): _start_scan(true))
	actions.add_child(scan)
	var auto_sync = CheckButton.new()
	auto_sync.text = "Auto-sync every 45 seconds"
	auto_sync.button_pressed = scan_settings.load_auto_sync()
	auto_sync.toggled.connect(_set_auto_sync_enabled)
	box.add_child(auto_sync)
	var summary = _label("Last scan: " + scan_summary, 14, TEXT)
	summary.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(summary)
	settings_scan_summary_label = summary
	var read_note = _label("Auto-sync checks at startup and every 45 seconds. Use Import Creature to import ZIPs stored in ARK’s DinoExports folder.", 13, MUTED)
	read_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(read_note)
	if not scan_block_reason.is_empty():
		var blocked = _label(scan_block_reason, 14, Color("#f5ce7d"))
		blocked.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		box.add_child(blocked)
	if not scan_issues.is_empty():
		box.add_child(_label("Scan issues", 19, TEXT))
		for i in range(mini(10, scan_issues.size())):
			var issue = _label("• " + str(scan_issues[i]), 13, Color("#f5ce7d"))
			issue.autowrap_mode = TextServer.AUTOWRAP_ARBITRARY
			box.add_child(issue)
		if scan_issues.size() > 10:
			box.add_child(_label("And %s more issues." % (scan_issues.size() - 10), 13, MUTED))
	if not scan_pending.is_empty():
		box.add_child(_label("Files to review", 19, TEXT))
		for i in range(mini(20, scan_pending.size())):
			var entry: Dictionary = scan_pending[i]
			var path = str(entry.get("path", ""))
			var b = _button("Review: " + path.get_file())
			b.clip_text = true
			b.tooltip_text = path + "\n" + str(entry.get("reason", ""))
			b.pressed.connect(func(): _start_import(path))
			box.add_child(b)
		if scan_pending.size() > 20:
			box.add_child(_label("And %s more files." % (scan_pending.size() - 20), 13, MUTED))
	var about = _button("About this prototype")
	about.pressed.connect(_show_about)
	box.add_child(about)


func _add_appearance_settings(parent: VBoxContainer) -> void:
	var section = _panel()
	parent.add_child(section)
	var stack = VBoxContainer.new()
	stack.add_theme_constant_override("separation", 8)
	section.add_child(stack)
	stack.add_child(_label("Simpler color", 21))
	var hint = _label("Choose one color for the whole theme.", 14, MUTED)
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	stack.add_child(hint)
	var simple_row = HBoxContainer.new()
	simple_row.add_theme_constant_override("separation", 8)
	stack.add_child(simple_row)
	var theme_picker = ColorPickerButton.new()
	theme_picker.name = "AppearanceThemeColor"
	theme_picker.edit_alpha = false
	theme_picker.color = appearance.get("theme_color", appearance["accent"])
	theme_picker.custom_minimum_size = Vector2(120, 38)
	theme_picker.tooltip_text = "Choose the base color for the theme"
	simple_row.add_child(theme_picker)
	var apply_theme = _button("Apply theme", true)
	apply_theme.name = "AppearanceApplyTheme"
	apply_theme.pressed.connect(func(): _apply_appearance(Appearance.from_color(theme_picker.color)))
	simple_row.add_child(apply_theme)
	stack.add_child(HSeparator.new())
	stack.add_child(_label("Individual colors", 18))
	var controls = HFlowContainer.new()
	controls.add_theme_constant_override("h_separation", 8)
	controls.add_theme_constant_override("v_separation", 6)
	stack.add_child(controls)
	var pickers = {}
	for entry in [
		["background", "App background"], ["sidebar", "Navigation"],
		["panels", "Main panels"], ["details", "Detail panels"], ["accent", "Accent"]
	]:
		var key: String = entry[0]
		var column = VBoxContainer.new()
		column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		column.custom_minimum_size.x = 100
		controls.add_child(column)
		column.add_child(_label(entry[1], 13, MUTED))
		var picker = ColorPickerButton.new()
		picker.name = "Appearance_" + key
		picker.edit_alpha = false
		picker.color = appearance[key]
		picker.custom_minimum_size.y = 32
		picker.tooltip_text = entry[1] + " tint"
		column.add_child(picker)
		pickers[key] = picker
	var actions = HBoxContainer.new()
	actions.add_theme_constant_override("separation", 8)
	stack.add_child(actions)
	var apply = _button("Apply colors", true)
	apply.name = "AppearanceApply"
	apply.pressed.connect(func():
		var chosen = {}
		if appearance.has("theme_color"):
			chosen["theme_color"] = appearance["theme_color"]
		for key in pickers:
			chosen[key] = pickers[key].color
		_apply_appearance(chosen)
	)
	actions.add_child(apply)
	var reset = _button("Restore defaults")
	reset.name = "AppearanceReset"
	reset.pressed.connect(func(): _apply_appearance(Appearance.DEFAULTS.duplicate()))
	actions.add_child(reset)

func _apply_appearance(chosen: Dictionary) -> void:
	if Appearance.save_colors(chosen) != OK:
		_show_message("Could not save appearance", "The current colors are still active.")
		return
	appearance = chosen
	background_rect.color = Appearance.surface(BACKGROUND, appearance, "background")
	sidebar_panel.add_theme_stylebox_override("panel", _style(Color("#091b29"), Color("#1b3748"), 4, "sidebar"))
	_show_settings()

func _add_bingo_control(row: HBoxContainer, title: String, control: Control) -> void:
	var column = VBoxContainer.new()
	column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	column.add_theme_constant_override("separation", 4)
	column.add_child(_label(title, 16, TEXT))
	control.add_theme_font_size_override("font_size", 14)
	if control is OptionButton:
		control.fit_to_longest_item = false
		control.clip_text = true
	column.add_child(control)
	row.add_child(column)

func _show_bingo() -> void:
	var previous = _selected()
	var selected_key = str(previous.get("species_key", "")) if previous != null else ""
	if bingo_color_id == 0 and previous != null:
		for region in previous.get("regions", []):
			if typeof(region) == TYPE_DICTIONARY and region.get("id", null) != null:
				bingo_color_id = int(region["id"])
				break
	selected_page = "bingo"
	_activate_nav("bingo")
	_workspace_setup()
	_page_heading("Color Bingo")
	var controls = _panel(Color("#0a1e2b"), Color("#25485c"))
	middle.add_child(controls)
	var stack = VBoxContainer.new()
	stack.add_theme_constant_override("separation", 7)
	controls.add_child(stack)
	var first = HBoxContainer.new()
	first.add_theme_constant_override("separation", 8)
	stack.add_child(first)
	bingo_species = _option()
	bingo_species.fit_to_longest_item = false
	bingo_species.clip_text = true
	bingo_species.custom_minimum_size.x = 112
	_add_bingo_control(first, "Creature", bingo_species)
	bingo_search = _text_input("Color name or ID")
	bingo_search.clear_button_enabled = true
	_add_bingo_control(first, "Find color", bingo_search)
	bingo_order = _option()
	for title in ["ID: low to high", "ID: high to low", "Bingo first", "Bingo + most regions"]:
		bingo_order.add_item(title)
	_add_bingo_control(first, "Sort by", bingo_order)
	bingo_filter = _option()
	for title in ["All colors", "Bingos", "One region away", "Needs review"]:
		bingo_filter.add_item(title)
	_add_bingo_control(first, "Filter", bingo_filter)
	bingo_summary = _label("", 13, MUTED)
	bingo_summary.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	stack.add_child(bingo_summary)
	var grid_panel = _panel(Color("#0a1e2b"), Color("#25485c"))
	grid_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	middle.add_child(grid_panel)
	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	grid_panel.add_child(scroll)
	bingo_grid = HFlowContainer.new()
	bingo_grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bingo_grid.add_theme_constant_override("h_separation", 6)
	bingo_grid.add_theme_constant_override("v_separation", 6)
	scroll.add_child(bingo_grid)
	_paged_scroll(scroll)
	var detail_panel = _panel(Color("#0a1e2b"), Color("#25485c"), "details")
	detail_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	details.add_child(detail_panel)
	var detail_scroll = ScrollContainer.new()
	detail_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	detail_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	detail_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	detail_panel.add_child(detail_scroll)
	bingo_detail_box = VBoxContainer.new()
	bingo_detail_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bingo_detail_box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	bingo_detail_box.add_theme_constant_override("separation", 5)
	detail_scroll.add_child(bingo_detail_box)
	bingo_keys = []
	var names: Dictionary = {}
	for creature in data.get("creatures", []):
		var key = str(creature.get("species_key", ""))
		if not key.is_empty() and not names.has(key):
			names[key] = str(creature.get("species_name", "Unknown"))
	var ordered: Array = names.keys()
	ordered.sort_custom(func(a, b): return str(names[a]).to_lower() < str(names[b]).to_lower())
	for key in ordered:
		bingo_keys.append(key)
		bingo_species.add_item(str(names[key]))
	bingo_species.item_selected.connect(_bingo_species_changed)
	bingo_search.text_changed.connect(func(_value): _draw_bingo_grid())
	bingo_order.item_selected.connect(func(_value): _draw_bingo_grid())
	bingo_filter.item_selected.connect(func(_value): _draw_bingo_grid())
	if bingo_keys.is_empty():
		bingo_species.add_item("Import a creature first")
		bingo_species.disabled = true
		bingo_summary.text = "Import a creature to start Color Bingo."
		bingo_detail_box.add_child(_label("Select a species first.", 16, MUTED))
		return
	var preferred = bingo_keys.find(selected_key)
	bingo_species.select(preferred if preferred >= 0 else 0)
	_bingo_species_changed(bingo_species.selected)

func _bingo_species_changed(index: int) -> void:
	if index < 0 or index >= bingo_keys.size():
		return
	var key = str(bingo_keys[index])
	var specimen: Dictionary = {}
	for creature in data.get("creatures", []):
		if str(creature.get("species_key", "")) == key:
			specimen = creature
			break
	bingo_rows = BingoScript.build(data.get("creatures", []), key, specimen.get("region_names", null), palette)
	if bingo_color_id == 0:
		for row in bingo_rows:
			if row["defined"] and int(row["found"]) > 0:
				bingo_color_id = int(row["id"])
				break
		if bingo_color_id == 0:
			bingo_color_id = 1
	var complete = 0
	var undefined = 0
	for row in bingo_rows:
		if row["status"] == "bingo":
			complete += 1
		elif row["status"] == "undefined":
			undefined += 1
	bingo_summary.text = "%s completed  •  %s IDs without color data  •  255 total" % [complete, undefined]
	_draw_bingo_grid()
	_bingo_detail(bingo_color_id)

func _draw_bingo_grid() -> void:
	if not is_instance_valid(bingo_grid):
		return
	_clear(bingo_grid)
	var rows = BingoScript.filtered(bingo_rows, bingo_search.text, bingo_filter.selected, bingo_order.selected)
	if rows.is_empty():
		bingo_grid.add_child(_label("No colors match this filter.", 15, MUTED))
		return
	for row in rows:
		var card = Button.new()
		card.custom_minimum_size = Vector2(163, 32)
		card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		card.tooltip_text = "Color %s: %s" % [row["id"], row["name"]]
		var active = int(row["id"]) == bingo_color_id
		var border = CYAN if active else (GREEN if row["status"] == "bingo" else Color("#29495a"))
		card.add_theme_stylebox_override("normal", _style(Color("#104656") if active else Color("#102b3a"), border, 4))
		card.add_theme_stylebox_override("hover", _style(Color("#174658"), CYAN, 4))
		card.add_theme_stylebox_override("pressed", _style(Color("#104656"), CYAN, 4))
		var id = int(row["id"])
		card.pressed.connect(func(): bingo_color_id = id; bingo_carrier_page = 0; _draw_bingo_grid(); _bingo_detail(id))
		var line = HBoxContainer.new()
		line.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		line.offset_left = 6
		line.offset_right = -6
		line.add_theme_constant_override("separation", 6)
		line.mouse_filter = Control.MOUSE_FILTER_IGNORE
		card.add_child(line)
		var region = {"state": "explicit" if row["defined"] else "unknown", "id": id if row["defined"] else null, "raw": row.get("rgba", [])}
		var swatch = _swatch(region, false)
		if not row["defined"]:
			swatch.get_child(0).text = str(id)
		swatch.mouse_filter = Control.MOUSE_FILTER_IGNORE
		line.add_child(swatch)
		var name = _label(str(row["name"]), 14, TEXT)
		name.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		name.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		name.mouse_filter = Control.MOUSE_FILTER_IGNORE
		line.add_child(name)
		var status = str(row["status"])
		var suffix = "No data" if status == "undefined" else ("BINGO" if status == "bingo" else ("%s/%s ?" % [row["found"], row["total"]] if status == "unknown" else "%s/%s" % [row["found"], row["total"]]))
		var badge = _label(suffix, 12, GREEN if status == "bingo" else (Color("#f5ce7d") if status == "unknown" else MUTED))
		badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
		line.add_child(badge)
		bingo_grid.add_child(card)

func _bingo_detail(id: int) -> void:
	if not is_instance_valid(bingo_detail_box):
		return
	_clear(bingo_detail_box)
	_preview_heading(bingo_detail_box, "Color details")
	if id < 1 or id > 255 or bingo_species.selected < 0 or bingo_species.selected >= bingo_keys.size():
		var hint = _label("Select a color to see its regions and carriers.", 16, MUTED)
		hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		bingo_detail_box.add_child(hint)
		return
	var target: Dictionary = palette.get_color(id)
	if target.is_empty():
		bingo_detail_box.add_child(_label("Color ID %s" % id, 23, TEXT))
		var unknown_label = _label("This ID is not in the bundled color data yet. It is not counted as complete or missing.", 15, MUTED)
		unknown_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		bingo_detail_box.add_child(unknown_label)
		return
	var key = str(bingo_keys[bingo_species.selected])
	var example: Dictionary = {}
	for creature in data.get("creatures", []):
		if str(creature.get("species_key", "")) == key:
			example = creature
			break
	if example.is_empty():
		return
	var color_title = _label(str(target["name"]), 25, TEXT)
	color_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	var color_heading = VBoxContainer.new()
	color_heading.add_theme_constant_override("separation", 1)
	color_heading.add_child(color_title)
	color_heading.add_child(_label("Color ID #%s" % id, 13, MUTED))
	bingo_detail_box.add_child(color_heading)
	var mode = HBoxContainer.new()
	bingo_detail_box.add_child(mode)
	var coverage_button = _button("Coverage", bingo_detail_tab == 0)
	coverage_button.name = "BingoCoverageTab"
	var carriers_button = _button("Carriers", bingo_detail_tab == 1)
	carriers_button.name = "BingoCarriersTab"
	mode.add_child(coverage_button)
	mode.add_child(carriers_button)
	var overview = VBoxContainer.new()
	overview.add_theme_constant_override("separation", 5)
	overview.visible = bingo_detail_tab == 0
	bingo_detail_box.add_child(overview)
	var carrier_section = VBoxContainer.new()
	carrier_section.size_flags_vertical = Control.SIZE_EXPAND_FILL
	carrier_section.visible = bingo_detail_tab == 1
	bingo_detail_box.add_child(carrier_section)
	coverage_button.pressed.connect(func(): bingo_detail_tab = 0; _bingo_detail(id))
	carriers_button.pressed.connect(func(): bingo_detail_tab = 1; _bingo_detail(id))
	var desired = example.duplicate(true)
	var regions: Array = []
	for i in range(6):
		var active = typeof(example.get("region_names")) == TYPE_ARRAY and example["region_names"].size() > i and example["region_names"][i] != null
		regions.append({"state": "explicit" if active else "empty", "id": id if active else null, "candidates": [id] if active else [], "raw": target["rgba"] if active else []})
	desired["regions"] = regions
	var picture = _preview(desired, Vector2(0, 119))
	overview.add_child(picture)
	if picture.texture == null:
		picture.hide()
		overview.add_child(_label("Preview image not included for this species.", 13, MUTED))
	var goal = GoalScript.calculate(data.get("creatures", []), key, example.get("region_names", null), id)
	if goal["status"] == "unknown_regions":
		var warning = _label("Visible regions are unknown for this species.", 15, Color("#f5ce7d"))
		warning.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		overview.add_child(warning)
		return
	var title = "%s / %s regions collected" % [goal["found"], goal["total"]]
	if goal["status"] == "complete":
		title += "  •  BINGO"
	overview.add_child(_label(title, 18, GREEN if goal["status"] == "complete" else TEXT))
	var note = _label("Collection coverage across creatures; not a guaranteed pair or solid baby.", 12, MUTED)
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	overview.add_child(note)
	overview.add_child(_label("Region summary", 17, TEXT))
	for region in goal["regions"]:
		if region["status"] == "unused":
			continue
		var status_text = "FOUND" if region["status"] == "found" else ("UNKNOWN" if region["status"] == "unknown" else "NOT FOUND")
		var status_color = GREEN if region["status"] == "found" else (Color("#f5ce7d") if region["status"] == "unknown" else RED)
		var region_caption = _label("R%s · %s — %s" % [region["region"], region["name"], status_text], 14, status_color)
		region_caption.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		overview.add_child(region_caption)
	carrier_section.add_child(_label("Creatures by region", 17, TEXT))
	var stars_note = _label("Each ★ is one confirmed matching region on that creature. Unknown colors are not counted.", 12, MUTED)
	stars_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	carrier_section.add_child(stars_note)
	if bingo_detail_tab != 1:
		return
	var star_filter = _option()
	star_filter.name = "BingoStarFilter"
	star_filter.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	star_filter.add_item("All star ratings", 0)
	for stars in range(int(goal["total"]), 0, -1):
		star_filter.add_item("%s %s" % [stars, "star" if stars == 1 else "stars"], stars)
	carrier_section.add_child(star_filter)
	var carrier_rows = VBoxContainer.new()
	carrier_rows.name = "BingoCarrierRows"
	carrier_rows.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	carrier_rows.add_theme_constant_override("separation", 3)
	var carriers_scroll = ScrollContainer.new()
	carriers_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	carriers_scroll.custom_minimum_size.y = 100
	carriers_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	carrier_section.add_child(carriers_scroll)
	carriers_scroll.add_child(carrier_rows)
	carriers_scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_NEVER
	bingo_carrier_footer = HBoxContainer.new()
	carrier_section.add_child(bingo_carrier_footer)
	var match_counts = BingoScript.carrier_match_counts(goal)
	star_filter.item_selected.connect(func(index):
		bingo_carrier_page = 0
		_render_bingo_carriers(carrier_rows, goal, match_counts, star_filter.get_item_id(index))
	)
	_render_bingo_carriers(carrier_rows, goal, match_counts, 0)

func _render_bingo_carriers(host: VBoxContainer, goal: Dictionary, match_counts: Dictionary, filter_stars: int) -> void:
	if not is_instance_valid(host):
		return
	_clear(host)
	var rows: Array = []
	var total_matches = 0
	for region in goal["regions"]:
		if region["status"] == "unused" or region["status"] == "missing":
			continue
		var carriers: Array = region.get("carriers", [])
		var ids: Array = region.get("carrier_ids", [])
		var ranked: Array = []
		for i in range(carriers.size()):
			var carrier_id = str(ids[i]) if i < ids.size() else ""
			var stars = int(match_counts.get(carrier_id, 0)) if not carrier_id.is_empty() else 0
			if filter_stars > 0 and stars != filter_stars:
				continue
			ranked.append({"label": str(carriers[i]), "local_id": carrier_id, "stars": stars})
		ranked.sort_custom(func(a, b):
			if int(a["stars"]) != int(b["stars"]):
				return int(a["stars"]) > int(b["stars"])
			var left = str(a["label"]).to_lower()
			var right = str(b["label"]).to_lower()
			if left != right:
				return left < right
			return str(a["local_id"]) < str(b["local_id"])
		)
		if filter_stars > 0 and ranked.is_empty():
			continue
		rows.append({"region": region, "header": true})
		rows.append_array(ranked)
		total_matches += ranked.size()
	if total_matches == 0 and filter_stars > 0:
		host.add_child(_label("No creatures with this star rating.", 13, MUTED))
		_clear(bingo_carrier_footer)
		return
	var per_page = maxi(6, floori((_desktop_height() - 224.0) / 23.0))
	bingo_carrier_page = clampi(bingo_carrier_page, 0, maxi(0, ceili(float(rows.size()) / float(per_page)) - 1))
	var start = bingo_carrier_page * per_page
	var finish = mini(start + per_page, rows.size())
	# An overflow page retains the region label even when the group started earlier.
	var header_index = start
	while header_index > 0 and not rows[header_index].has("header"):
		header_index -= 1
	if header_index < start:
		_bingo_carrier_heading(host, rows[header_index]["region"], true)
	for i in range(start, finish):
		var item: Dictionary = rows[i]
		if item.has("header"):
			_bingo_carrier_heading(host, item["region"])
			continue
		var carrier_id = str(item["local_id"])
		var count = int(item["stars"])
		var row = HBoxContainer.new()
		row.name = "BingoCarrierRow"
		row.add_theme_constant_override("separation", 5)
		var star_label = _label("★".repeat(count) if count > 0 else "?", 12, Color("#ffd66e") if count > 0 else MUTED)
		star_label.name = "BingoCarrierStars"
		star_label.custom_minimum_size.x = 60
		star_label.tooltip_text = "%s confirmed matching regions" % count
		row.add_child(star_label)
		var button = Button.new()
		button.name = "BingoCarrierButton"
		button.text = str(item["label"])
		button.alignment = HORIZONTAL_ALIGNMENT_LEFT
		button.clip_text = true
		button.flat = true
		button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		button.tooltip_text = "%s · Open creature" % item["label"]
		button.add_theme_font_size_override("font_size", 12)
		button.add_theme_color_override("font_color", TEXT)
		button.add_theme_color_override("font_hover_color", Appearance.accent(appearance))
		button.disabled = carrier_id.is_empty()
		button.pressed.connect(_open_carrier.bind(carrier_id))
		row.add_child(button)
		host.add_child(row)
	_result_page_controls(bingo_carrier_footer, rows.size(), bingo_carrier_page, per_page, func(index):
		bingo_carrier_page = index
		_render_bingo_carriers(host, goal, match_counts, filter_stars)
	)

func _bingo_carrier_heading(host: VBoxContainer, region: Dictionary, continued: bool = false) -> void:
	var label = "R%s · %s%s" % [region["region"], region["name"], " (continued)" if continued else " — " + str(region["status"]).to_upper()]
	var caption = _label(label, 13, GREEN if region["status"] == "found" else MUTED)
	caption.clip_text = true
	caption.tooltip_text = label
	host.add_child(caption)

func _open_carrier(id: String) -> void:
	library_species_key = ""
	selected_id = id
	library_preview_open = true
	_show_library()
	var rows = _filtered()
	for i in range(rows.size()):
		if str(rows[i].get("local_id", "")) == id:
			page_index = int(i / library_rows_per_page)
			_render_rows()
			break
	_render_details()


func _show_goals() -> void:
	selected_page = "goals"
	_activate_nav("goals")
	_workspace_setup()
	_page_heading("Color Goals")
	var controls_panel = _panel(Color("#0a1e2b"), Color("#25485c"))
	middle.add_child(controls_panel)
	var controls = VBoxContainer.new()
	controls.add_theme_constant_override("separation", 10)
	controls_panel.add_child(controls)
	var row_one = HBoxContainer.new()
	row_one.add_theme_constant_override("separation", 10)
	controls.add_child(row_one)
	goal_species = _option()
	goal_species.fit_to_longest_item = false
	goal_species.clip_text = true
	goal_species.custom_minimum_size.x = 112
	goal_species.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row_one.add_child(goal_species)
	goal_color = _text_input("Target color ID or exact name")
	goal_color.custom_minimum_size.x = 145
	goal_color.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row_one.add_child(goal_color)
	var row_two = HBoxContainer.new()
	row_two.add_theme_constant_override("separation", 10)
	controls.add_child(row_two)
	goal_stat_1 = _option()
	goal_stat_2 = _option()
	for stat in ["None", "Health", "Stamina", "Weight", "Melee"]:
		goal_stat_1.add_item(stat)
		goal_stat_2.add_item(stat)
	goal_stat_1.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	goal_stat_2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row_two.add_child(goal_stat_1)
	row_two.add_child(goal_stat_2)
	var save = _button("Save goal and note", true)
	save.pressed.connect(_save_goal)
	row_two.add_child(save)
	goal_header_info = _label("Enter an ID or exact color name.", 13, MUTED)
	goal_header_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	controls.add_child(goal_header_info)
	var note_title = _label("Notes", 14, MUTED)
	controls.add_child(note_title)
	goal_note = TextEdit.new()
	goal_note.custom_minimum_size.y = 56
	goal_note.placeholder_text = "Write what you still need, breeding reminders, or anything else..."
	goal_note.add_theme_font_size_override("font_size", 14)
	goal_note.add_theme_color_override("font_color", TEXT)
	goal_note.add_theme_stylebox_override("normal", _style(Color("#091b27"), Color("#35566a"), 6))
	goal_note.add_theme_stylebox_override("focus", _style(Color("#0b2230"), CYAN, 6))
	controls.add_child(goal_note)
	var result_panel = _panel(Color("#0a1e2b"), Color("#25485c"))
	result_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	middle.add_child(result_panel)
	var scroll = ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	result_panel.add_child(scroll)
	goal_result = VBoxContainer.new()
	goal_result.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	goal_result.add_theme_constant_override("separation", 9)
	scroll.add_child(goal_result)
	_paged_scroll(scroll)
	var preview_panel = _panel(Color("#0a1e2b"), Color("#25485c"), "details")
	preview_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	details.add_child(preview_panel)
	var preview_scroll = ScrollContainer.new()
	preview_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	preview_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	preview_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	preview_panel.add_child(preview_scroll)
	goal_preview_host = VBoxContainer.new()
	goal_preview_host.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	goal_preview_host.size_flags_vertical = Control.SIZE_EXPAND_FILL
	goal_preview_host.add_theme_constant_override("separation", 6)
	preview_scroll.add_child(goal_preview_host)
	goal_keys = []
	var unique: Dictionary = {}
	for creature in data.get("creatures", []):
		var key = str(creature.get("species_key", ""))
		if not key.is_empty() and not unique.has(key):
			unique[key] = str(creature.get("species_name", "Unknown"))
	var ordered: Array = unique.keys()
	ordered.sort_custom(func(a, b): return str(unique[a]).to_lower() < str(unique[b]).to_lower())
	for key in ordered:
		goal_keys.append(key)
		goal_species.add_item(str(unique[key]))
	goal_species.item_selected.connect(_goal_species_changed)
	goal_color.text_changed.connect(func(_value): _refresh_goal())
	goal_stat_1.item_selected.connect(func(_value): _refresh_goal())
	goal_stat_2.item_selected.connect(func(_value): _refresh_goal())
	if goal_keys.is_empty():
		goal_species.add_item("Import a creature first")
		goal_species.disabled = true
		goal_result.add_child(_label("Import at least one dino to start a goal.", 16, MUTED))
		goal_preview_host.add_child(_label("Goal preview", 22, TEXT))
	else:
		_goal_species_changed(0)

func _goal_species_changed(index: int) -> void:
	if index < 0 or index >= goal_keys.size():
		return
	var saved: Dictionary = data.get("goals", {}).get(str(goal_keys[index]), {})
	goal_color.text = str(saved.get("color_id", ""))
	goal_stat_1.select(clampi(int(saved.get("stat_1", 0)), 0, 4))
	goal_stat_2.select(clampi(int(saved.get("stat_2", 0)), 0, 4))
	goal_note.text = str(saved.get("note", ""))
	_refresh_goal()

func _resolve_goal_color(value: String) -> Dictionary:
	var query = value.strip_edges()
	if query.is_valid_int():
		return palette.get_color(int(query))
	var exact: Array = []
	for item in palette.search(query):
		if str(item.get("name", "")).to_lower() == query.to_lower():
			exact.append(item)
	if exact.size() == 1:
		return exact[0]
	return {}

func _refresh_goal() -> void:
	if not is_instance_valid(goal_result) or goal_keys.is_empty():
		return
	_clear(goal_result)
	_clear(goal_preview_host)
	var index = goal_species.selected
	if index < 0 or index >= goal_keys.size():
		return
	var key = str(goal_keys[index])
	var target = _resolve_goal_color(goal_color.text)
	goal_preview_host.add_child(_label("Goal Preview", 23, TEXT))
	if target.is_empty():
		var suggestions: Array = palette.search(goal_color.text.strip_edges()) if not goal_color.text.strip_edges().is_empty() else []
		var examples: Array = []
		for i in range(mini(5, suggestions.size())):
			examples.append("%s: %s" % [str(suggestions[i]["id"]), str(suggestions[i]["name"])])
		goal_header_info.text = "Matches: " + ", ".join(examples) if not examples.is_empty() else "Enter a valid color ID or exact name."
		goal_result.add_child(_label("Choose a target color to check your collection.", 16, MUTED))
		goal_preview_host.add_child(_label("Your target colors will appear here.", 15, MUTED))
		return
	goal_header_info.text = "Target: %s (ID %s)" % [str(target["name"]), str(int(target["id"]))]
	var example: Dictionary = {}
	for creature in data.get("creatures", []):
		if str(creature.get("species_key", "")) == key:
			example = creature
			break
	if example.is_empty():
		goal_result.add_child(_label("No creatures for this species.", 16, MUTED))
		return
	var result = GoalScript.calculate(data.get("creatures", []), key, example.get("region_names", null), int(target["id"]))
	if result["status"] == "unknown_regions":
		goal_result.add_child(_label("Visible regions are unknown. Coverage cannot be confirmed for this species yet.", 16, Color("#f5ce7d")))
	else:
		var title = "%s / %s regions collected" % [result["found"], result["total"]]
		if int(result["unknown"]) > 0:
			title += "  •  %s unknown" % result["unknown"]
		goal_result.add_child(_label(title, 21, TEXT))
		var progress = ProgressBar.new()
		progress.min_value = 0
		progress.max_value = maxi(1, int(result["total"]))
		progress.value = int(result["found"])
		progress.custom_minimum_size.y = 22
		progress.show_percentage = false
		goal_result.add_child(progress)
		for region in result["regions"]:
			if region["status"] == "unused":
				continue
			var status = str(region["status"])
			var line = "Region %s  •  %s: " % [region["region"], region["name"]]
			var color = MUTED
			if status == "found":
				var carriers: Array = region.get("carriers", [])
				line += "FOUND · %s" % ", ".join(carriers.slice(0, 2))
				if carriers.size() > 2:
					line += " +%s more" % (carriers.size() - 2)
				color = GREEN
			elif status == "missing":
				line += "NOT FOUND in imported creatures"
				color = RED
			else:
				line += "UNKNOWN / POSSIBLE — needs review"
				color = Color("#f5ce7d")
			var info = _label(line, 15, color)
			info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			if status == "found":
				info.tooltip_text = ", ".join(region.get("carriers", []))
			goal_result.add_child(info)
	var explanation = _label("Coverage means colors collected across your library. It does not prove a breeding pair or inherited stats.", 13, MUTED)
	explanation.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	goal_result.add_child(explanation)
	goal_result.add_child(_label("Focus stats · highest displayed values", 19, TEXT))
	for choice in [goal_stat_1.selected, goal_stat_2.selected]:
		var stat_key = ["", "health", "stamina", "weight", "melee damage"][int(choice)]
		if stat_key.is_empty():
			continue
		var best = -INF
		var owners: Array = []
		for creature in data.get("creatures", []):
			if str(creature.get("species_key", "")) != key:
				continue
			var value = _stat_number(creature, stat_key)
			if value == null:
				continue
			if float(value) > best:
				best = float(value)
				owners = [str(creature.get("name", "Unnamed"))]
			elif is_equal_approx(float(value), best):
				owners.append(str(creature.get("name", "Unnamed")))
		var text = stat_key.capitalize() + ": "
		if owners.is_empty():
			text += "Unknown"
		else:
			text += ("%.1f%%" % best if stat_key == "melee damage" else "%.1f" % best) + " — " + ", ".join(owners.slice(0, 2)) + (" +%s more" % (owners.size() - 2) if owners.size() > 2 else "")
		var line = _label(text, 15, TEXT)
		line.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		goal_result.add_child(line)
	var goal_creature = example.duplicate(true)
	var desired: Array = []
	for i in range(6):
		var active = typeof(example.get("region_names")) == TYPE_ARRAY and example["region_names"].size() > i and example["region_names"][i] != null
		desired.append({"state": "explicit" if active else "empty", "id": int(target["id"]) if active else null, "candidates": [int(target["id"])] if active else [], "raw": target["rgba"] if active else []})
	goal_creature["regions"] = desired
	var preview = _preview(goal_creature, Vector2(0, 166))
	preview.size_flags_vertical = Control.SIZE_EXPAND_FILL
	goal_preview_host.add_child(preview)
	if preview.texture == null:
		goal_preview_host.add_child(_label("No image available for this species yet.", 14, MUTED))
	var target_label = _label("%s\n%s (ID %s)" % [str(example.get("species_name", "Creature")), str(target["name"]), str(int(target["id"]))], 17, TEXT)
	target_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	target_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	goal_preview_host.add_child(target_label)
	var hint = _label("Preview only. This does not change the creature in ARK.", 12, MUTED)
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	goal_preview_host.add_child(hint)

func _save_goal() -> void:
	if goal_keys.is_empty():
		return
	var target = _resolve_goal_color(goal_color.text)
	if target.is_empty():
		_show_message("Choose a color", "Enter a valid color ID or its exact name.")
		return
	var next_data: Dictionary = data.duplicate(true)
	var key = str(goal_keys[goal_species.selected])
	next_data["goals"][key] = {"color_id": int(target["id"]), "stat_1": goal_stat_1.selected, "stat_2": goal_stat_2.selected, "note": goal_note.text}
	var saved = storage.save_data(next_data)
	if not saved.get("ok", false):
		_show_message("Could not save", str(saved.get("error", "Goal was not saved.")))
		return
	data = next_data
	database_revision += 1
	_show_message("Goal saved", "Your target color, focus stats, and note were saved on this PC.")

func _exit_tree() -> void:
	if import_thread != null and import_thread.is_started():
		import_thread.wait_to_finish()
