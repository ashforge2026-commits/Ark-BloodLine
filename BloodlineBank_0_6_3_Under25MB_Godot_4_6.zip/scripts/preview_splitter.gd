extends Control

signal width_changed(width: int)
signal resize_finished

var panel: Control
var drag_start: float
var width_start: float
var dragging = false

func _ready() -> void:
	custom_minimum_size.x = 8
	mouse_default_cursor_shape = Control.CURSOR_HSIZE
	focus_mode = Control.FOCUS_ALL
	tooltip_text = "Drag to resize preview. Left and Right arrows also resize."
	mouse_entered.connect(queue_redraw)
	mouse_exited.connect(queue_redraw)
	focus_entered.connect(queue_redraw)
	focus_exited.connect(queue_redraw)

func _draw() -> void:
	var active = dragging or has_focus() or Rect2(Vector2.ZERO, size).has_point(get_local_mouse_position())
	draw_line(Vector2(size.x / 2, size.y / 2 - 18), Vector2(size.x / 2, size.y / 2 + 18),
		Color("#35d5f4") if active else Color("#486a7b"), 2.0)

func _gui_input(event: InputEvent) -> void:
	if not is_instance_valid(panel):
		return
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		if event.pressed:
			grab_focus()
			dragging = true
			drag_start = event.global_position.x
			width_start = panel.size.x
		elif dragging:
			dragging = false
			resize_finished.emit()
		queue_redraw()
		accept_event()
	elif event is InputEventMouseMotion and dragging:
		width_changed.emit(roundi(width_start + drag_start - event.global_position.x))
		accept_event()
	elif event is InputEventKey and event.pressed and event.keycode in [KEY_LEFT, KEY_RIGHT]:
		width_changed.emit(roundi(panel.size.x) + (16 if event.keycode == KEY_LEFT else -16))
		resize_finished.emit()
		accept_event()
