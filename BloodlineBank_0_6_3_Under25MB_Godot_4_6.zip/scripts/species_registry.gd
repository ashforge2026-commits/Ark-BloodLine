extends RefCounted

const UNVERIFIED_WARNING = "Species or variant not recognized; region coverage is unknown."
const DEFAULT_SPECIES = "X-Otter"

var by_blueprint: Dictionary = {}
var catalog_subjects: Dictionary = {}
var portraits: Dictionary = {}
var catalog: Array[Dictionary] = []

func _init() -> void:
	var parsed = JSON.parse_string(FileAccess.get_file_as_string("res://data/species_registry.json"))
	if typeof(parsed) != TYPE_DICTIONARY:
		return
	for item in parsed.get("species", []):
		var key = normalize_blueprint(str(item.get("blueprint", "")))
		if not key.is_empty():
			by_blueprint[key] = item
			catalog_subjects[item["name"]] = key
	var manifest = JSON.parse_string(FileAccess.get_file_as_string("res://data/creature_catalog.json"))
	if typeof(manifest) == TYPE_DICTIONARY:
		portraits = manifest.get("portraits", {})
		for label in manifest.get("catalog", {}):
			var key = normalize_blueprint(manifest["catalog"][label])
			if by_blueprint.has(key):
				catalog_subjects[label] = key
	for label in catalog_subjects:
		catalog.append({"name": label, "key": catalog_subjects[label]})
	catalog.sort_custom(func(a, b): return a["name"].nocasecmp_to(b["name"]) < 0)

static func normalize_blueprint(value: String) -> String:
	var v = value.strip_edges()
	if v.begins_with("Blueprint'"):
		v = v.substr(10)
	v = v.trim_suffix("'").trim_suffix("\"")
	if v.to_lower().ends_with("_c"):
		v = v.left(v.length() - 2)
	return v.to_lower()

func resolve(blueprint: String, tag: String) -> Dictionary:
	var key = normalize_blueprint(blueprint)
	var recognized = subject_for_key(key)
	if not recognized.is_empty():
		return recognized
	# Keep unknown variants separate instead of matching them on display name.
	var label = tag.strip_edges().trim_prefix("\"").trim_suffix("\"")
	if label.is_empty():
		label = "Unknown species"
	if key.is_empty():
		key = "unknown:" + label.to_lower()
	return {"key": key, "name": label, "regions": null, "verified_species": false}

func subject_for_key(key: String) -> Dictionary:
	if not by_blueprint.has(key):
		return {}
	var item: Dictionary = by_blueprint[key]
	return {"key": key, "name": item["name"], "regions": item.get("regions", null), "verified_species": true}

func lab_subject(name: String) -> Dictionary:
	return subject_for_key(str(catalog_subjects.get(name, "")))

func can_use_lab(creature: Dictionary) -> bool:
	return creature.get("verified_species", false) and by_blueprint.has(creature.get("species_key", ""))

func poses_for(creature: Dictionary) -> Array:
	if not creature.get("verified_species", false):
		return []
	return portraits.get(creature.get("species_name", ""), [])

func default_pose(creature: Dictionary) -> int:
	var sex = str(creature.get("sex", ""))
	if sex == "Female" or sex == "Male":
		var poses = poses_for(creature)
		for index in range(poses.size()):
			if poses[index]["label"] == sex:
				return index
	return 0

func images_for(creature: Dictionary, pose: int = -1) -> Array:
	var poses = poses_for(creature)
	if poses.is_empty():
		return []
	if pose == -1:
		pose = default_pose(creature)
	return poses[clampi(pose, 0, poses.size() - 1)]["paths"]

func recognize_saved_creatures(creatures: Array) -> void:
	for creature in creatures:
		if typeof(creature) != TYPE_DICTIONARY or creature.get("verified_species", false):
			continue
		var subject = subject_for_key(normalize_blueprint(str(creature.get("blueprint", ""))))
		if subject.is_empty():
			continue
		creature["species_key"] = subject["key"]
		creature["species_name"] = subject["name"]
		var regions = subject["regions"]
		creature["region_names"] = regions.duplicate() if typeof(regions) == TYPE_ARRAY else null
		creature["verified_species"] = true
		var warnings = creature.get("warnings", [])
		if typeof(warnings) == TYPE_ARRAY:
			warnings.erase(UNVERIFIED_WARNING)
