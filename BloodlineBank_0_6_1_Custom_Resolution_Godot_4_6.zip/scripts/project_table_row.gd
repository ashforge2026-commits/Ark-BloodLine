extends PanelContainer

# Otters still reorder from the existing drag handle. 0.4.1 also accepts
# WHOLE-LIST drags anywhere on the non-interactive part of a creature row,
# so moving a batch above a 27-otter Main List doesn't require scrolling up
# to a tiny header target.
signal reordered(source_id: String, target_id: String, after: bool)
signal list_dropped_on_group(source_list_id: String, target_list_id: String)

var project_id: String = ""
var creature_id: String = ""
var list_id: String = ""

func _can_drop_data(_at_position: Vector2, payload: Variant) -> bool:
	if not (payload is Dictionary) or str(payload.get("project_id", "")) != project_id:
		return false
	if str(payload.get("type", "")) == "bloodline_project_row":
		return not str(payload.get("id", "")).is_empty() and str(payload.get("id", "")) != creature_id
	if str(payload.get("type", "")) == "bloodline_project_list":
		return not str(payload.get("list_id", "")).is_empty() and str(payload.get("list_id", "")) != list_id
	return false

func _drop_data(at_position: Vector2, payload: Variant) -> void:
	if not _can_drop_data(at_position, payload):
		return
	if str(payload["type"]) == "bloodline_project_row":
		reordered.emit(str(payload["id"]), creature_id, at_position.y >= size.y * 0.5)
	elif str(payload["type"]) == "bloodline_project_list":
		list_dropped_on_group.emit(str(payload["list_id"]), list_id)
