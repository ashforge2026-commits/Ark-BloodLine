extends RefCounted

const PATH = "user://display.cfg"
const MIN_SIZE = Vector2i(960, 640)
const MAX_SIZE = Vector2i(16384, 16384)
enum Mode { WINDOWED, BORDERLESS, MAXIMIZED, FULLSCREEN, EXCLUSIVE }
const MODE_LABELS = [
	"Windowed", "Borderless window", "Maximized", "Fullscreen", "Exclusive fullscreen"
]

static func _read_config() -> ConfigFile:
	var config = ConfigFile.new()
	config.load(PATH)
	return config

static func load_mode() -> Mode:
	var value = _read_config().get_value("display", "window_mode", Mode.WINDOWED)
	if value is int and value >= 0 and value < MODE_LABELS.size():
		return value as Mode
	return Mode.WINDOWED

static func save_mode(mode: Mode) -> Error:
	var config = _read_config()
	config.set_value("display", "window_mode", mode)
	return config.save(PATH)

static func default_size() -> Vector2i:
	return Vector2i(
		ProjectSettings.get_setting("display/window/size/window_width_override", 1280),
		ProjectSettings.get_setting("display/window/size/window_height_override", 720)
	)

static func valid_size(size: Vector2i) -> bool:
	return size == size.clamp(MIN_SIZE, MAX_SIZE)

static func load_size() -> Vector2i:
	var value = _read_config().get_value("display", "window_size", Vector2i.ZERO)
	return value if value is Vector2i and valid_size(value) else Vector2i.ZERO

static func save_size(size: Vector2i) -> Error:
	if not valid_size(size):
		return ERR_INVALID_PARAMETER
	var config = _read_config()
	config.set_value("display", "window_size", size)
	return config.save(PATH)

static func uses_custom_size(mode: Mode) -> bool:
	return mode == Mode.WINDOWED or mode == Mode.BORDERLESS

static func apply_size(window: Window, size: Vector2i) -> Vector2i:
	var usable = DisplayServer.screen_get_usable_rect(DisplayServer.SCREEN_OF_MAIN_WINDOW)
	var frame = (window.get_size_with_decorations() - window.size).max(Vector2i.ZERO)
	var available = usable.size - frame
	var target = size.min(available) if available.x > 0 and available.y > 0 else size
	window.size = target
	if usable.has_area():
		window.move_to_center()
	return target

static func apply(window: Window, mode: Mode) -> void:
	match mode:
		Mode.WINDOWED, Mode.BORDERLESS:
			window.mode = Window.MODE_WINDOWED
			window.borderless = mode == Mode.BORDERLESS
		Mode.MAXIMIZED:
			window.borderless = false
			window.mode = Window.MODE_MAXIMIZED
		Mode.FULLSCREEN:
			window.borderless = false
			window.mode = Window.MODE_FULLSCREEN
		Mode.EXCLUSIVE:
			window.borderless = false
			window.mode = Window.MODE_EXCLUSIVE_FULLSCREEN
