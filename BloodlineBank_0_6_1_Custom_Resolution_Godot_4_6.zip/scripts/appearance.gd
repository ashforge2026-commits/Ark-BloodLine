extends RefCounted

const PATH = "user://appearance.cfg"
const DEFAULTS = {
	"background": Color("#071521"),
	"sidebar": Color("#091b29"),
	"panels": Color("#0d2231"),
	"details": Color("#0a1e2b"),
	"accent": Color("#35d5f4"),
}

static func load_colors() -> Dictionary:
	var colors = DEFAULTS.duplicate()
	var config = ConfigFile.new()
	if config.load(PATH) == OK:
		for key in DEFAULTS:
			var saved = config.get_value("appearance", key, DEFAULTS[key])
			if saved is Color:
				colors[key] = saved
		if config.has_section_key("appearance", "theme_color"):
			var base = config.get_value("appearance", "theme_color")
			if base is Color:
				colors["theme_color"] = base
	return colors

static func save_colors(colors: Dictionary) -> Error:
	var config = ConfigFile.new()
	for key in DEFAULTS:
		config.set_value("appearance", key, colors[key])
	if colors.has("theme_color"):
		config.set_value("appearance", "theme_color", colors["theme_color"])
	return config.save(PATH)

static func from_color(base: Color) -> Dictionary:
	var colors = {"theme_color": base}
	for key in ["background", "sidebar", "panels", "details"]:
		var offset = DEFAULTS[key].v - DEFAULTS["background"].v
		var value = 0.18 * base.v + offset
		colors[key] = Color.from_hsv(base.h, base.s, value)
	colors["accent"] = Color.from_hsv(base.h, base.s * 0.75, maxf(0.90, base.v))
	return colors

# Keep the depth between rows, panels and controls while tinting their surfaces.
static func surface(base: Color, colors: Dictionary, key: String = "panels") -> Color:
	var tint: Color = colors.get(key, DEFAULTS[key])
	if tint == DEFAULTS[key]:
		return base
	var value = clampf(0.6 * base.v + 0.4 * minf(tint.v, 0.28), 0.07, 0.43)
	return Color.from_hsv(tint.h, tint.s, value, base.a)

static func accent(colors: Dictionary) -> Color:
	var tint: Color = colors.get("accent", DEFAULTS["accent"])
	return Color.from_hsv(tint.h, minf(tint.s, 0.78), maxf(tint.v, 0.76))
