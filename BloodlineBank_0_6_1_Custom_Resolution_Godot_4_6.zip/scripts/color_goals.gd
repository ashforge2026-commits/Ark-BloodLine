extends RefCounted

static func carrier_label(creature: Dictionary) -> String:
	var label = str(creature.get("name", "Unnamed"))
	if creature.get("level", null) != null:
		label += " — Lvl " + str(int(creature["level"]))
	var sex = str(creature.get("sex", "Unknown"))
	if sex == "Male" or sex == "Female":
		label += " — " + sex
	return label

# One snapshot serves every color in Bingo and the single-color goal screen.
static func build_index(creatures: Array, species_key: String, region_names) -> Dictionary:
	if typeof(region_names) != TYPE_ARRAY or region_names.size() != 6:
		return {"valid": false, "regions": []}
	var entries: Array = []
	var metadata_unknown = false
	for i in range(6):
		if region_names[i] == null:
			entries.append({"kind": "unused", "name": "Unused"})
			continue
		var region_name = str(region_names[i])
		if region_name.is_empty() or region_name.to_lower() == "unknown":
			metadata_unknown = true
			entries.append({"kind": "metadata_unknown", "name": "Unknown region"})
			continue
		entries.append({"kind": "active", "name": region_name, "found": {}, "possible": {}, "unknown_count": 0})
	var species_count = 0
	for creature in creatures:
		if str(creature.get("species_key", "")) != species_key:
			continue
		species_count += 1
		var regions: Array = creature.get("regions", [])
		for i in range(6):
			var entry: Dictionary = entries[i]
			if entry["kind"] != "active":
				continue
			if regions.size() <= i or typeof(regions[i]) != TYPE_DICTIONARY:
				entry["unknown_count"] += 1
				continue
			var region: Dictionary = regions[i]
			var state = str(region.get("state", "unknown"))
			var id = region.get("id", null)
			if (state == "matched" or state == "explicit") and id != null:
				var color_id = int(id)
				if not entry["found"].has(color_id):
					entry["found"][color_id] = []
				entry["found"][color_id].append({"label": carrier_label(creature), "local_id": str(creature.get("local_id", ""))})
			elif state == "ambiguous":
				for candidate in region.get("candidates", []):
					var candidate_id = int(candidate)
					if not entry["possible"].has(candidate_id):
						entry["possible"][candidate_id] = []
					entry["possible"][candidate_id].append(carrier_label(creature))
			elif state == "unknown" or state == "empty":
				entry["unknown_count"] += 1
	return {"valid": true, "regions": entries, "metadata_unknown": metadata_unknown, "species_count": species_count}

static func calculate_indexed(index: Dictionary, target_id: int) -> Dictionary:
	if not index.get("valid", false):
		return {"status": "unknown_regions", "regions": [], "found": 0, "total": 0, "unknown": 0}
	var results: Array = []
	var total = 0
	var found_count = 0
	var unknown_count = 0
	for i in range(6):
		var entry: Dictionary = index["regions"][i]
		if entry["kind"] == "unused":
			results.append({"region": i, "name": "Unused", "status": "unused", "carriers": []})
			continue
		if entry["kind"] == "metadata_unknown":
			results.append({"region": i, "name": "Unknown region", "status": "unknown", "carriers": []})
			continue
		total += 1
		var found: Array = entry["found"].get(target_id, [])
		var possible: Array = entry["possible"].get(target_id, [])
		var carriers: Array = []
		var carrier_ids: Array = []
		for carrier in found:
			carriers.append(carrier["label"])
			carrier_ids.append(carrier["local_id"])
		var status = "missing"
		if not carriers.is_empty():
			status = "found"
			found_count += 1
		elif not possible.is_empty() or int(entry["unknown_count"]) > 0 or int(index["species_count"]) == 0:
			status = "unknown"
			unknown_count += 1
		results.append({"region": i, "name": entry["name"], "status": status, "carriers": carriers, "carrier_ids": carrier_ids, "possible": possible, "unknown_count": int(entry["unknown_count"])})
	var overall = "complete" if total > 0 and found_count == total and not index["metadata_unknown"] else "incomplete"
	if index["metadata_unknown"] or total == 0:
		overall = "unknown_regions"
	return {"status": overall, "regions": results, "found": found_count, "total": total, "unknown": unknown_count}

static func calculate(creatures: Array, species_key: String, region_names, target_id: int) -> Dictionary:
	return calculate_indexed(build_index(creatures, species_key, region_names), target_id)
