extends RefCounted

const ZipGuard = preload("res://scripts/zip_guard.gd")
var parser

func _init(parser_ref) -> void:
	parser = parser_ref

func _read_ini(path: String) -> Dictionary:
	var file = FileAccess.open(path, FileAccess.READ)
	if file == null:
		return {"ok": false, "error": "Cannot open the INI file."}
	if file.get_length() > ZipGuard.MAX_ENTRY:
		return {"ok": false, "error": "INI exceeds the 1 MB limit."}
	var bytes = file.get_buffer(file.get_length())
	file.close()
	var text = bytes.get_string_from_utf8()
	if text.is_empty() and not bytes.is_empty():
		return {"ok": false, "error": "INI is not readable UTF-8 text."}
	return {"ok": true, "files": [{"path": path.get_file(), "text": text}], "errors": []}

func _read_zip(path: String) -> Dictionary:
	var inspection = ZipGuard.inspect(path)
	if not inspection.get("ok", false):
		return inspection
	var reader = ZIPReader.new()
	var code = reader.open(path)
	if code != OK:
		return {"ok": false, "error": "Could not open ZIP (error %s)." % code}
	var files: Array = []
	var errors: Array = []
	for entry in inspection["entries"]:
		var filename = str(entry["path"])
		if not reader.file_exists(filename, true):
			errors.append(filename + ": name could not be read in this ZIP encoding.")
			continue
		var bytes = reader.read_file(filename, true)
		if bytes.size() != int(entry["size"]) or ZipGuard.crc32(bytes) != int(entry["crc"]):
			errors.append(filename + ": corrupted or unreadable file.")
			continue
		var text = bytes.get_string_from_utf8()
		if text.is_empty() and not bytes.is_empty():
			errors.append(filename + ": unsupported text encoding.")
			continue
		files.append({"path": filename, "text": text})
	reader.close()
	return {"ok": true, "files": files, "errors": errors}

func prepare(path: String, current: Array) -> Dictionary:
	var extension = path.get_extension().to_lower()
	var read_result: Dictionary
	if extension == "zip":
		read_result = _read_zip(path)
	elif extension == "ini":
		read_result = _read_ini(path)
	else:
		return {"ok": false, "error": "Choose an INI or ZIP file."}
	if not read_result.get("ok", false):
		return read_result
	var errors: Array = read_result.get("errors", []).duplicate()
	var records: Array = []
	var seen_batch: Dictionary = {}
	var counts = {"new": 0, "update": 0, "unchanged": 0, "conflict": 0}
	for file in read_result.get("files", []):
		var source = str(file["path"])
		if path.to_lower().contains("demo"):
			source = "DEMO / " + source
		var parsed = parser.parse_export(str(file["text"]), source)
		if not parsed.get("ok", false):
			errors.append(source + ": " + str(parsed.get("error", "invalid export")))
			continue
		var creature: Dictionary = parsed["creature"]
		var identity = str(creature.get("identity", ""))
		var action = "new"
		var old_index = -1
		if not identity.is_empty():
			if seen_batch.has(identity):
				var previous: Dictionary = seen_batch[identity]
				action = "unchanged" if previous.get("source_hash") == creature.get("source_hash") else "conflict"
			else:
				seen_batch[identity] = creature
				for i in range(current.size()):
					var existing: Dictionary = current[i]
					if str(existing.get("identity", "")) != identity:
						continue
					old_index = i
					if str(existing.get("species_key", "")) != str(creature.get("species_key", "")):
						action = "conflict"
					elif str(existing.get("source_hash", "")) == str(creature.get("source_hash", "")):
						action = "unchanged"
					else:
						action = "update"
					break
		if identity.is_empty():
			creature["warnings"].append("Imported without a verified identity; duplicates are not merged.")
		counts[action] += 1
		records.append({"creature": creature, "action": action, "old_index": old_index})
	if records.is_empty() and errors.is_empty():
		return {"ok": false, "error": "No INI files were found in this archive."}
	return {"ok": true, "records": records, "errors": errors, "counts": counts, "archive": path.get_file()}

func apply_plan(plan: Dictionary, current: Dictionary) -> Dictionary:
	var output: Dictionary = current.duplicate(true)
	var creatures: Array = output["creatures"]
	for item in plan.get("records", []):
		var creature: Dictionary = item["creature"]
		if item["action"] == "new":
			creature["local_id"] = "%s-%s" % [Time.get_unix_time_from_system(), Time.get_ticks_usec()]
			creatures.append(creature)
		elif item["action"] == "update":
			var index = int(item["old_index"])
			if index >= 0 and index < creatures.size():
				creature["local_id"] = creatures[index].get("local_id", "")
				creature["note"] = creatures[index].get("note", "")
				creatures[index] = creature
	return output
