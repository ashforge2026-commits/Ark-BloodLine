extends RefCounted

var entries: Array = []
var by_id: Dictionary = {}

func _init() -> void:
	var parsed = JSON.parse_string(FileAccess.get_file_as_string("res://data/palette.json"))
	if typeof(parsed) == TYPE_DICTIONARY:
		entries = parsed.get("colors", [])
		for item in entries:
			by_id[int(item.get("id", -1))] = item

func get_color(id: int) -> Dictionary:
	return by_id.get(id, {})

func match_rgba(raw: Array) -> Dictionary:
	if raw.size() != 4:
		return {"state": "unknown", "id": null, "candidates": [], "raw": raw}
	# The standard exported no-color sentinel is black with alpha 1.
	if absf(float(raw[0])) < 0.000001 and absf(float(raw[1])) < 0.000001 and absf(float(raw[2])) < 0.000001 and absf(float(raw[3]) - 1.0) < 0.000001:
		return {"state": "empty", "id": null, "candidates": [], "raw": raw}
	var ids: Array = []
	for item in entries:
		var reference: Array = item.get("rgba", [])
		if reference.size() != 4:
			continue
		var same = true
		for n in range(4):
			if absf(float(raw[n]) - float(reference[n])) > 0.00001:
				same = false
				break
		if same:
			ids.append(int(item["id"]))
	if ids.size() == 1:
		return {"state": "matched", "id": ids[0], "candidates": ids, "raw": raw}
	if ids.size() > 1:
		return {"state": "ambiguous", "id": null, "candidates": ids, "raw": raw}
	return {"state": "unknown", "id": null, "candidates": [], "raw": raw}

func from_id(id: int) -> Dictionary:
	var item = get_color(id)
	if item.is_empty():
		return {"state": "unknown", "id": null, "candidates": [], "raw": []}
	return {"state": "explicit", "id": id, "candidates": [id], "raw": item.get("rgba", [])}

func search(query: String) -> Array:
	var q = query.strip_edges().to_lower()
	var output: Array = []
	for item in entries:
		if q.is_empty() or str(item["id"]).contains(q) or str(item["name"]).to_lower().contains(q):
			output.append(item)
	return output

static func linear_to_srgb(value: float) -> float:
	var x = clampf(value, 0.0, 1.0)
	if x <= 0.0031308:
		return clampf(x * 12.92, 0.0, 1.0)
	return clampf(1.055 * pow(x, 1.0 / 2.4) - 0.055, 0.0, 1.0)

static func display_color(raw: Array) -> Color:
	if raw.size() < 3:
		return Color(0.28, 0.32, 0.37, 1.0)
	return Color(linear_to_srgb(float(raw[0])), linear_to_srgb(float(raw[1])), linear_to_srgb(float(raw[2])), 1.0)
