extends "res://scripts/storage.gd"

const PATH = "user://color_lab_designs.json"

func _init(path: String = PATH) -> void:
	super(path)

func empty_data() -> Dictionary:
	return {"version": 1, "designs": []}

func _read_valid(path: String):
	var value = _read_json(path)
	if typeof(value) != TYPE_DICTIONARY or typeof(value.get("designs")) != TYPE_ARRAY:
		return null
	return value

func load_designs(legacy) -> Dictionary:
	var current = load_data()
	if not FileAccess.file_exists(data_path) and not FileAccess.file_exists(backup_path) and legacy is Array and not legacy.is_empty():
		current["designs"] = legacy.duplicate(true)
		var result = save_data(current)
		if not result.get("ok", false):
			last_warning = "Could not copy older designs: " + str(result.get("error", ""))
	return current
