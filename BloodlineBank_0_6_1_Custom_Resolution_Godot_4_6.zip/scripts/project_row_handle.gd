extends Label

# Keep dragging limited to this handle so selecting names and colors doesn't
# accidentally reorder the table.
var project_id: String = ""
var creature_id: String = ""

func _get_drag_data(_at_position: Vector2) -> Variant:
	if creature_id.is_empty() or project_id.is_empty():
		return null
	var preview = PanelContainer.new()
	var caption = Label.new()
	caption.text = "↕ Move row"
	preview.add_child(caption)
	set_drag_preview(preview)
	return {"type": "bloodline_project_row", "project_id": project_id, "id": creature_id}
