extends Control

signal creature_dropped(payload: Dictionary, board_position: Vector2)

# Native Godot 4.6 Control drag-and-drop, including drops from the picker.
func _can_drop_data(_at_position: Vector2, payload: Variant) -> bool:
	return typeof(payload) == TYPE_DICTIONARY and payload.get("type", "") == "bloodline_creature" and not str(payload.get("id", "")).is_empty()

func _drop_data(at_position: Vector2, payload: Variant) -> void:
	if _can_drop_data(at_position, payload):
		accept_creature_drop(at_position, payload)

func accept_creature_drop(at_position: Vector2, payload: Dictionary) -> void:
	creature_dropped.emit(payload, at_position)
