extends RefCounted

enum SearchMode { AUTO, COLOR_ID, NAME, LEVEL }

# Read-only color-coverage matching. Never edits creatures or saved projects.
# A confirmed ID must be explicit or matched, not merely an ambiguous candidate.

static func active_slots(creature: Dictionary) -> Array:
	var names = creature.get("region_names", null)
	if typeof(names) != TYPE_ARRAY or names.size() != 6:
		return []
	var result: Array = []
	for i in range(6):
		if names[i] == null:
			continue
		var label = str(names[i]).strip_edges().to_lower()
		if label.is_empty() or label == "unknown":
			return []
		result.append(i)
	return result

static func confirmed_color(creature: Dictionary, region_index: int):
	var regions = creature.get("regions", [])
	if typeof(regions) != TYPE_ARRAY or region_index >= regions.size() or region_index < 0:
		return null
	if typeof(regions[region_index]) != TYPE_DICTIONARY:
		return null
	var region: Dictionary = regions[region_index]
	if not (str(region.get("state", "")) in ["explicit", "matched"]) or region.get("id", null) == null:
		return null
	return int(region["id"])

static func colors_for_male(male: Dictionary) -> Array:
	var slots = active_slots(male)
	var counts: Dictionary = {}
	for i in slots:
		var id = confirmed_color(male, i)
		if id == null:
			continue
		counts[id] = int(counts.get(id, 0)) + 1
	var colors: Array = []
	for id in counts:
		colors.append({"id": int(id), "count": int(counts[id])})
	colors.sort_custom(func(a, b):
		if int(a["count"]) != int(b["count"]):
			return int(a["count"]) > int(b["count"])
		return int(a["id"]) < int(b["id"])
	)
	return colors

static func can_breed(creature: Dictionary, expected_sex: String) -> bool:
	return str(creature.get("sex", "")) == expected_sex and str(creature.get("neutered", "")).to_lower() not in ["true", "1"]

static func search_color_id(query: String) -> int:
	var value = query.strip_edges().trim_prefix("#")
	return int(value) if value.is_valid_int() and int(value) >= 0 else -1

static func male_options(creatures: Array) -> Array:
	var result: Array = []
	for entry in male_matches(creatures, ""):
		result.append(entry["creature"])
	return result

static func male_matches(creatures: Array, query: String, mode: int = SearchMode.AUTO, species_key: String = "") -> Array:
	var result: Array = []
	var text = query.strip_edges().to_lower()
	var target_color = search_color_id(text) if mode in [SearchMode.AUTO, SearchMode.COLOR_ID] else -1
	var level_query = text if mode == SearchMode.LEVEL else ""
	if mode == SearchMode.AUTO and text.begins_with("level "):
		level_query = text.trim_prefix("level ").strip_edges()
	if mode == SearchMode.COLOR_ID and not text.is_empty() and target_color < 0:
		return result
	if mode == SearchMode.LEVEL and not level_query.is_empty() and not level_query.is_valid_int():
		return result
	for creature in creatures:
		if typeof(creature) != TYPE_DICTIONARY or not can_breed(creature, "Male"):
			continue
		if not species_key.is_empty() and creature.get("species_key", "") != species_key:
			continue
		if not level_query.is_empty() and level_query.is_valid_int():
			if creature.get("level", null) == null or float(creature["level"]) != int(level_query):
				continue
		elif target_color < 0 and not text.is_empty():
			var words = str(creature.get("name", ""))
			if mode == SearchMode.AUTO:
				words += " %s %s" % [creature.get("species_name", ""), creature.get("level", "")]
			if not words.to_lower().contains(text):
				continue
		var color: Dictionary
		if target_color >= 0:
			var count = 0
			for slot in active_slots(creature):
				if confirmed_color(creature, slot) == target_color:
					count += 1
			if count == 0:
				continue
			color = {"id": target_color, "count": count}
		else:
			var colors = colors_for_male(creature)
			if colors.is_empty():
				continue
			color = colors[0]
		result.append({"creature": creature, "id": color["id"], "count": color["count"]})
	result.sort_custom(func(a, b):
		if a["count"] != b["count"]:
			return a["count"] > b["count"]
		var an = str(a["creature"].get("name", "")).to_lower()
		var bn = str(b["creature"].get("name", "")).to_lower()
		if an != bn:
			return an < bn
		return str(a["creature"].get("local_id", "")) < str(b["creature"].get("local_id", ""))
	)
	return result

static func rank(creatures: Array, male: Dictionary, target_id: int) -> Dictionary:
	var slots = active_slots(male)
	var male_slots: Array = []
	for i in slots:
		if confirmed_color(male, i) == target_id:
			male_slots.append(i)
	var result: Dictionary = {
		"valid": not slots.is_empty() and not male_slots.is_empty() and can_breed(male, "Male") and not str(male.get("species_key", "")).is_empty(),
		"total": slots.size(), "male_count": male_slots.size(), "male_slots": male_slots,
		"results": []
	}
	if not result["valid"]:
		return result
	for item in creatures:
		if typeof(item) != TYPE_DICTIONARY:
			continue
		var female: Dictionary = item
		if not can_breed(female, "Female"):
			continue
		if str(female.get("species_key", "")) != str(male.get("species_key", "")):
			continue
		if str(female.get("local_id", "")) == str(male.get("local_id", "")):
			continue
		# Unknown or inconsistent variant-region metadata is not a confirmed match.
		if active_slots(female) != slots:
			continue
		var female_slots: Array = []
		var new_slots: Array = []
		var guaranteed_slots: Array = []
		for i in slots:
			if confirmed_color(female, i) != target_id:
				continue
			female_slots.append(i)
			if i in male_slots:
				guaranteed_slots.append(i)
			else:
				new_slots.append(i)
		# Only suggest females that fill at least one region this male is missing.
		# Overlapping regions are allowed, but overlap alone is not useful here.
		if new_slots.is_empty():
			continue
		var coverage = male_slots.size() + new_slots.size()
		result["results"].append({
			"creature": female, "female_count": female_slots.size(),
			"new_count": new_slots.size(), "combined_count": coverage,
			"both_count": guaranteed_slots.size(),
			"new_slots": new_slots, "female_slots": female_slots,
			"both_slots": guaranteed_slots,
			"missing_count": slots.size() - coverage
		})
	result["results"].sort_custom(func(a, b):
		if int(a["new_count"]) != int(b["new_count"]):
			return int(a["new_count"]) > int(b["new_count"])
		if int(a["female_count"]) != int(b["female_count"]):
			return int(a["female_count"]) > int(b["female_count"])
		var an = str(a["creature"].get("name", "")).to_lower()
		var bn = str(b["creature"].get("name", "")).to_lower()
		if an != bn:
			return an < bn
		return str(a["creature"].get("local_id", "")) < str(b["creature"].get("local_id", ""))
	)
	return result
