extends RefCounted

# Show a dash only when species metadata confirms the region is unused.
static func is_unused(creature: Dictionary, index: int) -> bool:
	var names = creature.get("region_names", null)
	return typeof(names) == TYPE_ARRAY and names.size() > index and names[index] == null

static func region_at(creature: Dictionary, index: int) -> Dictionary:
	var regions = creature.get("regions", [])
	if typeof(regions) != TYPE_ARRAY or index < 0 or index >= regions.size() or typeof(regions[index]) != TYPE_DICTIONARY:
		return {"state": "unknown", "id": null, "raw": [], "candidates": []}
	return regions[index]

static func confirmed_id(creature: Dictionary, index: int):
	if is_unused(creature, index):
		return null
	var region = region_at(creature, index)
	var state = str(region.get("state", "unknown"))
	var id = region.get("id", null)
	if (state != "matched" and state != "explicit") or id == null:
		return null
	if typeof(id) != TYPE_INT and typeof(id) != TYPE_FLOAT and not str(id).is_valid_int():
		return null
	return int(id)

static func region_matches(creature: Dictionary, index: int, query: String, palette) -> bool:
	var q = query.strip_edges().to_lower()
	if q.is_empty():
		return true
	if is_unused(creature, index):
		return false
	var id = confirmed_id(creature, index)
	if q == "?":
		return id == null
	if id == null:
		return false
	if q.is_valid_int():
		return int(q) == int(id)
	return str(palette.get_color(int(id)).get("name", "")).to_lower().contains(q)

static func filtered(creatures: Array, species_key: String, query: String, region_filters: Array, sort_region: int, descending: bool, palette) -> Array:
	var result: Array = []
	var q = query.strip_edges().to_lower()
	for creature in creatures:
		if typeof(creature) != TYPE_DICTIONARY:
			continue
		if not species_key.is_empty() and str(creature.get("species_key", "")) != species_key:
			continue
		var name = (str(creature.get("name", "")) + " " + str(creature.get("species_name", "")) + " " + str(creature.get("sex", ""))).to_lower()
		if not q.is_empty() and not name.contains(q):
			continue
		var matches = true
		for i in range(6):
			var filter = str(region_filters[i]) if i < region_filters.size() else ""
			if not region_matches(creature, i, filter, palette):
				matches = false
				break
		if matches:
			result.append(creature)
	if sort_region >= 0 and sort_region < 6:
		result.sort_custom(func(a, b):
			var left = confirmed_id(a, sort_region)
			var right = confirmed_id(b, sort_region)
			if (left == null) != (right == null):
				return left != null
			if left != null and right != null and int(left) != int(right):
				return int(left) > int(right) if descending else int(left) < int(right)
			var left_name = str(a.get("name", "")).to_lower()
			var right_name = str(b.get("name", "")).to_lower()
			if left_name != right_name:
				return left_name < right_name
			return str(a.get("local_id", "")) < str(b.get("local_id", ""))
		)
	else:
		result.reverse()
	return result

# TSV can be pasted into a spreadsheet or message; it never sends anything.
# Prefix formula-like names to prevent them being evaluated by spreadsheet apps.
static func safe_text(value) -> String:
	var text = str(value).replace("\t", " ").replace("\r", " ").replace("\n", " ")
	var left = text.strip_edges(true, false)
	if not left.is_empty() and left.substr(0, 1) in ["=", "+", "-", "@"]:
		return "'" + text
	return text

static func copied_rows(creatures: Array, palette) -> String:
	var lines: Array = ["Creature\tSpecies\tLevel\tSex\tRegion 0\tRegion 1\tRegion 2\tRegion 3\tRegion 4\tRegion 5"]
	for creature in creatures:
		var fields: Array = [safe_text(creature.get("name", "Unnamed")), safe_text(creature.get("species_name", "Unknown")), str(int(creature["level"])) if creature.get("level", null) != null else "—", safe_text(creature.get("sex", "Unknown"))]
		for i in range(6):
			if is_unused(creature, i):
				fields.append("—")
			else:
				var id = confirmed_id(creature, i)
				if id == null:
					fields.append("?")
				else:
					var color_name = str(palette.get_color(int(id)).get("name", ""))
					fields.append("%s %s" % [id, safe_text(color_name)] if not color_name.is_empty() else str(id))
		lines.append("\t".join(fields))
	return "\n".join(lines)
