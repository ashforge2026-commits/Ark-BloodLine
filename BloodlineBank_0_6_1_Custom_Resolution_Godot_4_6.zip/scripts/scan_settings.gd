extends RefCounted

const CONFIG_PATH = "user://scan_settings.cfg"
const STATE_PATH = "user://scan_manifest.json"
const ASA_RELATIVE = "ARK Survival Ascended/ShooterGame/Saved/DinoExports"

# Keep the old private export folder as a fallback. Never create directories
# inside a Steam installation, and never change a saved user-selected folder.
func default_folder() -> String:
	return ProjectSettings.globalize_path("user://Exported Dino")

func _config() -> ConfigFile:
	var cfg = ConfigFile.new()
	cfg.load(CONFIG_PATH)
	return cfg

func has_explicit_folder() -> bool:
	return not str(_config().get_value("imports", "folder", "")).strip_edges().is_empty()

func ark_folder_candidates() -> Array[String]:
	var candidates: Array[String] = []
	if OS.get_name() != "Windows":
		return candidates
	# The user's normal install location comes first.
	candidates.append("C:/Program Files (x86)/Steam/steamapps/common/" + ASA_RELATIVE)
	candidates.append("C:/Program Files/Steam/steamapps/common/" + ASA_RELATIVE)
	var drives: Array[String] = []
	for i in range(DirAccess.get_drive_count()):
		var drive = DirAccess.get_drive_name(i).replace("\\", "/")
		if drive.is_empty():
			continue
		if not drive.ends_with("/"):
			drive += "/"
		drives.append(drive)
	for drive in drives:
		for base in ["SteamLibrary/steamapps/common", "Steam/steamapps/common", "Program Files (x86)/Steam/steamapps/common", "Program Files/Steam/steamapps/common"]:
			var candidate = drive.path_join(base).path_join(ASA_RELATIVE)
			if candidate not in candidates:
				candidates.append(candidate)
	return candidates

func detect_ark_folder(candidates: Array[String] = []) -> String:
	var paths: Array[String] = candidates
	if paths.is_empty():
		paths = ark_folder_candidates()
	for path in paths:
		if DirAccess.dir_exists_absolute(path):
			return path
	return ""

func is_ark_exports_folder(path: String) -> bool:
	var normalized = path.replace("\\", "/").trim_suffix("/").to_lower()
	return normalized.ends_with("/shootergame/saved/dinoexports") or normalized.contains("/shootergame/saved/dinoexports/")

func load_folder() -> String:
	var configured = str(_config().get_value("imports", "folder", "")).strip_edges()
	if not configured.is_empty():
		return configured
	var detected = detect_ark_folder()
	return detected if not detected.is_empty() else default_folder()

func save_folder(folder: String) -> Error:
	var cfg = _config()
	cfg.set_value("imports", "folder", folder)
	return cfg.save(CONFIG_PATH)

func load_auto_sync() -> bool:
	return bool(_config().get_value("imports", "auto_sync", true))

func save_auto_sync(enabled: bool) -> Error:
	var cfg = _config()
	cfg.set_value("imports", "auto_sync", enabled)
	return cfg.save(CONFIG_PATH)

func load_state() -> Dictionary:
	if not FileAccess.file_exists(STATE_PATH):
		return {"ok": true, "state": {"files": {}, "archives": {}}}
	var f = FileAccess.open(STATE_PATH, FileAccess.READ)
	if f == null or f.get_length() > 16 * 1024 * 1024:
		return {"ok": false, "error": "The scan manifest cannot be read; automatic scan was paused."}
	var json = JSON.new()
	if json.parse(f.get_as_text()) != OK or typeof(json.data) != TYPE_DICTIONARY:
		return {"ok": false, "error": "The scan manifest is damaged; automatic scan was paused and no file was overwritten."}
	var value: Dictionary = json.data
	if typeof(value.get("files")) != TYPE_DICTIONARY or typeof(value.get("archives")) != TYPE_DICTIONARY:
		return {"ok": false, "error": "The scan manifest has an unexpected format; automatic scan was paused."}
	if value.has("suppressed") and typeof(value["suppressed"]) != TYPE_DICTIONARY:
		return {"ok": false, "error": "The scan manifest has invalid removal markers; automatic scan was paused."}
	for entry in value["files"].values():
		if typeof(entry) != TYPE_DICTIONARY:
			return {"ok": false, "error": "The scan manifest contains an invalid file entry; automatic scan was paused."}
	for entry in value["archives"].values():
		if typeof(entry) != TYPE_DICTIONARY or (entry.has("outputs") and typeof(entry["outputs"]) != TYPE_ARRAY):
			return {"ok": false, "error": "The scan manifest contains an invalid ZIP entry; automatic scan was paused."}
	return {"ok": true, "state": value}

func save_state(state: Dictionary) -> Dictionary:
	var temp = STATE_PATH + ".tmp"
	var f = FileAccess.open(temp, FileAccess.WRITE)
	if f == null:
		return {"ok": false, "error": "Cannot write scan manifest."}
	f.store_string(JSON.stringify(state, "\t"))
	f.flush()
	f.close()
	var check = JSON.new()
	if check.parse(FileAccess.get_file_as_string(temp)) != OK or typeof(check.data) != TYPE_DICTIONARY:
		return {"ok": false, "error": "Scan manifest could not be verified."}
	var dest = ProjectSettings.globalize_path(STATE_PATH)
	var temp_abs = ProjectSettings.globalize_path(temp)
	var backup = ProjectSettings.globalize_path(STATE_PATH + ".backup")
	if FileAccess.file_exists(STATE_PATH) and DirAccess.copy_absolute(dest, backup) != OK:
		return {"ok": false, "error": "Could not back up scan manifest."}
	var code = DirAccess.rename_absolute(temp_abs, dest)
	if code != OK and FileAccess.file_exists(STATE_PATH):
		if DirAccess.remove_absolute(dest) != OK:
			return {"ok": false, "error": "Could not replace scan manifest."}
		code = DirAccess.rename_absolute(temp_abs, dest)
		if code != OK:
			DirAccess.copy_absolute(backup, dest)
	if code != OK:
		return {"ok": false, "error": "Could not finish saving scan manifest."}
	return {"ok": true}
