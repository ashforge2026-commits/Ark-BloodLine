extends RefCounted

const Extract = preload("res://scripts/archive_extract.gd")
const Guard = preload("res://scripts/zip_guard.gd")
const MAX_FILES = 10000
const MAX_DEPTH = 20
var parser

func _init(parser_ref) -> void:
	parser = parser_ref

func _walk(folder: String) -> Dictionary:
	if DirAccess.open(folder) == null:
		return {"ok": false, "error": "The export folder is missing or cannot be opened: " + folder}
	var todo: Array = [{"path": folder, "depth": 0, "extracted": false}]
	var inis: Array = []
	var zips: Array = []
	var issues: Array = []
	var count = 0
	while not todo.is_empty():
		var item: Dictionary = todo.pop_back()
		var dir = DirAccess.open(str(item["path"]))
		if dir == null:
			issues.append(str(item["path"]) + ": cannot open folder.")
			continue
		dir.list_dir_begin()
		var name = dir.get_next()
		while not name.is_empty():
			if name != "." and name != "..":
				count += 1
				if count > MAX_FILES:
					dir.list_dir_end()
					return {"ok": false, "error": "Folder scan exceeded %s entries." % MAX_FILES}
				var path = str(item["path"]).path_join(name)
				if dir.is_link(name):
					issues.append(path + ": link was skipped.")
				elif dir.current_is_dir():
					if int(item["depth"]) < MAX_DEPTH:
						todo.append({"path": path, "depth": int(item["depth"]) + 1, "extracted": bool(item["extracted"]) or name == Extract.EXTRACTED_DIR})
					else:
						issues.append(path + ": folder nesting limit reached.")
				elif name.get_extension().to_lower() == "ini":
					inis.append(path)
				elif name.get_extension().to_lower() == "zip" and not bool(item["extracted"]):
					zips.append(path)
			name = dir.get_next()
		dir.list_dir_end()
	inis.sort()
	zips.sort()
	return {"ok": true, "inis": inis, "zips": zips, "issues": issues}

func _bounded_hash(path: String, limit: int) -> String:
	var f = FileAccess.open(path, FileAccess.READ)
	if f == null or f.get_length() > limit:
		return ""
	f.close()
	return FileAccess.get_sha256(path)

func scan(folder: String, current: Array, previous: Dictionary, allow_archive_extraction: bool = true) -> Dictionary:
	var first = _walk(folder)
	if not first.get("ok", false):
		return first
	var state: Dictionary = previous.duplicate(true)
	if typeof(state.get("files")) != TYPE_DICTIONARY:
		state["files"] = {}
	if typeof(state.get("archives")) != TYPE_DICTIONARY:
		state["archives"] = {}
	if typeof(state.get("suppressed")) != TYPE_DICTIONARY:
		state["suppressed"] = {}
	var errors: Array = first.get("issues", []).duplicate()
	var counts = {"new": 0, "unchanged": 0, "review": 0, "invalid": 0, "archives": 0, "extracted": 0, "suppressed": 0}
	for zip_path in first["zips"]:
		# A live ARK DinoExports directory is read-only: no ZIP extraction into the game tree.
		if not allow_archive_extraction:
			continue
		var hash = _bounded_hash(str(zip_path), Guard.MAX_ARCHIVE)
		if hash.is_empty():
			errors.append(str(zip_path) + ": unreadable or ZIP exceeds 50 MB.")
			continue
		var old: Dictionary = state["archives"].get(str(zip_path), {})
		var outputs_exist = true
		for output in old.get("outputs", []):
			if not FileAccess.file_exists(str(output)):
				outputs_exist = false
				break
		if old.get("hash", "") == hash and outputs_exist:
			continue
		var unpacked = Extract.extract_archive(str(zip_path), folder)
		if not unpacked.get("ok", false):
			errors.append(str(zip_path) + ": " + str(unpacked.get("error", "extraction failed")))
			continue
		if _bounded_hash(str(zip_path), Guard.MAX_ARCHIVE) != hash:
			errors.append(str(zip_path) + ": ZIP changed during scanning; retry.")
			continue
		counts["archives"] += 1
		counts["extracted"] += int(unpacked.get("copied", 0))
		state["archives"][str(zip_path)] = {"hash": hash, "outputs": unpacked.get("files", [])}
	var second = _walk(folder)
	if not second.get("ok", false):
		return second
	for issue in second.get("issues", []):
		if issue not in errors:
			errors.append(issue)
	var groups: Dictionary = {}
	var pending: Array = []
	for file_path in second["inis"]:
		var path = str(file_path)
		var hash = _bounded_hash(path, Guard.MAX_ENTRY)
		if hash.is_empty():
			errors.append(path + ": unreadable or INI exceeds 1 MB.")
			counts["invalid"] += 1
			continue
		var old: Dictionary = state["files"].get(path, {})
		if old.get("hash", "") == hash and old.get("status", "") != "review":
			if old.get("status", "") == "invalid":
				counts["invalid"] += 1
				errors.append(path + ": " + str(old.get("reason", "Invalid export.")))
			else:
				counts["unchanged"] += 1
			continue
		var text = FileAccess.get_file_as_string(path)
		if FileAccess.get_sha256(path) != hash:
			errors.append(path + ": file changed during scanning; retry.")
			continue
		var parsed = parser.parse_export(text, path)
		if not parsed.get("ok", false):
			counts["invalid"] += 1
			state["files"][path] = {"hash": hash, "status": "invalid", "reason": str(parsed.get("error", "Not a creature export."))}
			errors.append(path + ": " + str(parsed.get("error", "Not a creature export.")))
			continue
		var creature: Dictionary = parsed["creature"]
		var lower_text = text.to_lower()
		if not lower_text.contains("[colorization]") or not lower_text.contains("[max character status values]"):
			var reason = "Export is missing color or stat sections; it may be incomplete. Review or scan it again."
			state["files"][path] = {"hash": hash, "status": "review", "reason": reason}
			pending.append({"path": path, "reason": reason})
			counts["review"] += 1
			continue
		var identity = str(creature.get("identity", ""))
		if identity.is_empty():
			var reason = "Creature has no verified ID. Use Import Creature to review it."
			state["files"][path] = {"hash": hash, "status": "review", "reason": reason}
			pending.append({"path": path, "reason": reason})
			counts["review"] += 1
			continue
		if not groups.has(identity):
			groups[identity] = []
		groups[identity].append({"path": path, "hash": hash, "creature": creature})
	var existing: Dictionary = {}
	for creature in current:
		var identity = str(creature.get("identity", ""))
		if not identity.is_empty():
			if not existing.has(identity):
				existing[identity] = []
			existing[identity].append(creature)
	var records: Array = []
	for identity in groups:
		var entries: Array = groups[identity]
		var old_records: Array = existing.get(identity, [])
		var unique: Dictionary = {}
		for entry in entries:
			var signature = str(entry["creature"].get("species_key", "")) + "|" + str(entry["creature"].get("source_hash", ""))
			unique[signature] = true
		var was_removed = old_records.is_empty() and state["suppressed"].has(identity)
		var safe_new = old_records.is_empty() and unique.size() == 1 and not was_removed
		if safe_new:
			records.append({"action": "new", "old_index": -1, "creature": entries[0]["creature"]})
			counts["new"] += 1
		for entry in entries:
			var path = str(entry["path"])
			var hash = str(entry["hash"])
			var creature: Dictionary = entry["creature"]
			var same = old_records.size() == 1 and str(old_records[0].get("species_key", "")) == str(creature.get("species_key", "")) and str(old_records[0].get("source_hash", "")) == str(creature.get("source_hash", ""))
			if was_removed:
				state["files"][path] = {"hash": hash, "status": "suppressed"}
				counts["suppressed"] += 1
			elif safe_new or same:
				state["files"][path] = {"hash": hash, "status": "imported" if safe_new else "unchanged"}
				if same:
					counts["unchanged"] += 1
			else:
				var reason = "Matching ID has changed or conflicts with another export. Review before updating."
				state["files"][path] = {"hash": hash, "status": "review", "reason": reason}
				pending.append({"path": path, "reason": reason})
				counts["review"] += 1
	return {"ok": true, "counts": counts, "errors": errors, "pending": pending, "state": state, "records": records}
