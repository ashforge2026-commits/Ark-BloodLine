extends RefCounted

# Comparison only; never edits exported creatures or guesses unknown wild points.
# The numeric indexes match ARK's NumberOfLevelUpPointsApplied[] order.
const BREEDING_STATS = [
	{"key": "health", "label": "Health", "index": "0"},
	{"key": "stamina", "label": "Stamina", "index": "1"},
	{"key": "oxygen", "label": "Oxygen", "index": "3"},
	{"key": "food", "label": "Food", "index": "4"},
	{"key": "weight", "label": "Weight", "index": "7"},
	{"key": "melee damage", "label": "Melee", "index": "8"},
	{"key": "movement speed", "label": "Movement Speed", "index": "9"}
]
const REFERENCE_STAT = {"key": "torpidity", "label": "Torpidity", "index": "2"}

static func definitions(mode: String) -> Array:
	var result: Array = BREEDING_STATS.duplicate(true)
	if mode == "values":
		result.append(REFERENCE_STAT.duplicate(true))
	return result

static func _valid_number(value):
	if typeof(value) != TYPE_INT and typeof(value) != TYPE_FLOAT:
		return null
	var n = float(value)
	if is_nan(n) or is_inf(n) or n < 0.0:
		return null
	return n

static func number_for(creature: Dictionary, stat: Dictionary, mode: String):
	if mode == "points":
		var points = creature.get("wild_points", {})
		if typeof(points) != TYPE_DICTIONARY or not points.has(str(stat["index"])):
			return null
		var p = _valid_number(points[str(stat["index"])])
		if p == null or p != floorf(p):
			return null
		return p
	var stats = creature.get("stats", {})
	if typeof(stats) != TYPE_DICTIONARY:
		return null
	return _valid_number(stats.get(str(stat["key"]), null))

static func species(creatures: Array) -> Array:
	var labels: Dictionary = {}
	for item in creatures:
		if typeof(item) != TYPE_DICTIONARY:
			continue
		var key = str(item.get("species_key", ""))
		if key.is_empty():
			continue
		var name = str(item.get("species_name", "Unknown"))
		if not labels.has(key):
			labels[key] = {"key": key, "name": name, "count": 0}
		labels[key]["count"] = int(labels[key]["count"]) + 1
	var result: Array = labels.values()
	result.sort_custom(func(a, b):
		var an = str(a["name"]).to_lower()
		var bn = str(b["name"]).to_lower()
		if an != bn:
			return an < bn
		return str(a["key"]) < str(b["key"])
	)
	return result

static func has_points(creatures: Array, species_key: String) -> bool:
	for item in creatures:
		if typeof(item) != TYPE_DICTIONARY or str(item.get("species_key", "")) != species_key:
			continue
		for stat in BREEDING_STATS:
			if number_for(item, stat, "points") != null:
				return true
	return false

static func analyze(creatures: Array, species_key: String, mode: String) -> Dictionary:
	var scoped: Array = []
	for item in creatures:
		if typeof(item) == TYPE_DICTIONARY and str(item.get("species_key", "")) == species_key:
			scoped.append(item)
	var rows: Array = []
	for stat in definitions(mode):
		var candidates: Array = []
		for creature in scoped:
			var value = number_for(creature, stat, mode)
			if value != null:
				candidates.append({"creature": creature, "value": value})
		candidates.sort_custom(func(a, b):
			if float(a["value"]) != float(b["value"]):
				return float(a["value"]) < float(b["value"])
			var al = a["creature"].get("level", null)
			var bl = b["creature"].get("level", null)
			if al != null and bl != null and int(al) != int(bl):
				return int(al) < int(bl)
			return str(a["creature"].get("local_id", "")) < str(b["creature"].get("local_id", ""))
		)
		var lowest = candidates[0]["value"] if not candidates.is_empty() else null
		var carriers: Array = []
		for candidate in candidates:
			if candidate["value"] != lowest:
				break
			carriers.append(candidate)
		rows.append({
			"stat": stat, "lowest": lowest, "carriers": carriers,
			"candidates": candidates, "known": candidates.size(),
			"unknown": scoped.size() - candidates.size()
		})
	return {"total": scoped.size(), "rows": rows, "species_key": species_key, "mode": mode}

static func format_value(value, stat: Dictionary, mode: String) -> String:
	if value == null:
		return "—"
	if mode == "points":
		return "%s pts" % int(value)
	if str(stat.get("key", "")) in ["melee damage", "movement speed"]:
		return "%.1f%%" % (float(value) * 100.0)
	return "%.1f" % float(value)
