extends RefCounted

var by_blueprint: Dictionary = {}
var by_name: Dictionary = {}
const UNVERIFIED_WARNING = "Species or variant not recognized; region coverage is unknown."
const LAB_SPECIES = ["X-Otter", "Concavenator", "Enigmasaur"]
const IMAGE_PATHS = {
	"Concavenator": ["res://assets/creatures/concavenator.png", "res://assets/creatures/concavenator_mask.png"],
	"Enigmasaur": ["res://assets/creatures/enigmasaur.png", "res://assets/creatures/enigmasaur_mask.png"],
	"X-Otter": ["res://assets/creatures/x_otter.png", "res://assets/creatures/x_otter_mask.png"],
	"Yutyrannus": ["res://assets/creatures/yutyrannus.png", "res://assets/creatures/yutyrannus_mask.png"],
	"Magmasaur": ["res://assets/creatures/magmasaur.png", "res://assets/creatures/magmasaur_mask.png"]
}

const ALTERNATE_POSES = {
	"Enigmasaur": ["res://assets/creatures/enigmasaur_pose_2.png", "res://assets/creatures/enigmasaur_pose_2_mask.png"]
}

func _init() -> void:
	var parsed = JSON.parse_string(FileAccess.get_file_as_string("res://data/species_registry.json"))
	if typeof(parsed) != TYPE_DICTIONARY:
		return
	for item in parsed.get("species", []):
		var key = normalize_blueprint(str(item.get("blueprint", "")))
		if not key.is_empty():
			by_blueprint[key] = item
		var name = str(item.get("name", ""))
		if not name.is_empty():
			if not by_name.has(name.to_lower()):
				by_name[name.to_lower()] = []
			by_name[name.to_lower()].append(item)

static func normalize_blueprint(value: String) -> String:
	var v = value.strip_edges()
	if v.begins_with("Blueprint'"):
		v = v.substr(10)
	v = v.trim_suffix("'").trim_suffix("\"")
	if v.to_lower().ends_with("_c"):
		v = v.left(v.length() - 2)
	return v.to_lower()

func resolve(blueprint: String, tag: String) -> Dictionary:
	var key = normalize_blueprint(blueprint)
	if by_blueprint.has(key):
		var item: Dictionary = by_blueprint[key]
		return {"key": key, "name": item.get("name", "Unknown species"), "regions": item.get("regions", null), "verified_species": true}
	# Without a recognized blueprint, keep the real identity instead of guessing a variant.
	var label = tag.strip_edges().trim_prefix("\"").trim_suffix("\"")
	if label.is_empty():
		label = "Unknown species"
	if key.is_empty():
		key = "unknown:" + label.to_lower()
	return {"key": key, "name": label, "regions": null, "verified_species": false}

func images_for(creature: Dictionary, pose: int = 0) -> Array:
	if not creature.get("verified_species", false):
		return []
	var name = str(creature.get("species_name", ""))
	if pose == 1 and ALTERNATE_POSES.has(name):
		return ALTERNATE_POSES[name]
	return IMAGE_PATHS.get(name, [])

func lab_subject(name: String) -> Dictionary:
	var entries: Array = by_name.get(name.to_lower(), [])
	if not LAB_SPECIES.has(name) or entries.is_empty():
		return {}
	var entry: Dictionary = entries[0]
	return resolve(str(entry["blueprint"]), name)

func recognize_saved_enigmasaurs(creatures: Array) -> void:
	var subject = lab_subject("Enigmasaur")
	if subject.is_empty():
		return
	for creature in creatures:
		if typeof(creature) != TYPE_DICTIONARY or creature.get("verified_species", false):
			continue
		if normalize_blueprint(str(creature.get("blueprint", ""))) != subject["key"]:
			continue
		creature["species_key"] = subject["key"]
		creature["species_name"] = subject["name"]
		creature["region_names"] = subject["regions"].duplicate()
		creature["verified_species"] = true
		var warnings = creature.get("warnings", [])
		if typeof(warnings) == TYPE_ARRAY:
			warnings.erase(UNVERIFIED_WARNING)
