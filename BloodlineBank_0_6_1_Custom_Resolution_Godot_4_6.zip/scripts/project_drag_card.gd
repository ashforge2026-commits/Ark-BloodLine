extends PanelContainer

# Used by both the picker and the project board.
var creature_id = ""
var source = "picker"
var board_target: Control

func _get_drag_data(at_position: Vector2) -> Variant:
	if creature_id.is_empty():
		return null
	var preview = PanelContainer.new()
	var box = StyleBoxFlat.new()
	box.bg_color = Color("#17465a")
	box.border_color = Color("#35d5f4")
	box.set_border_width_all(1)
	box.set_corner_radius_all(5)
	box.content_margin_left = 14
	box.content_margin_right = 14
	box.content_margin_top = 8
	box.content_margin_bottom = 8
	preview.add_theme_stylebox_override("panel", box)
	var label = Label.new()
	label.text = "Move creature to board" if source == "picker" else "Move creature"
	preview.add_child(label)
	set_drag_preview(preview)
	return {"type": "bloodline_creature", "id": creature_id, "source": source, "offset_x": at_position.x, "offset_y": at_position.y}

# Dropping over an existing card should work, not just empty board space.
func _can_drop_data(_at_position: Vector2, payload: Variant) -> bool:
	return board_target != null and is_instance_valid(board_target) and payload is Dictionary and payload.get("type", "") == "bloodline_creature"

func _drop_data(_at_position: Vector2, payload: Variant) -> void:
	if _can_drop_data(Vector2.ZERO, payload):
		board_target.call("accept_creature_drop", board_target.get_local_mouse_position(), payload)
