extends Button

# Large header: click to collapse, drag to move this WHOLE breeding list,
# or accept an otter drop (as in 0.4.0). Empty-list pads remain otter-only.
signal creature_dropped(creature_id: String, destination_list_id: String)
signal list_dropped(source_list_id: String, destination_list_id: String, after: bool)

var project_id: String = ""
var list_id: String = ""
var list_name: String = ""
var allow_list_reorder: bool = false

func _get_drag_data(_at_position: Vector2) -> Variant:
	if not allow_list_reorder or project_id.is_empty() or list_id.is_empty():
		return null
	var preview = PanelContainer.new()
	var label = Label.new()
	label.text = "↕ Move list: %s" % list_name
	preview.add_child(label)
	set_drag_preview(preview)
	return {"type": "bloodline_project_list", "project_id": project_id, "list_id": list_id}

func _can_drop_data(_at_position: Vector2, payload: Variant) -> bool:
	if not (payload is Dictionary) or str(payload.get("project_id", "")) != project_id or list_id.is_empty():
		return false
	if str(payload.get("type", "")) == "bloodline_project_row":
		return not str(payload.get("id", "")).is_empty()
	if str(payload.get("type", "")) == "bloodline_project_list":
		return allow_list_reorder and not str(payload.get("list_id", "")).is_empty() and str(payload.get("list_id", "")) != list_id
	return false

func _drop_data(at_position: Vector2, payload: Variant) -> void:
	if not _can_drop_data(at_position, payload):
		return
	if str(payload["type"]) == "bloodline_project_row":
		creature_dropped.emit(str(payload["id"]), list_id)
	elif str(payload["type"]) == "bloodline_project_list":
		# The whole 50px heading is a target. Its top half inserts above,
		# lower half inserts below. No tiny precision target required.
		list_dropped.emit(str(payload["list_id"]), list_id, at_position.y >= size.y * 0.5)
