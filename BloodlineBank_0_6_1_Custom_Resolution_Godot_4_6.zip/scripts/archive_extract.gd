extends RefCounted

const Guard = preload("res://scripts/zip_guard.gd")
const EXTRACTED_DIR = "BloodlineBank Extracted"

static func _sha_bytes(bytes: PackedByteArray) -> String:
	var context = HashingContext.new()
	context.start(HashingContext.HASH_SHA256)
	context.update(bytes)
	return context.finish().hex_encode()

static func extract_archive(path: String, folder: String, source_name: String = "") -> Dictionary:
	var original_hash = FileAccess.get_sha256(path)
	if original_hash.is_empty():
		return {"ok": false, "error": "Could not read the ZIP.", "files": []}
	var inspection = Guard.inspect(path, true)
	if not inspection.get("ok", false):
		return inspection
	var document_tree = folder.begins_with("content://")
	var name = source_name if not source_name.is_empty() else path.get_file()
	var base_name = name.get_basename().validate_filename().strip_edges().left(48)
	if document_tree:
		base_name = base_name.replace("#", "_")
	if base_name.is_empty():
		base_name = "Archive"
	var relative_folder = EXTRACTED_DIR.path_join(base_name + "_" + original_hash.left(12))
	var destination = folder + "#" + relative_folder if document_tree else folder.path_join(relative_folder)
	var out_dir: DirAccess
	if not document_tree:
		var opened = _open_output_directory(folder, relative_folder)
		out_dir = opened.get("dir")
		if out_dir == null:
			return opened
	var reader = ZIPReader.new()
	var open_result = reader.open(path)
	if open_result != OK:
		return {"ok": false, "error": "Could not read ZIP (error %s)." % open_result, "files": []}
	var files: Array = []
	var copied = 0
	var unchanged = 0
	var errors: Array = []
	var checked: Array = []
	for entry in inspection.get("entries", []):
		var archive_path = str(entry["path"])
		var content = reader.read_file(archive_path, true)
		if content.size() != int(entry["size"]) or Guard.crc32(content) != int(entry["crc"]):
			errors.append(archive_path + ": bad CRC or unreadable data.")
			continue
		checked.append({"path": archive_path, "content": content})
	reader.close()
	if FileAccess.get_sha256(path) != original_hash:
		errors.append("The ZIP changed while it was being read; scan it again.")
	if not errors.is_empty():
		return {"ok": false, "error": "; ".join(errors), "errors": errors, "files": [], "copied": 0, "unchanged": 0, "output_folder": destination}
	for item in checked:
		var archive_path = str(item["path"])
		var content: PackedByteArray = item["content"]
		# A stable prefix prevents equal basenames in different ZIP directories from colliding.
		# Flattening also avoids writing any path supplied by the archive.
		var original_name = archive_path.replace("\\", "/").get_file().validate_filename().strip_edges()
		if document_tree:
			original_name = original_name.replace("#", "_")
		var extension = original_name.get_extension().left(12)
		var stem = original_name.get_basename().left(80)
		var clean_name = (stem + ("." + extension if not extension.is_empty() else "")).trim_suffix(".").strip_edges()
		if clean_name.is_empty():
			clean_name = "file"
		var output_name = archive_path.sha256_text().left(16) + "__" + clean_name
		var output_path = destination.path_join(output_name)
		if out_dir != null and out_dir.is_link(output_name):
			errors.append(archive_path + ": output is a link; not overwritten.")
			continue
		if FileAccess.file_exists(output_path):
			if FileAccess.get_sha256(output_path) == _sha_bytes(content):
				unchanged += 1
				files.append(output_path)
			else:
				errors.append(archive_path + ": destination already exists and differs.")
			continue
		if document_tree:
			# SAF creates the relative folders on write. DirAccess cannot rename URI files.
			var write_error = _write_document(output_path, content)
			if not write_error.is_empty():
				errors.append(archive_path + ": " + write_error)
				continue
			copied += 1
			files.append(output_path)
			continue
		var temp_name = output_name + ".bbtmp_" + str(Time.get_ticks_usec())
		var temp_path = destination.path_join(temp_name)
		if FileAccess.file_exists(temp_path) or out_dir.is_link(temp_name):
			errors.append(archive_path + ": temporary destination already exists.")
			continue
		var f = FileAccess.open(temp_path, FileAccess.WRITE)
		if f == null:
			errors.append(archive_path + ": could not create output.")
			continue
		f.store_buffer(content)
		f.flush()
		f.close()
		if FileAccess.get_sha256(temp_path) != _sha_bytes(content) or FileAccess.file_exists(output_path):
			DirAccess.remove_absolute(temp_path)
			errors.append(archive_path + ": output could not be verified or already exists.")
			continue
		if DirAccess.rename_absolute(temp_path, output_path) != OK:
			DirAccess.remove_absolute(temp_path)
			errors.append(archive_path + ": could not finish writing output.")
			continue
		copied += 1
		files.append(output_path)
	if FileAccess.get_sha256(path) != original_hash:
		errors.append("The ZIP changed while it was being read; scan it again.")
	return {"ok": errors.is_empty(), "error": "; ".join(errors), "errors": errors, "files": files, "copied": copied, "unchanged": unchanged, "output_folder": destination}


static func _open_output_directory(folder: String, relative_folder: String) -> Dictionary:
	var root = DirAccess.open(folder)
	if root == null:
		return {"ok": false, "error": "Export folder cannot be opened.", "files": []}
	for name in relative_folder.split("/"):
		if root.is_link(name):
			return {"ok": false, "error": "Extraction folder is a link; choose a normal folder.", "files": []}
		if not root.dir_exists(name) and root.make_dir(name) != OK:
			return {"ok": false, "error": "Could not create the extraction folder.", "files": []}
		if root.change_dir(name) != OK:
			return {"ok": false, "error": "Could not open the extraction folder.", "files": []}
	return {"dir": root}

static func _write_document(path: String, content: PackedByteArray) -> String:
	var output = FileAccess.open(path, FileAccess.WRITE)
	if output == null:
		return "could not write to the selected Android folder. Try selecting it again."
	var wrote = output.store_buffer(content)
	output.close()
	if not wrote or FileAccess.get_sha256(path) != _sha_bytes(content):
		return "the extracted file could not be verified."
	return ""
