extends RefCounted

var palette
var registry

func _init(palette_ref, registry_ref) -> void:
	palette = palette_ref
	registry = registry_ref

static func _number(value: String):
	var s = value.strip_edges().trim_prefix("\"").trim_suffix("\"")
	if not s.is_valid_float():
		return null
	return float(s)

static func _slot(key: String, prefix: String, limit: int = 6) -> int:
	if not key.begins_with(prefix + "[") or not key.ends_with("]"):
		return -1
	var n = key.substr(prefix.length() + 1, key.length() - prefix.length() - 2)
	if not n.is_valid_int():
		return -1
	var i = int(n)
	return i if i >= 0 and i < limit else -1

static func _rgba(value: String) -> Array:
	var text = value.strip_edges().trim_prefix("(").trim_suffix(")")
	var vals = {"r": null, "g": null, "b": null, "a": null}
	for component in text.split(",", false):
		var pos = component.find("=")
		if pos < 0:
			continue
		var k = component.left(pos).strip_edges().to_lower()
		if vals.has(k):
			vals[k] = _number(component.substr(pos + 1))
	for k in ["r", "g", "b", "a"]:
		if vals[k] == null:
			return []
	return [vals["r"], vals["g"], vals["b"], vals["a"]]

func parse_export(content: String, source: String = "") -> Dictionary:
	var data: Dictionary = {}
	var stat_values: Dictionary = {}
	var raw_colors: Array = [null, null, null, null, null, null]
	var direct_ids: Array = [null, null, null, null, null, null]
	var wild_points: Dictionary = {}
	var tamed_points: Dictionary = {}
	var section = ""
	var saw_dino_section = false
	var warnings: Array = []
	var input = content.trim_prefix("\ufeff")
	for raw_line in input.split("\n"):
		var line = str(raw_line).strip_edges()
		if line.is_empty() or line.begins_with(";") or line.begins_with("#"):
			continue
		if line.begins_with("[") and line.ends_with("]"):
			section = line.to_lower()
			if section == "[dino data]":
				saw_dino_section = true
			continue
		var equal_at = line.find("=")
		if equal_at <= 0:
			continue
		var key = line.left(equal_at).strip_edges().to_lower()
		var value = line.substr(equal_at + 1).strip_edges()
		var color_slot = _slot(key, "colorset")
		if color_slot >= 0:
			var color_value = _rgba(value)
			if color_value.size() == 4:
				raw_colors[color_slot] = color_value
			else:
				warnings.append("Region %s has invalid color data." % color_slot)
			continue
		var direct_slot = _slot(key, "colorsetindices")
		if direct_slot >= 0:
			if value.is_valid_int():
				direct_ids[direct_slot] = int(value)
			continue
		if key.begins_with("numberofleveluppointsappliedtamed["):
			var t = _slot(key, "numberofleveluppointsappliedtamed", 12)
			if t >= 0 and value.is_valid_int():
				tamed_points[str(t)] = int(value)
			continue
		if key.begins_with("numberofleveluppointsapplied["):
			var w = _slot(key, "numberofleveluppointsapplied", 12)
			if w >= 0 and value.is_valid_int():
				wild_points[str(w)] = int(value)
			continue
		if section == "[max character status values]":
			var stat_name = key.to_lower()
			if stat_name in ["health", "stamina", "weight", "melee damage", "oxygen", "food", "torpidity", "movement speed"]:
				var number = _number(value)
				if number != null:
					stat_values[stat_name] = number
				else:
					warnings.append("Invalid stat: " + stat_name)
			continue
		data[key] = value.trim_prefix("\"").trim_suffix("\"")
	if not saw_dino_section and not data.has("dinoclass") and not data.has("dinonametag"):
		return {"ok": false, "error": "Not a recognized dino export."}
	if not data.has("dinoclass") and not data.has("dinonametag"):
		return {"ok": false, "error": "Missing creature type and blueprint."}
	var species = registry.resolve(str(data.get("dinoclass", "")), str(data.get("dinonametag", "")))
	if not species["verified_species"]:
		warnings.append(registry.UNVERIFIED_WARNING)
	var sex = "Unknown"
	var sex_text = str(data.get("bisfemale", "")).to_lower()
	if sex_text == "true":
		sex = "Female"
	elif sex_text == "false":
		sex = "Male"
	else:
		warnings.append("Sex not available.")
	var regions: Array = []
	for i in range(6):
		var result = {"state": "unknown", "id": null, "candidates": [], "raw": []}
		if raw_colors[i] != null:
			result = palette.match_rgba(raw_colors[i])
		if direct_ids[i] != null:
			var direct = palette.from_id(int(direct_ids[i]))
			if direct["state"] == "explicit":
				if raw_colors[i] != null and result.get("state") == "matched" and int(result["id"]) != int(direct_ids[i]):
					warnings.append("Region %s: explicit ID and raw color differ." % i)
				if raw_colors[i] != null:
					direct["raw"] = raw_colors[i]
				result = direct
		regions.append(result)
	var id1 = str(data.get("dinoid1", ""))
	var id2 = str(data.get("dinoid2", ""))
	var identity = ""
	if id1.is_valid_int() and id2.is_valid_int() and not (int(id1) == 0 and int(id2) == 0):
		identity = "ASA|" + id1 + "|" + id2
	else:
		warnings.append("ARK identity missing; duplicate detection needs review.")
	var level = null
	if str(data.get("characterlevel", "")).is_valid_int():
		level = int(data["characterlevel"])
	var custom_name = str(data.get("tamedname", data.get("dinoname", ""))).strip_edges()
	if custom_name.is_empty():
		custom_name = "Unnamed " + str(species["name"])
	var creature = {
		"identity": identity, "id1": id1, "id2": id2,
		"species_key": species["key"], "species_name": species["name"], "blueprint": str(data.get("dinoclass", "")),
		"verified_species": species["verified_species"], "region_names": species["regions"],
		"name": custom_name, "sex": sex, "level": level, "regions": regions,
		"stats": stat_values, "wild_points": wild_points, "tamed_points": tamed_points,
		"neutered": data.get("bneutered", ""), "mutation_maternal": data.get("randommutationsfemale", ""),
		"mutation_paternal": data.get("randommutationsmale", ""), "source": source,
		"source_hash": content.sha256_text(), "raw_export": content, "warnings": warnings,
		"is_demo": source.to_lower().contains("demo")
	}
	return {"ok": true, "creature": creature, "warnings": warnings}
