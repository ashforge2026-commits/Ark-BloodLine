extends RefCounted

const Guard = preload("res://scripts/zip_guard.gd")
const CONFIG_PATH = "user://mobile_exports.cfg"
const DEFAULT_FOLDER = "user://Mobile Dino Exports"

static func load_folder() -> String:
	var config = ConfigFile.new()
	if config.load(CONFIG_PATH) != OK:
		return DEFAULT_FOLDER
	return str(config.get_value("exports", "folder", DEFAULT_FOLDER))

static func save_folder(folder: String) -> Error:
	if folder.begins_with("content://"):
		if not folder.contains("/tree/") or folder.contains("#"):
			return ERR_INVALID_PARAMETER
		if not Engine.has_singleton("AndroidRuntime"):
			return ERR_UNAVAILABLE
		var runtime = Engine.get_singleton("AndroidRuntime")
		var granted = runtime.updatePersistableUriPermission(folder, true)
		if granted is bool and not granted:
			return ERR_UNAUTHORIZED
	elif DirAccess.open(folder) == null:
		return ERR_CANT_OPEN
	var config = ConfigFile.new()
	config.set_value("exports", "folder", folder)
	return config.save(CONFIG_PATH)

static func describe(path: String) -> String:
	if path == DEFAULT_FOLDER:
		return "App storage / Mobile Dino Exports"
	if path.begins_with("content://"):
		var root = path.get_slice("#", 0)
		var folder = root.substr(root.find("/tree/") + 6).uri_decode().trim_prefix("primary:")
		return folder.path_join(path.get_slice("#", 1)) if path.contains("#") else folder
	return path

# Android document IDs can be opaque, and the ZIP reader needs a seekable file.
static func stage_document(path: String) -> Dictionary:
	var input = FileAccess.open(path, FileAccess.READ)
	if input == null:
		return {"error": "Could not open the selected file. Select it again in Android Files."}
	var length = input.get_length()
	if length <= 0 or length > Guard.MAX_ARCHIVE:
		return {"error": "Choose a local INI or ZIP up to 50 MB."}
	var header = input.get_buffer(4)
	var is_zip = header == PackedByteArray([80, 75, 3, 4]) or header == PackedByteArray([80, 75, 5, 6])
	var filename = path.uri_decode().get_file()
	if filename.contains(":"):
		filename = filename.get_slice(":", 1)
	var extension = "zip" if is_zip or filename.get_extension().to_lower() == "zip" else "ini"
	if extension == "ini" and length > Guard.MAX_ENTRY:
		return {"error": "INI files must be 1 MB or smaller."}
	if filename.get_extension().to_lower() != extension:
		filename = "Dino export." + extension
	var prefix = filename.get_basename().validate_filename().left(48)
	var copy = FileAccess.create_temp(FileAccess.READ_WRITE, prefix, extension)
	if copy == null:
		return {"error": "Could not create a temporary import file."}
	if not copy.store_buffer(header):
		return {"error": "Could not write the temporary import file."}
	var remaining = length - header.size()
	while remaining > 0:
		var data = input.get_buffer(mini(remaining, 256 * 1024))
		if data.is_empty() or not copy.store_buffer(data):
			return {"error": "Could not copy the selected file."}
		remaining -= data.size()
	copy.flush()
	return {"file": copy, "path": copy.get_path_absolute(), "name": filename}
