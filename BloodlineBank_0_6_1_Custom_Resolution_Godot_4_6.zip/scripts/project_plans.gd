extends RefCounted

# 0.4.1: named breeding lists can also be reordered, including Main List.
# Legacy lists still start with Main List first unless the user reorders them.
# List order lives only in project["list_order"]; member IDs and list contents
# are untouched when a heading moves. No migration write until a user edits.
const BOARD_SIZE = Vector2(1080, 780)
const CARD_SIZE = Vector2(224, 139)
const MAIN_LIST_ID = "main"

static func get_projects(library: Dictionary) -> Dictionary:
	var projects = library.get("projects", {})
	return projects if typeof(projects) == TYPE_DICTIONARY else {}

static func members_of(project: Dictionary) -> Array:
	var members = project.get("members", [])
	return members if typeof(members) == TYPE_ARRAY else []

static func member_index(project: Dictionary, creature_id: String) -> int:
	var members = members_of(project)
	for i in range(members.size()):
		if typeof(members[i]) == TYPE_DICTIONARY and str(members[i].get("id", "")) == creature_id:
			return i
	return -1

# Groups are small display sections, not copies of creatures. A project always
# has the synthetic Main List, even when loading old 0.3.5-0.3.8 projects.
static func lists_of(project: Dictionary) -> Array:
	var result: Array = [{"id": MAIN_LIST_ID, "name": "Main List", "open": true}]
	var source = project.get("lists", [])
	if typeof(source) != TYPE_ARRAY:
		return result
	var seen: Dictionary = {}
	seen[MAIN_LIST_ID] = true
	for item in source:
		if typeof(item) != TYPE_DICTIONARY:
			continue
		var key = str(item.get("id", ""))
		if key.is_empty() or seen.has(key):
			continue
		seen[key] = true
		result.append({"id": key, "name": str(item.get("name", "List")), "open": bool(item.get("open", true))})
	# Old data could have explicitly saved Main List's collapse state.
	for item in source:
		if typeof(item) == TYPE_DICTIONARY and str(item.get("id", "")) == MAIN_LIST_ID:
			result[0]["open"] = bool(item.get("open", true))
	# Do not require a migration for 0.3.9/0.4.0 project files. An optional
	# order key moves the synthetic Main List as well as named batches. Unknown,
	# duplicate or deleted list IDs are ignored; newly created lists go last.
	var saved_order = project.get("list_order", [])
	if typeof(saved_order) != TYPE_ARRAY:
		return result
	var ordered: Array = []
	var added: Dictionary = {}
	for raw_id in saved_order:
		var ordered_id = str(raw_id)
		if added.has(ordered_id):
			continue
		for entry in result:
			if str(entry["id"]) == ordered_id:
				ordered.append(entry)
				added[ordered_id] = true
				break
	for entry in result:
		if not added.has(str(entry["id"])):
			ordered.append(entry)
	return ordered

# Move a whole breeding-list section before/after another header. This only
# changes display order. Every creature keeps its own list_id and row position.
static func move_list_to(project: Dictionary, source_id: String, target_id: String, after: bool = false) -> bool:
	if source_id == target_id or not list_exists(project, source_id) or not list_exists(project, target_id):
		return false
	var order: Array = []
	for entry in lists_of(project):
		order.append(str(entry["id"]))
	var changed_order = order.duplicate()
	changed_order.erase(source_id)
	var insert_at = changed_order.find(target_id)
	if insert_at < 0:
		return false
	changed_order.insert(insert_at + (1 if after else 0), source_id)
	if changed_order == order:
		return false
	project["list_order"] = changed_order
	return true

static func move_list_by(project: Dictionary, list_id: String, delta: int) -> bool:
	if delta != -1 and delta != 1:
		return false
	var ids: Array = []
	for entry in lists_of(project):
		ids.append(str(entry["id"]))
	var index = ids.find(list_id)
	if index < 0 or index + delta < 0 or index + delta >= ids.size():
		return false
	return move_list_to(project, list_id, str(ids[index + delta]), delta > 0)

static func list_exists(project: Dictionary, list_id: String) -> bool:
	for item in lists_of(project):
		if str(item.get("id", "")) == list_id:
			return true
	return false

static func member_list_id(project: Dictionary, member: Dictionary) -> String:
	var id = str(member.get("list_id", MAIN_LIST_ID))
	return id if list_exists(project, id) else MAIN_LIST_ID

static func members_in_list(project: Dictionary, list_id: String) -> Array:
	var result: Array = []
	for member in members_of(project):
		if typeof(member) == TYPE_DICTIONARY and member_list_id(project, member) == list_id:
			result.append(member)
	return result

static func member_position(project: Dictionary, creature_id: String) -> int:
	var index = member_index(project, creature_id)
	if index == -1:
		return -1
	var members = members_of(project)
	var list_id = member_list_id(project, members[index])
	var count = 0
	for member in members:
		if typeof(member) != TYPE_DICTIONARY or member_list_id(project, member) != list_id:
			continue
		count += 1
		if str(member.get("id", "")) == creature_id:
			return count
	return -1

static func add_list(project: Dictionary, list_id: String, list_name: String) -> bool:
	var clean = list_name.strip_edges().substr(0, 42)
	if clean.is_empty() or list_id.is_empty() or list_exists(project, list_id):
		return false
	for entry in lists_of(project):
		if str(entry.get("name", "")).to_lower() == clean.to_lower():
			return false
	var lists = project.get("lists", [])
	lists = lists.duplicate(true) if typeof(lists) == TYPE_ARRAY else []
	lists.append({"id": list_id, "name": clean, "open": true})
	project["lists"] = lists
	return true

static func rename_list(project: Dictionary, list_id: String, list_name: String) -> bool:
	if list_id == MAIN_LIST_ID:
		return false
	var clean = list_name.strip_edges().substr(0, 42)
	if clean.is_empty():
		return false
	for entry in lists_of(project):
		if str(entry.get("id", "")) != list_id and str(entry.get("name", "")).to_lower() == clean.to_lower():
			return false
	var lists = project.get("lists", [])
	if typeof(lists) != TYPE_ARRAY:
		return false
	lists = lists.duplicate(true)
	for i in range(lists.size()):
		if typeof(lists[i]) == TYPE_DICTIONARY and str(lists[i].get("id", "")) == list_id:
			if str(lists[i].get("name", "")) == clean:
				return false
			lists[i]["name"] = clean
			project["lists"] = lists
			return true
	return false

static func set_list_open(project: Dictionary, list_id: String, is_open: bool) -> bool:
	if not list_exists(project, list_id):
		return false
	var lists = project.get("lists", [])
	lists = lists.duplicate(true) if typeof(lists) == TYPE_ARRAY else []
	for entry in lists:
		if typeof(entry) == TYPE_DICTIONARY and str(entry.get("id", "")) == list_id:
			if bool(entry.get("open", true)) == is_open:
				return false
			entry["open"] = is_open
			project["lists"] = lists
			return true
	if list_id == MAIN_LIST_ID:
		lists.append({"id": MAIN_LIST_ID, "name": "Main List", "open": is_open})
		project["lists"] = lists
		return true
	return false

static func remove_list(project: Dictionary, list_id: String) -> bool:
	# Deleting a section NEVER removes creatures; they return to Main List.
	if list_id == MAIN_LIST_ID or not list_exists(project, list_id):
		return false
	var lists: Array = []
	for entry in lists_of(project):
		if str(entry.get("id", "")) != list_id:
			lists.append(entry)
	var members = members_of(project).duplicate(true)
	for member in members:
		if typeof(member) == TYPE_DICTIONARY and str(member.get("list_id", MAIN_LIST_ID)) == list_id:
			member["list_id"] = MAIN_LIST_ID
	project["lists"] = lists
	project["members"] = members
	# Keep saved ordering tidy after a list is deleted. All remaining batches
	# retain their relative order and Main List remains wherever it was moved.
	var keep_order: Array = []
	for entry in lists_of(project):
		keep_order.append(str(entry["id"]))
	project["list_order"] = keep_order
	return true

static func add_member(project: Dictionary, creature_id: String, _position: Vector2 = Vector2.ZERO, list_id: String = MAIN_LIST_ID) -> bool:
	if creature_id.is_empty() or member_index(project, creature_id) != -1:
		return false
	if not list_exists(project, list_id):
		list_id = MAIN_LIST_ID
	var members = members_of(project).duplicate(true)
	members.append({"id": creature_id, "alias": "", "list_id": list_id})
	project["members"] = members
	return true

static func remove_member(project: Dictionary, creature_id: String) -> bool:
	var index = member_index(project, creature_id)
	if index == -1:
		return false
	var members = members_of(project).duplicate(true)
	members.remove_at(index)
	project["members"] = members
	return true

static func rename_member(project: Dictionary, creature_id: String, alias: String) -> bool:
	var index = member_index(project, creature_id)
	if index == -1:
		return false
	var members = members_of(project).duplicate(true)
	var member: Dictionary = members[index]
	var clean = alias.strip_edges().substr(0, 80)
	if str(member.get("alias", "")) == clean:
		return false
	member["alias"] = clean
	project["members"] = members
	return true

static func move_member_to_list(project: Dictionary, creature_id: String, list_id: String) -> bool:
	var index = member_index(project, creature_id)
	if index < 0 or not list_exists(project, list_id):
		return false
	var members = members_of(project).duplicate(true)
	if member_list_id(project, members[index]) == list_id:
		return false
	var moved: Dictionary = members[index]
	members.remove_at(index)
	moved["list_id"] = list_id
	var insertion = members.size()
	for i in range(members.size()):
		if typeof(members[i]) == TYPE_DICTIONARY and member_list_id(project, members[i]) == list_id:
			insertion = i + 1
	members.insert(insertion, moved)
	project["members"] = members
	return true

static func move_member_to_position(project: Dictionary, creature_id: String, position_one_based: int) -> bool:
	var from = member_index(project, creature_id)
	if from < 0:
		return false
	var members = members_of(project).duplicate(true)
	var list_id = member_list_id(project, members[from])
	var total = members_in_list(project, list_id).size()
	var target = clampi(position_one_based, 1, total)
	if member_position(project, creature_id) == target:
		return false
	var moved = members[from]
	members.remove_at(from)
	var other_indices: Array = []
	for i in range(members.size()):
		if typeof(members[i]) == TYPE_DICTIONARY and member_list_id(project, members[i]) == list_id:
			other_indices.append(i)
	var insertion = members.size()
	if target - 1 < other_indices.size():
		insertion = other_indices[target - 1]
	elif not other_indices.is_empty():
		insertion = other_indices.back() + 1
	members.insert(insertion, moved)
	project["members"] = members
	return true

static func move_member_to(project: Dictionary, creature_id: String, target_id: String, after: bool = false) -> bool:
	var from = member_index(project, creature_id)
	var to = member_index(project, target_id)
	if from == -1 or to == -1 or from == to:
		return false
	var members = members_of(project).duplicate(true)
	var destination_list = member_list_id(project, members[to])
	var moved: Dictionary = members[from]
	members.remove_at(from)
	to = -1
	for i in range(members.size()):
		if str(members[i].get("id", "")) == target_id:
			to = i
			break
	if to == -1:
		return false
	moved["list_id"] = destination_list
	members.insert(to + (1 if after else 0), moved)
	if members == members_of(project):
		return false
	project["members"] = members
	return true

static func move_member_by(project: Dictionary, creature_id: String, delta: int) -> bool:
	var from = member_index(project, creature_id)
	if from < 0:
		return false
	var list_id = member_list_id(project, members_of(project)[from])
	var pos = member_position(project, creature_id)
	if pos + delta < 1 or pos + delta > members_in_list(project, list_id).size():
		return false
	return move_member_to_position(project, creature_id, pos + delta)

static func notes_of(project: Dictionary) -> Array:
	var notes = project.get("notes", [])
	return notes if typeof(notes) == TYPE_ARRAY else []

static func note_index(project: Dictionary, note_id: String) -> int:
	var notes = notes_of(project)
	for i in range(notes.size()):
		if typeof(notes[i]) == TYPE_DICTIONARY and str(notes[i].get("id", "")) == note_id:
			return i
	return -1

static func add_note(project: Dictionary, note_id: String, text_value: String) -> bool:
	var clean = text_value.strip_edges().substr(0, 300)
	if clean.is_empty() or note_index(project, note_id) != -1:
		return false
	var notes = notes_of(project).duplicate(true)
	notes.append({"id": note_id, "text": clean, "done": false})
	project["notes"] = notes
	return true

static func update_note(project: Dictionary, note_id: String, next_text: String, done: bool) -> bool:
	var idx = note_index(project, note_id)
	if idx < 0:
		return false
	var notes = notes_of(project).duplicate(true)
	var note: Dictionary = notes[idx]
	var clean = next_text.strip_edges().substr(0, 300)
	if clean.is_empty() or (str(note.get("text", "")) == clean and bool(note.get("done", false)) == done):
		return false
	note["text"] = clean
	note["done"] = done
	project["notes"] = notes
	return true

static func remove_note(project: Dictionary, note_id: String) -> bool:
	var idx = note_index(project, note_id)
	if idx < 0:
		return false
	var notes = notes_of(project).duplicate(true)
	notes.remove_at(idx)
	project["notes"] = notes
	return true

static func creature_by_id(creatures: Array, creature_id: String) -> Dictionary:
	for creature in creatures:
		if typeof(creature) == TYPE_DICTIONARY and str(creature.get("local_id", "")) == creature_id:
			return creature
	return {}
