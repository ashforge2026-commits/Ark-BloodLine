extends RefCounted

const MAX_ARCHIVE = 50 * 1024 * 1024
const MAX_CENTRAL = 8 * 1024 * 1024
const MAX_ENTRY = 1024 * 1024
const MAX_TOTAL = 32 * 1024 * 1024
const MAX_COUNT = 3000
const MAX_OTHER_ENTRY = 16 * 1024 * 1024
const MAX_ALL_TOTAL = 64 * 1024 * 1024

static func _u16(data: PackedByteArray, at: int) -> int:
	if at < 0 or at + 2 > data.size():
		return -1
	return int(data[at]) | (int(data[at + 1]) << 8)

static func _u32(data: PackedByteArray, at: int) -> int:
	if at < 0 or at + 4 > data.size():
		return -1
	return int(data[at]) | (int(data[at + 1]) << 8) | (int(data[at + 2]) << 16) | (int(data[at + 3]) << 24)

static func inspect(path: String, include_all: bool = false) -> Dictionary:
	var file = FileAccess.open(path, FileAccess.READ)
	if file == null:
		return {"ok": false, "error": "Cannot open ZIP file."}
	var length = file.get_length()
	if length < 22 or length > MAX_ARCHIVE:
		return {"ok": false, "error": "ZIP is empty, invalid, or exceeds the 50 MB limit."}
	var tail_length = mini(length, 65557)
	file.seek(length - tail_length)
	var tail = file.get_buffer(tail_length)
	var end_at = -1
	for i in range(tail.size() - 22, -1, -1):
		if _u32(tail, i) == 0x06054b50 and i + 22 + _u16(tail, i + 20) == tail.size():
			end_at = i
			break
	if end_at < 0:
		return {"ok": false, "error": "ZIP directory is missing or corrupted."}
	var disk = _u16(tail, end_at + 4)
	var start_disk = _u16(tail, end_at + 6)
	var entries_on_disk = _u16(tail, end_at + 8)
	var count = _u16(tail, end_at + 10)
	var central_size = _u32(tail, end_at + 12)
	var central_offset = _u32(tail, end_at + 16)
	var eocd_offset = length - tail_length + end_at
	if disk != 0 or start_disk != 0 or entries_on_disk != count or count == 0xffff or central_size == 0xffffffff or central_offset == 0xffffffff:
		return {"ok": false, "error": "Multi-part and ZIP64 archives are not supported in this build."}
	if count > MAX_COUNT or central_size > MAX_CENTRAL or central_offset < 0 or central_offset + central_size > eocd_offset:
		return {"ok": false, "error": "ZIP directory exceeds limits or has invalid offsets."}
	file.seek(central_offset)
	var directory = file.get_buffer(central_size)
	if directory.size() != central_size:
		return {"ok": false, "error": "ZIP directory is incomplete."}
	var position = 0
	var total = 0
	var entries: Array = []
	var seen: Dictionary = {}
	for unused_index in range(count):
		if position + 46 > directory.size() or _u32(directory, position) != 0x02014b50:
			return {"ok": false, "error": "Invalid ZIP entry header."}
		var flags = _u16(directory, position + 8)
		var method = _u16(directory, position + 10)
		var crc = _u32(directory, position + 16)
		var compressed = _u32(directory, position + 20)
		var uncompressed = _u32(directory, position + 24)
		var name_length = _u16(directory, position + 28)
		var extra_length = _u16(directory, position + 30)
		var comment_length = _u16(directory, position + 32)
		var file_disk = _u16(directory, position + 34)
		var attributes = _u32(directory, position + 38)
		var local_offset = _u32(directory, position + 42)
		var next_position = position + 46 + name_length + extra_length + comment_length
		if next_position > directory.size() or name_length <= 0 or compressed == 0xffffffff or uncompressed == 0xffffffff or local_offset == 0xffffffff or file_disk != 0:
			return {"ok": false, "error": "Unsupported or malformed ZIP entry."}
		var raw_name = directory.slice(position + 46, position + 46 + name_length)
		if raw_name.has(0):
			return {"ok": false, "error": "Unsafe ZIP entry name."}
		var name = raw_name.get_string_from_utf8()
		var normalized = name.replace("\\", "/")
		if name.is_empty() or normalized.begins_with("/") or normalized.contains("../") or normalized == ".." or normalized.ends_with("/.."):
			return {"ok": false, "error": "Unsafe ZIP entry name."}
		if include_all and (normalized.contains(":") or raw_name != name.to_utf8_buffer()):
			return {"ok": false, "error": "Unsupported or unsafe ZIP entry name."}
		var seen_name = normalized.to_lower() if include_all else name
		if seen.has(seen_name):
			return {"ok": false, "error": "ZIP contains duplicate entry paths: " + name}
		seen[seen_name] = true
		position = next_position
		if normalized.ends_with("/"):
			continue
		if not include_all and not name.to_lower().ends_with(".ini"):
			continue
		if (flags & 1) != 0:
			return {"ok": false, "error": "Encrypted ZIP entries are not supported."}
		if method != 0 and method != 8:
			return {"ok": false, "error": "Unsupported ZIP compression method."}
		var unix_kind = (attributes >> 16) & 0xf000
		if unix_kind == 0xa000 or (include_all and unix_kind != 0 and unix_kind != 0x8000):
			return {"ok": false, "error": "Links and special files are not extracted."}
		var entry_limit = MAX_ENTRY if name.to_lower().ends_with(".ini") else MAX_OTHER_ENTRY
		if uncompressed > entry_limit:
			return {"ok": false, "error": "ZIP entry exceeds the allowed size: " + name}
		total += uncompressed
		if total > (MAX_ALL_TOTAL if include_all else MAX_TOTAL):
			return {"ok": false, "error": "ZIP contents exceed the allowed total size."}
		if local_offset < 0 or local_offset + 30 > central_offset:
			return {"ok": false, "error": "Invalid local ZIP header."}
		file.seek(local_offset)
		var local = file.get_buffer(30)
		if local.size() != 30 or _u32(local, 0) != 0x04034b50 or _u16(local, 6) != flags or _u16(local, 8) != method:
			return {"ok": false, "error": "ZIP local header disagrees with its directory."}
		var local_name_length = _u16(local, 26)
		var local_extra_length = _u16(local, 28)
		if local_offset + 30 + local_name_length + local_extra_length + compressed > central_offset:
			return {"ok": false, "error": "ZIP entry data exceeds its bounds."}
		var local_name = file.get_buffer(local_name_length)
		if local_name != raw_name:
			return {"ok": false, "error": "ZIP entry names do not match."}
		if (flags & 8) == 0 and (_u32(local, 18) != compressed or _u32(local, 22) != uncompressed):
			return {"ok": false, "error": "ZIP entry sizes do not match."}
		entries.append({"path": name, "size": uncompressed, "crc": crc})
	file.close()
	return {"ok": true, "entries": entries, "total": total}

static func crc32(bytes: PackedByteArray) -> int:
	var table: Array = []
	for i in range(256):
		var v = i
		for ignored in range(8):
			v = (v >> 1) ^ (0xedb88320 if (v & 1) != 0 else 0)
		table.append(v)
	var value = 0xffffffff
	for b in bytes:
		value = int(table[(value ^ int(b)) & 0xff]) ^ (value >> 8)
	return (value ^ 0xffffffff) & 0xffffffff
