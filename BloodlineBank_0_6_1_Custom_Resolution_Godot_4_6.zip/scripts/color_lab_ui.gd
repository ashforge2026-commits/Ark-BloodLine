extends VBoxContainer

# Shared PC / Android Color Lab. All edits are previews or saved design presets;
# the imported creature list and ARK files are never modified here.
const LabModel = preload("res://scripts/color_lab.gd")
const PaletteScript = preload("res://scripts/palette.gd")
const Preview = preload("res://scripts/creature_preview.gd")
const Registry = preload("res://scripts/species_registry.gd")
const DesignStore = preload("res://scripts/color_design_store.gd")
const Appearance = preload("res://scripts/appearance.gd")
const BG = Color("#0b2330")
const EDGE = Color("#29566a")
const INK = Color("#e9f6fc")
const DIM = Color("#a0b9c8")
const BRIGHT = Color("#48d6ee")

var palette
var registry
var session: Dictionary
var library: Dictionary
var design_store = DesignStore.new()
var saved_designs: Dictionary
var appearance: Dictionary = {}
var draft_name = ""
var model
var is_mobile = false
var status = ""
var mode = "all"
var body: VBoxContainer
var name_input: LineEdit
var picker: PopupPanel
var picker_query: LineEdit
var picker_rows: VBoxContainer
var picker_slot = 0
var landscape_layout = false

func configure(palette_ref, registry_ref, library_ref: Dictionary, session_ref: Dictionary, mobile: bool = false, creature: Dictionary = {}, colors: Dictionary = {}) -> void:
	palette = palette_ref
	registry = registry_ref
	library = library_ref
	appearance = colors
	saved_designs = design_store.load_designs(library.get("color_lab_presets", []))
	session = session_ref
	is_mobile = mobile
	var species = str(creature.get("species_name", session.get("species", Registry.LAB_SPECIES[0])))
	_select_species(species)
	if not creature.is_empty() and model.from_creature(creature):
		status = "Loaded confirmed colors from " + str(creature.get("name", species))
	if not design_store.last_warning.is_empty():
		status = design_store.last_warning

func set_library(next_library: Dictionary) -> void:
	library = next_library
	for design in session["models"].values():
		design.library = next_library

func _select_species(species: String) -> void:
	session["species"] = species
	if not session.has("models"):
		session["models"] = {}
	if not session.has("poses"):
		session["poses"] = {}
	if not session["models"].has(species):
		session["models"][species] = LabModel.new(palette, library, registry.lab_subject(species))
	model = session["models"][species]
	set_library(library)
	status = ""
	_render()

func _ready() -> void:
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	size_flags_vertical = Control.SIZE_EXPAND_FILL
	var scroll = ScrollContainer.new()
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(scroll)
	body = VBoxContainer.new()
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 10)
	scroll.add_child(body)
	_build_picker()
	resized.connect(_on_layout_size_changed)
	landscape_layout = is_mobile and size.x >= 680
	_render()

func _on_layout_size_changed() -> void:
	var should_be_landscape = is_mobile and size.x >= 680
	if should_be_landscape != landscape_layout:
		landscape_layout = should_be_landscape
		call_deferred("_render")

func _sty(bg: Color = BG, border: Color = EDGE, is_swatch: bool = false) -> StyleBoxFlat:
	var style = StyleBoxFlat.new()
	style.bg_color = bg if is_swatch else Appearance.surface(bg, appearance)
	style.border_color = Appearance.accent(appearance) if border == BRIGHT and not appearance.is_empty() else Appearance.surface(border, appearance)
	style.set_border_width_all(1)
	style.set_corner_radius_all(9)
	style.set_content_margin_all(3 if is_swatch else 9)
	return style

func _panel() -> PanelContainer:
	var panel = PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _sty())
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return panel

func _label(text: String, font_size: int = 16, tint: Color = INK) -> Label:
	var label = Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", tint)
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return label

func _btn(text: String, emphasis: bool = false) -> Button:
	var b = Button.new()
	b.text = text
	b.custom_minimum_size.y = 50 if is_mobile else 38
	b.clip_text = true
	b.add_theme_font_size_override("font_size", 16 if is_mobile else 14)
	b.add_theme_color_override("font_color", INK)
	b.add_theme_stylebox_override("normal", _sty(Color("#16516a") if emphasis else Color("#173847"), BRIGHT if emphasis else EDGE))
	b.add_theme_stylebox_override("hover", _sty(Color("#24677b"), BRIGHT))
	b.add_theme_stylebox_override("pressed", _sty(Color("#0b5b6f"), BRIGHT))
	return b

func _style_input(control: Control) -> void:
	control.add_theme_stylebox_override("normal", _sty(Color("#091b27")))
	control.add_theme_stylebox_override("focus", _sty(Color("#0b2330"), BRIGHT))
	if control is OptionButton:
		control.add_theme_stylebox_override("hover", _sty(Color("#173847"), BRIGHT))
		control.add_theme_stylebox_override("pressed", _sty(Color("#173847"), BRIGHT))

func _clear(node: Node) -> void:
	for child in node.get_children():
		node.remove_child(child)
		child.queue_free()

func _build_picker() -> void:
	picker = PopupPanel.new()
	picker.title = "Choose ARK color"
	add_child(picker)
	var layout = VBoxContainer.new()
	layout.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layout.add_theme_constant_override("separation", 6)
	picker.add_child(layout)
	picker_query = LineEdit.new()
	_style_input(picker_query)
	picker_query.placeholder_text = "Find color ID or name"
	picker_query.clear_button_enabled = true
	picker_query.custom_minimum_size.y = 46
	layout.add_child(picker_query)
	var list_scroll = ScrollContainer.new()
	list_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	list_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	layout.add_child(list_scroll)
	picker_rows = VBoxContainer.new()
	picker_rows.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list_scroll.add_child(picker_rows)
	picker_query.text_changed.connect(_refresh_picker)

func _choose(slot: int) -> void:
	picker_slot = slot
	picker_query.clear()
	_refresh_picker("")
	var available = get_viewport_rect().size
	var popup_width = mini(360 if is_mobile else 460, maxi(230, roundi(available.x) - 24))
	var popup_height = mini(550, maxi(200, roundi(available.y) - 24))
	picker.popup_centered(Vector2i(popup_width, popup_height))
	picker_query.grab_focus()

func _refresh_picker(query: String) -> void:
	if not is_instance_valid(picker_rows):
		return
	_clear(picker_rows)
	var matches = palette.search(query)
	# Avoid constructing 227 full control rows each time the picker opens.
	# All colors remain accessible through the live ID/name search.
	var shown = 0
	for entry in matches:
		if shown >= 60:
			break
		shown += 1
		var id = int(entry.get("id", -1))
		var r = HBoxContainer.new()
		r.add_theme_constant_override("separation", 8)
		picker_rows.add_child(r)
		var square = ColorRect.new()
		square.color = PaletteScript.display_color(entry.get("rgba", []))
		square.custom_minimum_size = Vector2(40, 40)
		square.mouse_filter = Control.MOUSE_FILTER_IGNORE
		r.add_child(square)
		var b = _btn("#%s  %s" % [id, str(entry.get("name", "Unknown"))])
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.pressed.connect(func():
			model.set_color(picker_slot, id)
			status = "Region %s changed to color #%s." % [picker_slot, id]
			picker.hide()
			_render()
		)
		r.add_child(b)
	if matches.is_empty():
		picker_rows.add_child(_label("No matching color ID or name.", 15, DIM))
	elif matches.size() > 60:
		picker_rows.add_child(_label("Showing 60 of %s. Search by ID or name for more." % matches.size(), 13, DIM))

func _make_preview() -> Control:
	var center = CenterContainer.new()
	var pixels = 170 if landscape_layout else (220 if is_mobile else 255)
	center.custom_minimum_size.y = 182 if landscape_layout else (236 if is_mobile else 270)
	var creature = model.preview_creature()
	var pose = int(session["poses"].get(model.species_name, 0))
	var image = Preview.build(creature, registry.images_for(creature, pose), Vector2(pixels, pixels), true)
	image.name = "ColorLabCreaturePreview"
	center.add_child(image)
	return center

func _render() -> void:
	if not is_instance_valid(body):
		return
	_clear(body)
	var header = HBoxContainer.new()
	header.add_theme_constant_override("separation", 8)
	body.add_child(header)
	if not is_mobile:
		var title = _label("Color Lab", 23, INK)
		title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		header.add_child(title)
	var species = OptionButton.new()
	_style_input(species)
	species.name = "ColorLabSpecies"
	species.custom_minimum_size.y = 46 if is_mobile else 38
	for name in Registry.LAB_SPECIES:
		species.add_item(name)
	species.select(Registry.LAB_SPECIES.find(model.species_name))
	species.item_selected.connect(func(index: int): _select_species(Registry.LAB_SPECIES[index]))
	species.size_flags_horizontal = Control.SIZE_EXPAND_FILL if is_mobile else Control.SIZE_FILL
	species.custom_minimum_size.x = 128
	header.add_child(species)
	if Registry.ALTERNATE_POSES.has(model.species_name):
		var pose = OptionButton.new()
		_style_input(pose)
		pose.name = "ColorLabPose"
		pose.custom_minimum_size.y = 46 if is_mobile else 38
		pose.add_item("Side view")
		pose.add_item("Front angle")
		pose.select(int(session["poses"].get(model.species_name, 0)))
		pose.item_selected.connect(func(index: int):
			session["poses"][model.species_name] = index
			_render()
		)
		pose.custom_minimum_size.x = 118
		header.add_child(pose)
	var preview_panel = _panel()
	body.add_child(preview_panel)
	var preview_stack = VBoxContainer.new()
	preview_panel.add_child(preview_stack)
	preview_stack.add_child(_make_preview())
	preview_stack.add_child(_label("Preview colors vary with in-game lighting.", 13, DIM))
	var regions = HBoxContainer.new()
	regions.name = "ColorLabRegionStrip"
	regions.add_theme_constant_override("separation", 3 if is_mobile else 8)
	body.add_child(regions)
	for slot in range(6):
		regions.add_child(_region_tile(slot))
	var generator = _panel()
	body.add_child(generator)
	var tools = VBoxContainer.new()
	tools.add_theme_constant_override("separation", 9)
	generator.add_child(tools)
	tools.add_child(_label("Randomizer", 19, INK))
	var mode_option = OptionButton.new()
	_style_input(mode_option)
	for entry in [["All ARK colors", "all"], ["My collection (per region)", "owned"], ["One solid color", "solid"]]:
		mode_option.add_item(str(entry[0]))
	mode_option.select(["all", "owned", "solid"].find(mode))
	mode_option.custom_minimum_size.y = 46 if is_mobile else 38
	mode_option.item_selected.connect(func(idx: int): mode = ["all", "owned", "solid"][idx])
	var generator_row = HFlowContainer.new()
	generator_row.add_theme_constant_override("h_separation", 8)
	tools.add_child(generator_row)
	mode_option.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	generator_row.add_child(mode_option)
	var generate = _btn("Randomize unlocked", true)
	generate.custom_minimum_size.x = 176
	generate.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	generate.pressed.connect(func():
		var result = model.randomize_colors(mode)
		status = str(result.get("message", ""))
		_render()
	)
	generator_row.add_child(generate)
	var actions = HBoxContainer.new()
	if is_mobile:
		tools.add_child(actions)
	else:
		generator_row.add_child(actions)
	var undo = _btn("Undo")
	undo.custom_minimum_size.x = 64
	undo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	undo.disabled = model.history.is_empty()
	undo.pressed.connect(func():
		model.undo()
		status = "Previous colors restored."
		_render()
	)
	actions.add_child(undo)
	var reset = _btn("Reset to white")
	reset.custom_minimum_size.x = 112
	reset.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	reset.pressed.connect(func():
		model.reset()
		status = "Reset to white."
		_render()
	)
	actions.add_child(reset)
	if not status.is_empty():
		body.add_child(_label(status, 14, Appearance.accent(appearance)))
	var saved_panel = _panel()
	body.add_child(saved_panel)
	var saved_stack = VBoxContainer.new()
	saved_stack.add_theme_constant_override("separation", 8)
	saved_panel.add_child(saved_stack)
	saved_stack.add_child(_label("Saved designs", 19, INK))
	var save_row = HBoxContainer.new()
	saved_stack.add_child(save_row)
	name_input = LineEdit.new()
	_style_input(name_input)
	name_input.placeholder_text = "Design name (optional)"
	name_input.custom_minimum_size.x = 108
	name_input.text = draft_name
	name_input.text_changed.connect(func(value): draft_name = value)
	name_input.text_submitted.connect(func(_value): _save_design())
	name_input.max_length = 64
	name_input.custom_minimum_size.y = 46 if is_mobile else 38
	name_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	save_row.add_child(name_input)
	var save = _btn("Save design", true)
	save.name = "ColorLabSaveDesign"
	save.custom_minimum_size.x = 110
	save.disabled = saved_designs.get("read_only", false)
	save.pressed.connect(_save_design)
	save_row.add_child(save)
	var presets = saved_designs.get("designs", [])
	var shown = false
	if typeof(presets) == TYPE_ARRAY:
		for entry in presets:
			if typeof(entry) != TYPE_DICTIONARY or entry.get("species", Registry.LAB_SPECIES[0]) != model.species_name:
				continue
			shown = true
			var design: Dictionary = entry
			var line = HBoxContainer.new()
			saved_stack.add_child(line)
			var open = _btn(str(design.get("name", "Untitled")))
			open.alignment = HORIZONTAL_ALIGNMENT_LEFT
			open.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			open.pressed.connect(func():
				if model.apply_colors(design.get("ids", [])):
					status = "Loaded: " + str(design.get("name", "Untitled"))
				else:
					status = "Design already selected or preset is invalid."
				_render()
			)
			line.add_child(open)
			var remove = _btn("×")
			remove.custom_minimum_size.x = 38
			remove.disabled = saved_designs.get("read_only", false)
			remove.tooltip_text = "Delete saved design"
			remove.pressed.connect(func(): _delete_design(str(design.get("key", ""))))
			line.add_child(remove)
	if not shown:
		saved_stack.add_child(_label("No designs saved for this creature yet.", 14, DIM))

func _region_tile(slot: int) -> Control:
	var cell = VBoxContainer.new()
	cell.name = "ColorLabRegionR%s" % slot
	cell.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cell.add_theme_constant_override("separation", 3)
	var active = slot in model.active_regions
	var region_name = str(model.region_names[slot]) if active else "Unused region"
	var heading = _label("R%s" % slot if is_mobile or not active else "R%s · %s" % [slot, region_name], 13, INK if active else DIM)
	heading.clip_text = true
	heading.autowrap_mode = TextServer.AUTOWRAP_OFF
	heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	heading.tooltip_text = region_name
	cell.add_child(heading)
	var pick = _btn("#%s" % model.ids[slot] if active else "×")
	pick.name = "ColorLabRegionColor"
	pick.custom_minimum_size.x = 44
	pick.add_theme_font_size_override("font_size", 13)
	pick.custom_minimum_size.y = 44 if is_mobile else 38
	pick.tooltip_text = "%s · %s" % [region_name, model.label_for(slot)] if active else region_name
	pick.disabled = not active
	if active:
		var entry = palette.get_color(int(model.ids[slot]))
		var color = PaletteScript.display_color(entry.get("rgba", []))
		var ink = Color.BLACK if color.get_luminance() >= 0.18 else Color.WHITE
		for state in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
			pick.add_theme_color_override(state, ink)
		pick.add_theme_stylebox_override("normal", _sty(color, EDGE, true))
		pick.add_theme_stylebox_override("hover", _sty(color, Appearance.accent(appearance), true))
		pick.add_theme_stylebox_override("pressed", _sty(color, Appearance.accent(appearance), true))
		pick.pressed.connect(func(): _choose(slot))
	cell.add_child(pick)
	if active:
		var locked = bool(model.locked[slot])
		var lock = _btn(("🔓" if is_mobile else "Unlock") if locked else ("🔒" if is_mobile else "Lock"), locked)
		lock.custom_minimum_size.y = 42 if is_mobile else 34
		lock.tooltip_text = "Locked. Click to unlock." if locked else "Lock this color for Randomize"
		lock.pressed.connect(func():
			model.toggle_lock(slot)
			_render()
		)
		cell.add_child(lock)
	return cell

func _save_design() -> void:
	var name = name_input.text.strip_edges()
	var existing = saved_designs.get("designs", [])
	if typeof(existing) != TYPE_ARRAY:
		existing = []
	if existing.size() >= 50:
		status = "50 design limit reached. Delete a saved design first."
		_render()
		return
	if name.is_empty():
		name = "Design %s" % (existing.size() + 1)
	var next: Array = existing.duplicate(true)
	next.append({"key": "%s-%s" % [Time.get_unix_time_from_system(), Time.get_ticks_usec()], "name": name, "ids": model.ids.duplicate(), "species": model.species_name})
	_store_presets(next, "Saved design: " + name)

func _delete_design(key: String) -> void:
	if key.is_empty():
		status = "This saved design cannot be removed (missing ID)."
		_render()
		return
	var old = saved_designs.get("designs", [])
	if typeof(old) != TYPE_ARRAY:
		return
	var next: Array = []
	for entry in old:
		if typeof(entry) == TYPE_DICTIONARY and str(entry.get("key", "")) != key:
			next.append(entry)
	if next.size() == old.size():
		return
	_store_presets(next, "Removed saved design.")

func _store_presets(next: Array, message: String) -> void:
	var candidate = saved_designs.duplicate()
	candidate["designs"] = next
	var result: Dictionary = design_store.save_data(candidate)
	if result.get("ok", false):
		saved_designs = candidate
		draft_name = ""
		status = message
	else:
		status = "Save failed: " + str(result.get("error", "Unknown error"))
	_render()
