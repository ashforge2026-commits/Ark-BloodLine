extends Control

var sex: String = "Unknown"

func _init(value: String = "Unknown") -> void:
	sex = value
	custom_minimum_size = Vector2(42, 24)
	size_flags_vertical = Control.SIZE_SHRINK_CENTER
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _draw() -> void:
	if sex == "Female":
		var pink = Color("#ff91c9")
		draw_arc(Vector2(10, 8), 5.5, 0.0, TAU, 32, pink, 2.0, true)
		draw_line(Vector2(10, 13.5), Vector2(10, 22), pink, 2.0, true)
		draw_line(Vector2(6, 18.5), Vector2(14, 18.5), pink, 2.0, true)
	elif sex == "Male":
		var blue = Color("#35d5f4")
		draw_arc(Vector2(8, 15), 5.5, 0.0, TAU, 32, blue, 2.0, true)
		draw_line(Vector2(12, 11), Vector2(20, 3), blue, 2.0, true)
		draw_line(Vector2(15, 3), Vector2(20, 3), blue, 2.0, true)
		draw_line(Vector2(20, 3), Vector2(20, 8), blue, 2.0, true)
