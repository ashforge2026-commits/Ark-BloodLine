extends RefCounted

const DEFAULT_DATA_PATH = "user://bloodlinebank.json"
var data_path = DEFAULT_DATA_PATH
var temp_path = "user://bloodlinebank.json.tmp"
var backup_path = "user://bloodlinebank.json.backup"
var last_warning = ""

func _init(path: String = DEFAULT_DATA_PATH) -> void:
	data_path = path
	temp_path = path + ".tmp"
	backup_path = path + ".backup"

func empty_data() -> Dictionary:
	return {"version": 1, "creatures": [], "goals": {}, "projects": {}}

func _read_json(path: String):
	if not FileAccess.file_exists(path):
		return null
	var file = FileAccess.open(path, FileAccess.READ)
	if file == null or file.get_length() > 128 * 1024 * 1024:
		return null
	return JSON.parse_string(file.get_as_text())

func _read_valid(path: String):
	var value = _read_json(path)
	if typeof(value) != TYPE_DICTIONARY or typeof(value.get("creatures")) != TYPE_ARRAY or typeof(value.get("goals")) != TYPE_DICTIONARY:
		return null
	return value

func load_data() -> Dictionary:
	last_warning = ""
	var value = _read_valid(data_path)
	if value != null:
		return value
	if FileAccess.file_exists(data_path):
		last_warning = "The saved library could not be read. Checking backup."
	value = _read_valid(backup_path)
	if value != null:
		last_warning = "Loaded the previous backup in read-only mode because the latest library was missing or invalid. Copy the backup to a safe location before restoring."
		value["read_only"] = true
		return value
	if FileAccess.file_exists(data_path) or FileAccess.file_exists(backup_path):
		last_warning = "The library and backup could not be read. Existing files were not overwritten."
		var recovery = empty_data()
		recovery["read_only"] = true
		return recovery
	return empty_data()

func save_data(data: Dictionary) -> Dictionary:
	if data.get("read_only", false):
		return {"ok": false, "error": "Read-only recovery mode: existing data was not overwritten."}
	var out = FileAccess.open(temp_path, FileAccess.WRITE)
	if out == null:
		return {"ok": false, "error": "Could not write the temporary save file."}
	out.store_string(JSON.stringify(data, "\t"))
	out.flush()
	out.close()
	if _read_valid(temp_path) == null:
		return {"ok": false, "error": "Temporary save could not be verified."}
	var destination = ProjectSettings.globalize_path(data_path)
	var temporary = ProjectSettings.globalize_path(temp_path)
	var backup = ProjectSettings.globalize_path(backup_path)
	if FileAccess.file_exists(data_path):
		var copy_error = DirAccess.copy_absolute(destination, backup)
		if copy_error != OK:
			return {"ok": false, "error": "Could not make a backup; library was not changed."}
	var rename_error = DirAccess.rename_absolute(temporary, destination)
	if rename_error != OK and FileAccess.file_exists(data_path):
		# Some platforms cannot rename over an existing file. The backup is already complete.
		var remove_error = DirAccess.remove_absolute(destination)
		if remove_error != OK:
			return {"ok": false, "error": "Could not replace save; previous library remains intact."}
		rename_error = DirAccess.rename_absolute(temporary, destination)
		if rename_error != OK:
			DirAccess.copy_absolute(backup, destination)
	if rename_error != OK:
		return {"ok": false, "error": "Could not finish saving; previous backup was preserved."}
	return {"ok": true}
