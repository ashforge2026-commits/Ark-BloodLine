extends RefCounted

const Goals = preload("res://scripts/color_goals.gd")

# Count the selected color on each individual creature. The goal's region
# lists already contain only confirmed matches on active visible regions.
# Keep IDs separate even if several creatures have identical names and levels.
static func carrier_match_counts(goal: Dictionary) -> Dictionary:
	var counts: Dictionary = {}
	for region in goal.get("regions", []):
		if region.get("status", "") != "found":
			continue
		var seen_in_region: Dictionary = {}
		for raw_id in region.get("carrier_ids", []):
			var local_id = str(raw_id)
			if local_id.is_empty() or seen_in_region.has(local_id):
				continue
			seen_in_region[local_id] = true
			counts[local_id] = int(counts.get(local_id, 0)) + 1
	return counts

# Keep the bingo calculation tied to the existing color-goal rules.
static func build(creatures: Array, species_key: String, region_names, palette) -> Array:
	var rows: Array = []
	var index = Goals.build_index(creatures, species_key, region_names)
	for id in range(1, 256):
		var item: Dictionary = palette.get_color(id)
		if item.is_empty():
			rows.append({"id": id, "name": "Not in color data", "defined": false, "status": "undefined", "found": 0, "total": 0, "unknown": 0})
			continue
		var goal = Goals.calculate_indexed(index, id)
		var status = "progress"
		if goal.get("status") == "complete":
			status = "bingo"
		elif goal.get("status") == "unknown_regions" or int(goal.get("unknown", 0)) > 0:
			status = "unknown"
		elif int(goal.get("found", 0)) == 0:
			status = "missing"
		rows.append({"id": id, "name": str(item.get("name", "Unknown")), "rgba": item.get("rgba", []), "defined": true, "status": status, "found": int(goal.get("found", 0)), "total": int(goal.get("total", 0)), "unknown": int(goal.get("unknown", 0))})
	return rows

static func filtered(rows: Array, query: String, filter: int, order: int) -> Array:
	var q = query.strip_edges().to_lower()
	var result: Array = []
	for row in rows:
		if not q.is_empty() and not str(row["id"]).contains(q) and not str(row["name"]).to_lower().contains(q):
			continue
		if filter == 1 and row["status"] != "bingo":
			continue
		if filter == 2 and (not row["defined"] or row["status"] == "bingo" or row["status"] == "unknown" or int(row["unknown"]) != 0 or int(row["total"]) <= 0 or int(row["total"]) - int(row["found"]) != 1):
			continue
		if filter == 3 and row["status"] != "unknown":
			continue
		result.append(row)
	if order == 1:
		result.sort_custom(func(a, b): return int(a["id"]) > int(b["id"]))
	elif order == 2:
		result.sort_custom(func(a, b):
			if (a["status"] == "bingo") != (b["status"] == "bingo"):
				return a["status"] == "bingo"
			return int(a["id"]) < int(b["id"])
		)
	elif order == 3:
		result.sort_custom(func(a, b):
			if (a["status"] == "bingo") != (b["status"] == "bingo"):
				return a["status"] == "bingo"
			if bool(a["defined"]) != bool(b["defined"]):
				return bool(a["defined"])
			if int(a["found"]) != int(b["found"]):
				return int(a["found"]) > int(b["found"])
			return int(a["id"]) < int(b["id"])
		)
	else:
		result.sort_custom(func(a, b): return int(a["id"]) < int(b["id"]))
	return result
