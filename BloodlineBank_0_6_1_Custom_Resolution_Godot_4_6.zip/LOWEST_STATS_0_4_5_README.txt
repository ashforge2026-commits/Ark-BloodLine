BLOODLINEBANK 0.4.5 — LOWEST STATS TRACKER

What changed
- scripts/lowest_stats.gd: read-only minimum-point/displayed-stat index and ranking.
- scripts/main.gd: Lowest Stats navigation, species/mode filters, stat overview,
  tied carriers and ranked clickable creature list.
- tests/test_lowest_stats.gd: isolated regression tests (not runtime-executed).
- project.godot: version caption only.
- README_FIRST.txt and TEST_REPORT.txt: user instructions and test status.

What stayed untouched
- Existing parser, storage, import service, Color Bingo, Partner Finder, X marks,
  Projects and creature data formats. Existing `user://bloodlinebank.json` remains
  the data source; tracker makes no writes.

How to use
1. Extract the ZIP in a separate directory, open project.godot in Godot 4.6.
2. Open Lowest Stats, choose X-Otter and mode.
3. Click Health/Stamina/etc to list which otter(s) carry the smallest number.
4. Click an otter in the right panel to see its Creature Library details.
5. For Level 1 breeding, use exported wild-points when present and verify
   mutation levels separately. A lower displayed HP is NOT a guaranteed lower
   inherited HP point count.

Recommended local test command (isolated test data only):
  BLOODLINEBANK_TEST_MODE=1 BLOODLINEBANK_DISABLE_AUTOSCAN=1 godot --headless --path . --script res://tests/test_lowest_stats.gd

Current testing
- Implemented; static checks intended.
- Godot parser, runtime, GUI and user's real ARK exports: not tested here.
