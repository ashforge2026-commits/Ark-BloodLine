BloodlineBank 0.4.0 — easier otter dragging (Godot 4.6)

Changed ONLY Projects drag-and-drop UI + 2 new small scripts:
* Drag from the otter picture/name OR the wider left ↕ grip.
* Drop onto any part of a list's wide ↧ DROP OTTER HERE heading, including closed/empty lists.
* An expanded empty list has a large extra drop area.
* A successful cross-list drop opens the target and appends the otter to the bottom.
* Dropping on your own list heading moves the otter to the end (if not already last).
* Drop onto the picture/name or blank area of another row to reorder.
* Dragging near the scroll area's top/bottom edges auto-scrolls the long table.
* Keep the numbered position field and Move to list dropdown as alternatives.

Unchanged: project ID/member data model, row numbers, list save format,
notes, color table, library data, importer, ARK auto-sync, filters, assets.
No creatures or lists are copied or deleted by moving a row.

TEST IN GODOT: Create empty 'First Breed', drag an otter by its name and
release onto First Breed heading or large empty box. Confirm it appears there.
Collapse list, drag another onto its header; it should open with 2 otters.
Reorder using name drag onto another row, and test numeric position edit.
Drag near scroll top/bottom to move long lists without mouse-wheel use.
Restart app and confirm membership and positions remain. Also verify
renaming/deleting lists, notes, filters, ARK sync, and existing project upgrade.

Status: source changes are implemented. Runtime functionality must be tested
in Godot 4.6 on your PC unless an actual Godot runtime test is recorded.
