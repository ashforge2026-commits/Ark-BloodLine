BLOODLINEBANK 0.4.4 — FEMALE USED X MARKS
=========================================
Parent: 0.4.3 Useful Partners Only (complete Godot 4.6 project).

WHAT'S NEW
- Each female result in Partner Finder has a small separate 'Used' toggle.
- Empty square (□) = available/unmarked; red X (✕) = already used in another breeding.
- Click X to set the mark, click again to clear it.
- Marked females remain visible, selectable, and ranked exactly as before.
- The match count includes marked females; the heading displays how many are marked.
- Selecting a marked female displays a reminder in Breeding Comparison.
- Marks are GLOBAL per imported female (local_id), not per male or target color.
- They persist when the app restarts using the existing local save file.

DATA SAFETY
- The marks are stored in a new optional top-level 'partner_used_females' dictionary
  within user://bloodlinebank.json: { "creature_local_id": true }.
- No saved creature, project, color goal, or existing breeding list is modified.
- The file path, format version, and save/backup procedure are unchanged.
- Existing saves do not need migration. Missing marks are treated as unmarked.
- If saving fails or the library is in read-only recovery, the X is NOT changed.
- Marked creatures are not filtered out or removed from the library.

MODIFIED FILES
- scripts/main.gd (row toggle, mark persistence, summary/detail indicator)
- tests/test_partner_finder.gd (isolated mark/save/clear/reload/read-only checks)
- project.godot (version comment only)
- new PARTNER_FINDER_0_4_4_README.txt

TESTING
Open project.godot in Godot 4.6 and press F5.
Partner Finder -> pick a male -> Find Females -> click an empty square
beside a female. Verify red X appears. Switch tabs, pick another male,
close and reopen: the same female should retain X. Click it again to clear.
Ranked results must still include marked females in the same order.

Headless regression test (isolated throwaway user file, autoscan disabled):
  BLOODLINEBANK_TEST_MODE=1 BLOODLINEBANK_DISABLE_AUTOSCAN=1 godot --headless --path . -s res://tests/test_partner_finder.gd

Test runner must run with the environment variables shown. Windows GUI and
real-user-data runtime behavior require user confirmation.
