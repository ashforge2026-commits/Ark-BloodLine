BLOODLINEBANK v0.5.0 — MOBILE BETA + X-OTTER COLOR LAB
====================================================

WHAT'S INCLUDED
- Godot 4.6 project built from the original BloodlineBank 0.4.5 archive.
- Original PC main.tscn preserved; one small Android/preview branch was added
  to scripts/main.gd. All existing PC pages remain intact.
- PC Color Lab tab with live 256px X-Otter mask/shader preview.
- Android touch shell automatically selected on Android. Horizontally
  scrollable tabs: Library, Color Lab, Bingo, Colors, Projects, Partners,
  Lowest, Tools.
- Manual test colors for X-Otter active regions 0/2/3/4/5 using exact palette
  IDs/names, searchable color picker, lock toggles, undo, reset to white.
- Randomizer: All 227 defined palette IDs, my owned IDs *per region*, and
  one solid color across unlocked regions. Locked regions are unchanged.
- Save up to 50 named design presets to the local library, load or remove
  them. No color operation edits an imported creature or ARK game file.
- Mobile import review for .ini and .zip, plus JSON backup export and
  confirmed JSON restore to transfer a library from PC to phone.
- Mobile read-only Projects lists; selected creatures open touch details.
- Mobile Color Bingo, Color Table, Partner Finder, and Lowest Stats view
  rely on the existing calculation scripts.

WHAT REMAINS PC-ONLY IN THIS BETA
- Editing/sorting breeding Projects (mobile Projects is view-only).
- Detailed Color Goals editor and some advanced PC table filters.
- PC automatic DinoExports folder scanning (not available on Android).
- Mobile FileDialog/Android document-provider support is implemented as
  candidate code but has not been tested on a real Android phone.

HOW TO TEST ON PC
1. Make a backup of the existing user://bloodlinebank.json.
2. Extract this ZIP to a NEW directory; open project.godot in Godot 4.6.
3. Run the project normally: original PC UI with Color Lab tab.
4. For the Android-style UI, run with command line:
     godot --path <project-folder> -- --mobile-preview
   Resize the window to a phone-sized portrait view for layout inspection.
5. Before using live data, test the following in a new empty user-data dir:
     BLOODLINEBANK_TEST_MODE=1 BLOODLINEBANK_DISABLE_AUTOSCAN=1 godot --headless --path . --script res://tests/test_color_lab.gd
   Then run the existing tests listed in TEST_REPORT.txt.

HOW TO MAKE AN ANDROID APK
1. Install official Godot 4.6 Android export templates and required SDK/JDK.
2. Open this project in the Godot 4.6 desktop editor.
3. Project > Export... > Add Android. Configure SDK/application ID,
   permissions, and signing according to Godot's export setup instructions.
4. Export a debug APK and INSTALL IT ON YOUR PHONE for real UI and file
   access checks. This ZIP is the Godot project, not an installable APK.

HOW TO MOVE YOUR DATA FROM PC
- On PC, your saved bloodlinebank.json is under Godot's user data folder
  for "BloodlineBank_Prototype". Create a copy of the file, not a move.
- Transfer the copy to your phone, open Android Tools > Restore PC / phone
  backup (.json), review the creature counts, and confirm replacement.
- Phone data is local and independent; there is no automatic cloud sync.
- The PC copy is NOT edited by a phone restore.
- For phone -> PC use Android Tools > Export library backup; keep a separate
  PC backup before manually copying data across.

IMPORTANT TESTING STATUS
- Implemented, source/file integrity checked, not Godot runtime compiled.
- This container has no Godot 4.6 executable or Android export templates.
- There is NO confirmed working APK or Android device test yet.
- The X-Otter preview is stylized and may differ from ARK lighting/materials.

PRESERVED UNCHANGED
Parser, storage engine, ARK import service, existing calculations,
projects data code, existing shader and image assets, 227-color source
palette, species registry, original main.tscn.
