shader_type canvas_item;
render_mode unshaded;

uniform sampler2D region_mask : filter_linear;
uniform sampler2D image_source : filter_linear;
uniform vec4 region_0 = vec4(0.5);
uniform vec4 region_1 = vec4(0.5);
uniform vec4 region_2 = vec4(0.5);
uniform vec4 region_3 = vec4(0.5);
uniform vec4 region_4 = vec4(0.5);
uniform vec4 region_5 = vec4(0.5);
uniform bool use_0 = false;
uniform bool use_1 = false;
uniform bool use_2 = false;
uniform bool use_3 = false;
uniform bool use_4 = false;
uniform bool use_5 = false;
uniform float detail_sharpen : hint_range(0.0, 0.5) = 0.0;
uniform bool high_quality_preview = false;

// Cubic interpolation of the original image, with alpha-weighted color to
// avoid pulling the colors of transparent pixels into the silhouette.
// This improves scaling only; it does not invent missing fur detail.
vec4 cubic_weights(float f) {
	float f2 = f * f;
	float f3 = f2 * f;
	return vec4(-0.5 * f + f2 - 0.5 * f3,
		1.0 - 2.5 * f2 + 1.5 * f3,
		0.5 * f + 2.0 * f2 - 1.5 * f3,
		-0.5 * f2 + 0.5 * f3);
}

vec4 sample_cubic_base(vec2 uv, vec2 pixel_size) {
	vec2 texel = uv / pixel_size - vec2(0.5);
	vec2 origin = floor(texel);
	vec2 fraction = fract(texel);
	vec4 wx = cubic_weights(fraction.x);
	vec4 wy = cubic_weights(fraction.y);
	vec3 premultiplied = vec3(0.0);
	float alpha_sum = 0.0;
	for (int y = 0; y < 4; y++) {
		for (int x = 0; x < 4; x++) {
			vec2 pos = (origin + vec2(float(x - 1), float(y - 1)) + vec2(0.5)) * pixel_size;
			vec4 s = texture(image_source, pos);
			float weight = wx[x] * wy[y];
			premultiplied += s.rgb * s.a * weight;
			alpha_sum += s.a * weight;
		}
	}
	if (alpha_sum <= 0.001) {
		return vec4(0.0);
	}
	return vec4(clamp(premultiplied / alpha_sum, vec3(0.0), vec3(1.0)), clamp(alpha_sum, 0.0, 1.0));
}

vec3 apply_region(vec3 base, vec3 color, float strength) {
	vec3 grain_merge = clamp(base + color - vec3(0.5), vec3(0.0), vec3(1.0));
	return mix(base, grain_merge, clamp(strength, 0.0, 1.0));
}

void fragment() {
	vec4 base = texture(TEXTURE, UV);
	// Use the higher-quality reconstruction only when the large preview is
	// magnified; downscaled pictures and table thumbnails keep their old path.
	vec2 uv_footprint = abs(dFdx(UV)) + abs(dFdy(UV));
	if (high_quality_preview && base.a > 0.001 && max(uv_footprint.x / TEXTURE_PIXEL_SIZE.x, uv_footprint.y / TEXTURE_PIXEL_SIZE.y) < 0.99) {
		base = sample_cubic_base(UV, TEXTURE_PIXEL_SIZE);
	}
	// A mild, alpha-aware detail boost improves the enlarged preview without
	// inventing new source detail or sharpening tiny table thumbnails.
	if (detail_sharpen > 0.0 && base.a > 0.001) {
		vec4 left_px = texture(TEXTURE, UV - vec2(TEXTURE_PIXEL_SIZE.x, 0.0));
		vec4 right_px = texture(TEXTURE, UV + vec2(TEXTURE_PIXEL_SIZE.x, 0.0));
		vec4 top_px = texture(TEXTURE, UV - vec2(0.0, TEXTURE_PIXEL_SIZE.y));
		vec4 bottom_px = texture(TEXTURE, UV + vec2(0.0, TEXTURE_PIXEL_SIZE.y));
		vec3 neighbours = (mix(base.rgb, left_px.rgb, left_px.a) + mix(base.rgb, right_px.rgb, right_px.a) + mix(base.rgb, top_px.rgb, top_px.a) + mix(base.rgb, bottom_px.rgb, bottom_px.a)) * 0.25;
		base.rgb = clamp(base.rgb + (base.rgb - neighbours) * detail_sharpen, vec3(0.0), vec3(1.0));
	}
	vec3 mask = texture(region_mask, UV).rgb;
	vec3 result = base.rgb;
	if (use_0) { result = apply_region(result, region_0.rgb, max(0.0, mask.r - mask.g - mask.b)); }
	if (use_1) { result = apply_region(result, region_1.rgb, max(0.0, mask.g - mask.r - mask.b)); }
	if (use_2) { result = apply_region(result, region_2.rgb, max(0.0, mask.b - mask.r - mask.g)); }
	if (use_3) { result = apply_region(result, region_3.rgb, min(mask.g, mask.b)); }
	if (use_4) { result = apply_region(result, region_4.rgb, min(mask.r, mask.g)); }
	if (use_5) { result = apply_region(result, region_5.rgb, min(mask.r, mask.b)); }
	COLOR = vec4(result, base.a);
}
