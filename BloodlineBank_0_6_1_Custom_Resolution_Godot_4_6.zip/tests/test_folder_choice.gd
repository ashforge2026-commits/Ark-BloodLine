extends SceneTree

var failures: Array = []

func check(value: bool, label: String) -> void:
	if value:
		print("PASS: ", label)
	else:
		failures.append(label)
		printerr("FAIL: ", label)

func _initialize() -> void:
	call_deferred("_run")

func wait_idle(app) -> void:
	await process_frame
	for i in range(200):
		if not app.is_importing:
			return
		await create_timer(0.05).timeout
	check(false, "scan finishes within timeout")

func _run() -> void:
	if OS.get_environment("BLOODLINEBANK_TEST_MODE") != "1":
		printerr("Use an isolated XDG_DATA_HOME and BLOODLINEBANK_TEST_MODE=1.")
		quit(1)
		return
	root.size = Vector2i(1280, 720)
	var first = ProjectSettings.globalize_path("user://custom_ark_exports")
	var second = ProjectSettings.globalize_path("user://Second Export Folder")
	DirAccess.make_dir_recursive_absolute(first)
	DirAccess.make_dir_recursive_absolute(second)
	var female = ProjectSettings.globalize_path("res://examples/DEMO_Female_XOtter.ini")
	var male = ProjectSettings.globalize_path("res://examples/DEMO_Male_XOtter.ini")
	DirAccess.copy_absolute(female, first.path_join("female.ini"))
	DirAccess.copy_absolute(female, second.path_join("female_copy.ini"))
	DirAccess.copy_absolute(male, second.path_join("male.ini"))
	var app = load("res://main.tscn").instantiate()
	root.add_child(app)
	await wait_idle(app)
	var button = app.middle.find_child("LibraryExportFolderButton", true, false) as Button
	app.search_field.text = "otter"
	button.pressed.emit()
	check(app.folder_dialog.visible and app.folder_dialog.current_dir.trim_suffix("/") == app.export_folder.trim_suffix("/"), "library button opens the picker at the current source")
	app._automatic_scan_tick()
	check(not app.is_importing, "auto-scan waits while the folder picker is open")
	app.folder_dialog.hide()
	check(not app.scan_settings.has_explicit_folder(), "closing the picker keeps the current preference")
	app.folder_dialog.dir_selected.emit(first)
	await wait_idle(app)
	check(app.export_folder == first and app.data["creatures"].size() == 1, "choosing a folder stores it and scans new creatures")
	check(app.selected_page == "library" and app.search_field.text == "otter" and button.tooltip_text == first, "library filter stays in place and the button shows the new path")
	app.message_dialog.hide()
	button.pressed.emit()
	check(app.folder_dialog.current_dir.trim_suffix("/") == first.trim_suffix("/"), "reopening starts in the newly chosen folder")
	app.folder_dialog.hide()
	app.folder_dialog.dir_selected.emit(second)
	await wait_idle(app)
	check(app.export_folder == second and app.data["creatures"].size() == 2, "switching folders adds new creatures without duplicating previous imports")
	app.queue_free()
	await process_frame
	var restart = load("res://main.tscn").instantiate()
	root.add_child(restart)
	await wait_idle(restart)
	check(restart.export_folder == second and restart.data["creatures"].size() == 2, "chosen folder persists and restart avoids duplicates")
	restart.queue_free()
	await process_frame
	print("FOLDER CHOICE TESTS COMPLETE; failures: ", failures.size())
	quit(0 if failures.is_empty() else 1)
