extends SceneTree

var failures: Array = []
func check(value: bool, label: String) -> void:
	if value:
		print("PASS: ", label)
	else:
		printerr("FAIL: ", label)
		failures.append(label)

func _initialize() -> void:
	call_deferred("_run")

func wait_idle(app) -> void:
	await process_frame
	for i in range(200):
		if not app.is_importing:
			return
		await create_timer(0.05).timeout

func _run() -> void:
	if OS.get_environment("BLOODLINEBANK_TEST_MODE") != "1":
		printerr("Run only with an isolated XDG_DATA_HOME and BLOODLINEBANK_TEST_MODE=1.")
		quit(1)
		return
	root.size = Vector2i(1280, 720)
	var app = load("res://main.tscn").instantiate()
	root.add_child(app)
	var path = ProjectSettings.globalize_path("res://tests/fixtures/safe_synthetic.zip")
	var extraction_root = app.export_folder.path_join("BloodlineBank Extracted")
	app._start_import(path)
	await wait_idle(app)
	check(not app.pending_import.is_empty(), "manual ZIP opens import confirmation")
	check(not DirAccess.dir_exists_absolute(extraction_root), "ZIP is not extracted before confirmation")
	app.confirm_import.hide()
	app.pending_import.clear()
	check(app.data["creatures"].is_empty() and not DirAccess.dir_exists_absolute(extraction_root), "cancel leaves library and export folder unchanged")
	app._start_import(path)
	await wait_idle(app)
	if not app.pending_import.is_empty():
		app.confirm_import.get_ok_button().emit_signal("pressed")
		await wait_idle(app)
		await process_frame
		await wait_idle(app)
	check(app.data["creatures"].size() == 2, "confirmation saves two creature records")
	var extracted_count = 0
	var d = DirAccess.open(extraction_root)
	if d != null:
		for sub in d.get_directories():
			var subdir = DirAccess.open(extraction_root.path_join(sub))
			if subdir != null:
				extracted_count += subdir.get_files().size()
	check(extracted_count == 3, "confirmation extracts all three regular ZIP files")
	app.queue_free()
	await process_frame
	print("MANUAL ZIP TESTS COMPLETE; failures: ", failures.size())
	quit(0 if failures.is_empty() else 1)
