extends SceneTree

var failures: Array = []
func check(value: bool, label: String) -> void:
	if value:
		print("PASS: ", label)
	else:
		printerr("FAIL: ", label)
		failures.append(label)

func _initialize() -> void:
	call_deferred("_run")

func wait_until_idle(app) -> void:
	await process_frame
	for i in range(200):
		if not app.is_importing:
			return
		await create_timer(0.05).timeout

func _run() -> void:
	if OS.get_environment("BLOODLINEBANK_TEST_MODE") != "1":
		printerr("Run only with BLOODLINEBANK_TEST_MODE=1 and an isolated XDG_DATA_HOME.")
		quit(1)
		return
	root.size = Vector2i(1280, 720)
	var folder = ProjectSettings.globalize_path("user://Exported Dino")
	DirAccess.make_dir_recursive_absolute(folder)
	var archive = folder.path_join("startup_test.zip")
	DirAccess.copy_absolute(ProjectSettings.globalize_path("res://tests/fixtures/safe_synthetic.zip"), archive)
	var app = load("res://main.tscn").instantiate()
	root.add_child(app)
	await wait_until_idle(app)
	check(not app.is_importing and app.data.get("creatures", []).size() == 2, "app startup scans ZIP and imports two creatures")
	check(app.scan_state.get("archives", {}).has(archive), "startup saves archive scan state")
	check(FileAccess.file_exists(archive), "startup keeps original ZIP")
	app.data["goals"]["existing"] = {"note": "keep this goal"}
	check(app.storage.save_data(app.data).get("ok", false), "existing goal is saved")
	app._start_scan(false)
	await wait_until_idle(app)
	check(app.data["creatures"].size() == 2, "Scan Now does not duplicate existing creatures")
	var changed_path = ""
	for p in app.scan_state["files"]:
		if str(p).to_lower().ends_with("female.ini"):
			changed_path = str(p)
			break
	check(not changed_path.is_empty(), "startup tracks extracted INI paths")
	if not changed_path.is_empty():
		var text = FileAccess.get_file_as_string(changed_path).replace("Health=54.400000", "Health=99.000000")
		var f = FileAccess.open(changed_path, FileAccess.WRITE)
		f.store_string(text)
		f.close()
		app._start_scan(false)
		await wait_until_idle(app)
		check(app.scan_pending.size() == 1 and app.data["creatures"].size() == 2, "changed creature waits for review")
		app._show_settings()
		check(app.selected_page == "settings", "settings page displays the scan workflow")
		app._start_import(changed_path)
		await wait_until_idle(app)
		check(not app.pending_import.is_empty(), "review opens the existing import confirmation")
		if not app.pending_import.is_empty():
			app.confirm_import.get_ok_button().emit_signal("pressed")
			var updated = false
			for creature in app.data["creatures"]:
				if creature.get("sex") == "Female" and absf(float(creature.get("stats", {}).get("health", 0)) - 99.0) < 0.001:
					updated = true
			check(updated and app.data["goals"]["existing"]["note"] == "keep this goal", "confirmed update preserves the existing goal")
			check(app.scan_pending.is_empty(), "confirmed review clears its pending entry")
	app.queue_free()
	await process_frame
	var restart = load("res://main.tscn").instantiate()
	root.add_child(restart)
	await wait_until_idle(restart)
	check(restart.data["creatures"].size() == 2 and restart.data["goals"]["existing"]["note"] == "keep this goal", "restart preserves library without duplicates")
	if not changed_path.is_empty():
		var female_id = ""
		var identity = ""
		for creature in restart.data["creatures"]:
			if creature.get("sex") == "Female":
				female_id = str(creature["local_id"])
				identity = str(creature["identity"])
		restart.selected_id = female_id
		restart._delete_selected()
		var extra_copy = folder.path_join("another_copy.ini")
		DirAccess.copy_absolute(changed_path, extra_copy)
		restart._start_scan(false)
		await wait_until_idle(restart)
		check(restart.data["creatures"].size() == 1 and restart.scan_state.get("suppressed", {}).has(identity), "deleted creature is not restored by a new duplicate file")
		restart._start_import(extra_copy)
		await wait_until_idle(restart)
		if not restart.pending_import.is_empty():
			restart.confirm_import.get_ok_button().emit_signal("pressed")
		check(restart.data["creatures"].size() == 2 and not restart.scan_state.get("suppressed", {}).has(identity), "manual import restores a previously removed creature")
	restart.queue_free()
	await process_frame
	print("STARTUP TESTS COMPLETE; failures: ", failures.size())
	quit(0 if failures.is_empty() else 1)
