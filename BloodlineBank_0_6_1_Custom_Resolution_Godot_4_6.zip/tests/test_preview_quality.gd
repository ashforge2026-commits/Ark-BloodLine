extends SceneTree

# Run with a real rendering backend, not --headless.
var failures: Array = []

func check(value: bool, label: String) -> void:
	if value:
		print("PASS: ", label)
	else:
		printerr("FAIL: ", label)
		failures.append(label)

func _initialize() -> void:
	call_deferred("_run")

func capture() -> Image:
	await process_frame
	await RenderingServer.frame_post_draw
	return root.get_texture().get_image()

func changed_pixels(a: Image, b: Image) -> int:
	var changed = 0
	for y in range(0, 512, 4):
		for x in range(0, 512, 4):
			var ca = a.get_pixel(x, y)
			var cb = b.get_pixel(x, y)
			if absf(ca.r - cb.r) + absf(ca.g - cb.g) + absf(ca.b - cb.b) > 0.01:
				changed += 1
	return changed

func _run() -> void:
	root.size = Vector2i(512, 512)
	var app = load("res://main.tscn").instantiate()
	root.add_child(app)
	app.visible = false
	var creature = app.parser.parse_export(FileAccess.get_file_as_string("res://examples/DEMO_Female_XOtter.ini"), "DEMO.ini")["creature"]
	var preview = app._preview(creature, Vector2(0, 250))
	preview.size = Vector2(512, 512)
	root.add_child(preview)
	check(preview.material.get_shader_parameter("high_quality_preview") == true, "large preview enables enhanced scaling")
	preview.material.set_shader_parameter("high_quality_preview", false)
	var baseline = await capture()
	preview.material.set_shader_parameter("high_quality_preview", true)
	var enhanced = await capture()
	check(changed_pixels(baseline, enhanced) > 500, "enlarged image uses enhanced scaling")
	var corners_unchanged = true
	for pos in [Vector2i(0, 0), Vector2i(511, 0), Vector2i(0, 511), Vector2i(511, 511)]:
		corners_unchanged = corners_unchanged and baseline.get_pixelv(pos).is_equal_approx(enhanced.get_pixelv(pos))
	check(corners_unchanged, "transparent background corners remain unchanged")
	preview.size = Vector2(256, 256)
	preview.material.set_shader_parameter("high_quality_preview", false)
	baseline = await capture()
	preview.material.set_shader_parameter("high_quality_preview", true)
	enhanced = await capture()
	check(changed_pixels(baseline, enhanced) == 0, "native-size preview keeps the existing rendering")
	preview.queue_free()
	await process_frame
	preview = app._preview(creature, Vector2(40, 40))
	preview.size = Vector2(40, 40)
	root.add_child(preview)
	check(preview.material.get_shader_parameter("high_quality_preview") == false, "table thumbnail keeps the existing rendering")
	preview.queue_free()
	await process_frame
	preview = app._preview(creature, Vector2(0, 250))
	preview.size = Vector2(512, 512)
	root.add_child(preview)
	for i in range(6):
		preview.material.set_shader_parameter("use_%s" % i, false)
	baseline = await capture()
	for i in [0, 2, 3, 4, 5]:
		preview.material.set_shader_parameter("use_%s" % i, true)
		preview.material.set_shader_parameter("region_%s" % i, Color(1.0, 0.0, 1.0))
		enhanced = await capture()
		check(changed_pixels(baseline, enhanced) > 5, "X-Otter region %s still recolors" % i)
		preview.material.set_shader_parameter("use_%s" % i, false)
	preview.queue_free()
	await process_frame
	for species in ["Yutyrannus", "Magmasaur"]:
		var other = creature.duplicate(true)
		other["species_name"] = species
		preview = app._preview(other, Vector2(0, 250))
		preview.size = Vector2(512, 512)
		root.add_child(preview)
		check(preview.texture != null and preview.material != null, species + " preview and mask load")
		baseline = await capture()
		preview.material.set_shader_parameter("high_quality_preview", false)
		enhanced = await capture()
		check(changed_pixels(baseline, enhanced) > 200, species + " enhanced preview renders")
		preview.queue_free()
		await process_frame
	app.queue_free()
	await process_frame
	print("PREVIEW QUALITY TESTS COMPLETE; failures: ", failures.size())
	quit(0 if failures.is_empty() else 1)
