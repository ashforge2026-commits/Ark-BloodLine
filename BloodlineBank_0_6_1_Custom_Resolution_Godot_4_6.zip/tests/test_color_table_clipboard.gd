extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	if DisplayServer.get_name() == "headless":
		printerr("Run this clipboard test with a display server.")
		quit(1)
		return
	var app = load("res://main.tscn").instantiate()
	root.add_child(app)
	var example = app.parser.parse_export(FileAccess.get_file_as_string("res://examples/DEMO_Female_XOtter.ini"), "DEMO.ini")["creature"]
	var records: Array = []
	for i in range(120):
		var creature = example.duplicate(true)
		creature["local_id"] = "copy-%s" % i
		creature["name"] = "Demo otter %s" % i
		creature["regions"][0] = app.palette.from_id(90 if i % 2 == 0 else 83)
		records.append(creature)
	app.data = {"version": 1, "creatures": records, "goals": {}}
	app._show_color_table()
	await process_frame
	app.color_table_inputs[0].text = "90"
	app.color_table_inputs[0].text_changed.emit("90")
	app.color_table_copy_button.pressed.emit()
	await process_frame
	var clipboard = DisplayServer.clipboard_get()
	var ok = clipboard.begins_with("Creature\tSpecies\tLevel\tSex\tRegion 0") and clipboard.count("\n") == 60
	ok = ok and clipboard.contains("Demo otter 0\tX-Otter") and not clipboard.contains("Demo otter 1\tX-Otter")
	ok = ok and clipboard.contains("90 MediumLavender") and app.color_table_copy_button.text == "Copied!"
	print("COLOR TABLE CLIPBOARD: ", "PASS" if ok else "FAIL")
	app.queue_free()
	await process_frame
	quit(0 if ok else 1)
