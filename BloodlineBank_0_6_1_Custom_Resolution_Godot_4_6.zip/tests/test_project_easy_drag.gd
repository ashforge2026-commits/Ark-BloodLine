extends SceneTree

# Run using a Godot 4.6 binary with BLOODLINEBANK_TEST_MODE=1 and
# BLOODLINEBANK_DISABLE_AUTOSCAN=1. Uses an isolated temporary data file.
const Store = preload("res://scripts/storage.gd")
const Plans = preload("res://scripts/project_plans.gd")
const Parser = preload("res://scripts/ark_parser.gd")
const Palette = preload("res://scripts/palette.gd")
const Registry = preload("res://scripts/species_registry.gd")
var failures: Array = []

func check(ok: bool, text: String) -> void:
	if ok:
		print("PASS: ", text)
	else:
		printerr("FAIL: ", text)
		failures.append(text)

func _initialize() -> void:
	call_deferred("_test")

func find_target(app: Control, list_id: String, target_name: String) -> Control:
	for target in app.project_table_rows.find_children(target_name, "", true, false):
		if str(target.get("list_id")) == list_id:
			return target
	return null

func _test() -> void:
	if OS.get_environment("BLOODLINEBANK_TEST_MODE") != "1":
		printerr("Enable BLOODLINEBANK_TEST_MODE=1, with autoscan disabled.")
		quit(1)
		return
	root.size = Vector2i(1300, 800)
	var app = load("res://main.tscn").instantiate()
	root.add_child(app)
	var temporary = "user://_bloodline_easy_drop_%s.json" % Time.get_ticks_usec()
	app.storage = Store.new(temporary)
	app.data = app.storage.empty_data()
	var parser = Parser.new(Palette.new(), Registry.new())
	var otter = parser.parse_export(FileAccess.get_file_as_string("res://examples/DEMO_Female_XOtter.ini"), "sample.ini")["creature"]
	for i in range(3):
		var creature = otter.duplicate(true)
		creature["local_id"] = "easy-drag-%s" % i
		app.data["creatures"].append(creature)
	app._show_projects()
	app.project_name_field.text = "Drop target regression"
	app._create_project()
	var project_key = app.project_id
	for i in range(3):
		app._project_add_creature("easy-drag-%s" % i)
	app.project_new_list_name.text = "First Breed"
	app._project_create_list()
	var breed_id = app.project_add_list_id
	var payload = {"type":"bloodline_project_row", "project_id": project_key, "id":"easy-drag-0"}
	var header = find_target(app, breed_id, "ProjectListToggle")
	check(header != null, "list header exists")
	if header != null:
		check(header._can_drop_data(Vector2.ZERO, payload), "wide header accepts creature drags")
		check(not header._can_drop_data(Vector2.ZERO, {"type":"invalid"}), "unrelated drag is rejected")
	var empty_zone = find_target(app, breed_id, "ProjectEmptyListDropTarget")
	check(empty_zone != null, "empty group has a large drop area")
	if empty_zone != null:
		empty_zone._drop_data(Vector2(12, 12), payload)
	check(Plans.members_in_list(app._project_current(), breed_id).size() == 1, "dropping into an empty list moves exactly one otter")
	check(Plans.members_of(app._project_current()).size() == 3, "drag never duplicates or deletes otters")
	app._project_toggle_list(breed_id)
	var header_after_collapse = find_target(app, breed_id, "ProjectListToggle")
	check(header_after_collapse != null and header_after_collapse._can_drop_data(Vector2(5,5), {"type":"bloodline_project_row", "project_id":project_key, "id":"easy-drag-1"}), "collapsed list heading accepts drop")
	if header_after_collapse != null:
		header_after_collapse._drop_data(Vector2(5, 5), {"type":"bloodline_project_row", "project_id":project_key, "id":"easy-drag-1"})
	check(Plans.members_in_list(app._project_current(), breed_id).size() == 2, "collapsed list expands and receives second otter")
	var is_open = false
	for group in Plans.lists_of(app._project_current()):
		if str(group["id"]) == breed_id:
			is_open = bool(group["open"])
	check(is_open, "successful drop automatically opens destination")
	var first_row = null
	for candidate in app.project_table_rows.find_children("ProjectRowDragArea", "", true, false):
		if str(candidate.creature_id) == "easy-drag-0":
			first_row = candidate
	check(first_row != null, "name and image have their own drag target")
	if first_row != null:
		check(first_row._can_drop_data(Vector2.ZERO, {"type":"bloodline_project_row", "project_id":project_key, "id":"easy-drag-1"}), "name area also accepts row reorder drop")
		check(not first_row._can_drop_data(Vector2.ZERO, {"type":"bloodline_project_row", "project_id":project_key, "id":"easy-drag-0"}), "row refuses dropping onto itself")
	var saved = app.storage.load_data()
	check(Plans.members_in_list(saved["projects"][project_key], breed_id).size() == 2, "new list membership persisted to file")
	app.queue_free()
	await process_frame
	for suffix in ["", ".tmp", ".backup"]:
		if FileAccess.file_exists(temporary + suffix):
			DirAccess.remove_absolute(ProjectSettings.globalize_path(temporary + suffix))
	print("EASY DRAG REGRESSION; failures: ", failures.size())
	quit(0 if failures.is_empty() else 1)
