extends SceneTree

# Integration/model regression for 0.4.1. Run isolated with
# BLOODLINEBANK_TEST_MODE=1 BLOODLINEBANK_DISABLE_AUTOSCAN=1.
const Store = preload("res://scripts/storage.gd")
const Plans = preload("res://scripts/project_plans.gd")
const Parser = preload("res://scripts/ark_parser.gd")
const Palette = preload("res://scripts/palette.gd")
const Registry = preload("res://scripts/species_registry.gd")
var failures: Array = []

func check(condition: bool, description: String) -> void:
	if condition:
		print("PASS: ", description)
	else:
		printerr("FAIL: ", description)
		failures.append(description)

func order_of(project: Dictionary) -> Array:
	var ids: Array = []
	for entry in Plans.lists_of(project):
		ids.append(str(entry["id"]))
	return ids

func find_header(app: Control, group_id: String) -> Control:
	for node in app.project_table_rows.find_children("ProjectListToggle", "", true, false):
		if str(node.get("list_id")) == group_id:
			return node
	return null

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	if OS.get_environment("BLOODLINEBANK_TEST_MODE") != "1":
		printerr("Set BLOODLINEBANK_TEST_MODE=1 for safe isolated tests")
		quit(1)
		return
	# Data-only compatibility tests. None of these should touch real user files.
	var legacy: Dictionary = {
		"members": [
			{"id": "A", "list_id": "main"},
			{"id": "B", "list_id": "first"},
			{"id": "C", "list_id": "first"}
		],
		"lists": [
			{"id": "first", "name": "First Breed", "open": false},
			{"id": "second", "name": "Second Batch", "open": true}
		],
		"notes": [{"id":"note", "text":"Test", "done":true}]
	}
	var creatures_before = Plans.members_of(legacy).duplicate(true)
	check(order_of(legacy) == ["main", "first", "second"], "old projects default to Main List first")
	check(Plans.move_list_to(legacy, "first", "main"), "dragging First Breed above Main List changes order")
	check(order_of(legacy) == ["first", "main", "second"], "First Breed is first")
	check(not Plans.move_list_to(legacy, "first", "main"), "same-position drop makes no change")
	check(Plans.move_list_to(legacy, "first", "second", true), "dropping lower half places list after target")
	check(order_of(legacy) == ["main", "second", "first"], "list moved last")
	check(Plans.move_list_by(legacy, "main", 1), "Main List itself can move down")
	check(order_of(legacy) == ["second", "main", "first"], "Main List is not fixed at top")
	check(not Plans.move_list_by(legacy, "second", -1), "up button disabled at top")
	check(not Plans.move_list_to(legacy, "unknown", "main"), "invalid source never changes order")
	check(not Plans.move_list_to(legacy, "main", "main"), "self-drop rejected")
	check(Plans.members_of(legacy) == creatures_before, "group moves do not modify creature memberships/order")
	check(Plans.notes_of(legacy)[0]["done"], "notes stay untouched")
	check(not bool(Plans.lists_of(legacy)[2]["open"]), "collapsed state follows the moved list")
	# Bad order data must not hide or duplicate lists.
	legacy["list_order"] = ["second", "second", "missing", "main"]
	check(order_of(legacy) == ["second", "main", "first"], "stale/duplicate saved order IDs handled")
	check(Plans.add_list(legacy, "third", "Third Breed"), "new list can be added")
	check(order_of(legacy) == ["second", "main", "first", "third"], "new list appears last")
	check(Plans.remove_list(legacy, "second"), "named list can be deleted")
	check(order_of(legacy) == ["main", "first", "third"], "deleting list preserves remaining relative order")
	check(Plans.members_of(legacy) == creatures_before, "deleting an empty list leaves members untouched")

	# UI/data persistence tests with a real transient project (NOT a real library).
	root.size = Vector2i(1400, 850)
	var app = load("res://main.tscn").instantiate()
	root.add_child(app)
	var tempfile = "user://_bloodline_list_order_041_%s.json" % Time.get_ticks_usec()
	app.storage = Store.new(tempfile)
	app.data = app.storage.empty_data()
	var parser = Parser.new(Palette.new(), Registry.new())
	var otter = parser.parse_export(FileAccess.get_file_as_string("res://examples/DEMO_Female_XOtter.ini"), "sample.ini")["creature"]
	for i in range(3):
		var creature = otter.duplicate(true)
		creature["local_id"] = "reorder-test-%s" % i
		app.data["creatures"].append(creature)
	app._show_projects()
	app.project_name_field.text = "List order regression"
	app._create_project()
	var key = app.project_id
	for i in range(3):
		app._project_add_creature("reorder-test-%s" % i)
	app.project_new_list_name.text = "First Breed"
	app._project_create_list()
	var first = app.project_add_list_id
	app.project_new_list_name.text = "Second Batch"
	app._project_create_list()
	var second = app.project_add_list_id
	app._project_move_to_list("reorder-test-0", first)
	app._project_move_to_list("reorder-test-1", first)
	var saved_members = Plans.members_of(app._project_current()).duplicate(true)
	await process_frame
	var header = find_header(app, Plans.MAIN_LIST_ID)
	var payload = {"type": "bloodline_project_list", "project_id": key, "list_id": first}
	check(header != null, "Main List exposes a draggable/drop-ready header")
	if header != null:
		check(bool(header.get("allow_list_reorder")), "header can be dragged")
		check(header._can_drop_data(Vector2(5, 5), payload), "Main List heading accepts a breeding-list drop")
		check(not header._can_drop_data(Vector2(5, 5), {"type":"bloodline_project_list", "project_id":"another", "list_id":first}), "other project list drags rejected")
		check(not header._can_drop_data(Vector2(5, 5), {"type":"bloodline_project_list", "project_id":key, "list_id":"main"}), "self-list drop rejected")
		check(header._can_drop_data(Vector2(5, 5), {"type":"bloodline_project_row", "project_id":key, "id":"reorder-test-0"}), "existing otter drop still accepted")
		header._drop_data(Vector2(8, 1), payload)
	check(order_of(app._project_current()) == [first, "main", second], "dropping header above Main List reorders saved project")
	check(Plans.members_of(app._project_current()) == saved_members, "list drop does not move any otters between lists")
	app._project_move_list_by(first, 1)
	check(order_of(app._project_current()) == ["main", first, second], "list down arrow works")
	app._project_move_list_by(Plans.MAIN_LIST_ID, 1)
	check(order_of(app._project_current()) == [first, "main", second], "Main List down arrow works")
	# Drop a whole list onto the NAME/PICTURE of a creature in a different
	# section. This avoids the need to scroll up to that section's header.
	var main_row = null
	for node in app.project_table_rows.find_children("ProjectRowDragArea", "", true, false):
		if str(node.get("list_id")) == "main":
			main_row = node
			break
	check(main_row != null, "creature picture/name can receive a whole-list drag")
	if main_row != null:
		check(main_row._can_drop_data(Vector2.ZERO, {"type":"bloodline_project_list", "project_id":key, "list_id":second}), "different group's row accepts list drop")
		check(not main_row._can_drop_data(Vector2.ZERO, {"type":"bloodline_project_list", "project_id":key, "list_id":"main"}), "same group's row rejects list drop")
		main_row._drop_data(Vector2(5, 10), {"type":"bloodline_project_list", "project_id":key, "list_id":second})
	check(order_of(app._project_current()) == [first, second, "main"], "drop onto a main-list otter moves Second Batch above Main List")
	var disk = app.storage.load_data()
	check(order_of(disk["projects"][key]) == [first, second, "main"], "list order survives disk save/reload")
	check(Plans.members_of(disk["projects"][key]) == saved_members, "saved membership still unchanged")
	app._project_toggle_list(first)
	check(order_of(app._project_current()) == [first, second, "main"], "collapse/expand does not reorder lists")
	await process_frame
	app.queue_free()
	await process_frame
	for suffix in ["", ".tmp", ".backup"]:
		if FileAccess.file_exists(tempfile + suffix):
			DirAccess.remove_absolute(ProjectSettings.globalize_path(tempfile + suffix))
	print("LIST ORDER TEST COMPLETE; failures: ", failures.size())
	quit(0 if failures.is_empty() else 1)
