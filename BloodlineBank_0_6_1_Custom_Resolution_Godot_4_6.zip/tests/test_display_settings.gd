extends SceneTree

const Display = preload("res://scripts/display_settings.gd")
var failures: Array[String] = []

func _initialize() -> void:
	call_deferred("_run")

func check(ok: bool, message: String) -> void:
	if ok:
		print("PASS: ", message)
	else:
		failures.append(message)
		printerr("FAIL: ", message)

func _run() -> void:
	if OS.get_environment("BLOODLINEBANK_TEST_MODE") != "1":
		printerr("Use isolated user data and BLOODLINEBANK_TEST_MODE=1.")
		quit(1)
		return
	root.size = Vector2i(960, 640)
	var app = load("res://main.tscn").instantiate()
	root.add_child(app)
	app._show_settings()
	await process_frame
	var tabs = app.middle.get_node("SettingsTabs") as TabContainer
	check(tabs.get_tab_count() == 3 and tabs.get_tab_title(0) == "Appearance" and tabs.get_tab_title(1) == "Display" and tabs.get_tab_title(2) == "Files", "settings exposes the three requested tabs")
	tabs.current_tab = 1
	var picker = tabs.find_child("DisplayWindowMode", true, false) as OptionButton
	var apply = tabs.find_child("DisplayApplyMode", true, false) as Button
	var expected = [
		Window.MODE_WINDOWED, Window.MODE_WINDOWED, Window.MODE_MAXIMIZED,
		Window.MODE_FULLSCREEN, Window.MODE_EXCLUSIVE_FULLSCREEN
	]
	check(picker.item_count == expected.size(), "Display offers all five persistent modes")
	for index in range(expected.size()):
		picker.select(index)
		apply.pressed.emit()
		check(Display.load_mode() == index, "mode persists: " + picker.get_item_text(index))
		# Native window manager behavior requires a graphical display.
		if DisplayServer.get_name() != "headless":
			await create_timer(0.25).timeout
			check(root.mode == expected[index], "native window mode: " + picker.get_item_text(index))
			if index == Display.Mode.BORDERLESS or index == Display.Mode.WINDOWED:
				check(root.borderless == (index == Display.Mode.BORDERLESS), "native borderless flag follows the choice")
	var f11 = InputEventKey.new()
	f11.keycode = KEY_F11
	f11.pressed = true
	app._input(f11)
	check(Display.load_mode() == Display.Mode.WINDOWED, "F11 restores a regular window")
	app._input(f11)
	check(Display.load_mode() == Display.Mode.FULLSCREEN, "F11 enters fullscreen from Windowed")
	picker.select(Display.Mode.BORDERLESS)
	apply.pressed.emit()
	check(tabs.current_tab == 1 and app.display_mode_status.text.contains("Borderless window"), "apply keeps Display open and shows the saved mode")
	var minimize = tabs.find_child("DisplayMinimize", true, false) as Button
	minimize.pressed.emit()
	check(Display.load_mode() == Display.Mode.BORDERLESS, "minimize leaves the startup mode saved")
	Display.apply(root, Display.Mode.BORDERLESS)
	var width = tabs.find_child("DisplayWindowWidth", true, false) as LineEdit
	var height = tabs.find_child("DisplayWindowHeight", true, false) as LineEdit
	var apply_size = tabs.find_child("DisplayApplySize", true, false) as Button
	check(width.text == "1280" and height.text == "720" and Display.load_size() == Vector2i.ZERO, "older mode-only preferences retain the default window size")
	width.text = "1400"
	height.text = "875"
	apply_size.pressed.emit()
	await process_frame
	check(Display.load_size() == Vector2i(1400, 875) and Display.load_mode() == Display.Mode.BORDERLESS, "custom resolution saves separately from window mode")
	if DisplayServer.get_name() == "headless":
		check(root.size == Vector2i(1400, 875), "borderless mode receives the custom width and height")
	width.text = "small"
	apply_size.pressed.emit()
	check(Display.load_size() == Vector2i(1400, 875) and app.window_size_status.text.begins_with("Enter a size"), "invalid dimensions do not overwrite a saved resolution")
	picker.select(Display.Mode.FULLSCREEN)
	apply.pressed.emit()
	width.text = "1200"
	height.text = "720"
	apply_size.pressed.emit()
	check(Display.load_mode() == Display.Mode.FULLSCREEN and app.window_size_status.text.contains("Applies in Windowed"), "size can be saved while fullscreen remains selected")
	app._input(f11)
	await process_frame
	check(Display.load_mode() == Display.Mode.WINDOWED and Display.load_size() == Vector2i(1200, 720), "F11 retains the saved dimensions")
	if DisplayServer.get_name() == "headless":
		check(root.size == Vector2i(1200, 720), "F11 applies the custom dimensions when returning to Windowed")
	tabs.find_child("DisplayDefaultSize", true, false).pressed.emit()
	check(Display.load_size() == Display.default_size() and width.text == "1280" and height.text == "720", "Default size restores the project dimensions")
	picker.select(Display.Mode.BORDERLESS)
	apply.pressed.emit()
	width.text = "1400"
	height.text = "875"
	apply_size.pressed.emit()
	tabs.current_tab = 0
	var accent = tabs.find_child("Appearance_accent", true, false) as ColorPickerButton
	accent.color = Color.ORANGE
	app.scan_pending = [{"path": "res://examples/DEMO_Female_XOtter.ini", "reason": "Review test"}]
	app._refresh_file_settings()
	check(tabs.current_tab == 0 and accent.color == Color.ORANGE, "scan updates preserve the open tab and unsaved colors")
	tabs.current_tab = 2
	check(tabs.find_child("ExportFolderPath", true, false).text == app.export_folder, "Files shows the current export and extraction location")
	app._show_library()
	app._show_settings()
	check(app.middle.get_node("SettingsTabs").current_tab == 2, "settings remembers the last tab during the session")
	app.queue_free()
	await process_frame

	var reopened = load("res://main.tscn").instantiate()
	root.add_child(reopened)
	check(reopened.window_mode == Display.Mode.BORDERLESS, "launch reloads the last saved window mode")
	check(reopened.custom_window_size == Vector2i(1400, 875), "launch reloads the saved width and height")
	if DisplayServer.get_name() == "headless":
		check(root.size == Vector2i(1400, 875), "launch applies the custom dimensions")
	await process_frame
	if DisplayServer.get_name() != "headless":
		check(root.mode == Window.MODE_WINDOWED and root.borderless, "launch applies the borderless state")
	reopened.queue_free()
	await process_frame
	print("DISPLAY SETTINGS TEST COMPLETE; failures: ", failures.size())
	quit(0 if failures.is_empty() else 1)
