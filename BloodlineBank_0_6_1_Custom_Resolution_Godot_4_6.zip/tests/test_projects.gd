extends SceneTree

# Run with BLOODLINEBANK_TEST_MODE=1 and BLOODLINEBANK_DISABLE_AUTOSCAN=1
# using an isolated Godot --user-data-dir.
const Store = preload("res://scripts/storage.gd")
const Plans = preload("res://scripts/project_plans.gd")
const Parser = preload("res://scripts/ark_parser.gd")
const Palette = preload("res://scripts/palette.gd")
const Registry = preload("res://scripts/species_registry.gd")
var failures: Array = []

func check(value: bool, message: String) -> void:
	if value:
		print("PASS: ", message)
	else:
		printerr("FAIL: ", message)
		failures.append(message)

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	if OS.get_environment("BLOODLINEBANK_TEST_MODE") != "1":
		printerr("Use BLOODLINEBANK_TEST_MODE=1 with isolated user data.")
		quit(1)
		return
	root.size = Vector2i(1280, 720)
	var path = "user://_bloodlinebank_projects_037_%s.json" % Time.get_ticks_usec()
	var app = load("res://main.tscn").instantiate()
	root.add_child(app)
	app.storage = Store.new(path)
	app.data = app.storage.empty_data()
	var parser = Parser.new(Palette.new(), Registry.new())
	var female = parser.parse_export(FileAccess.get_file_as_string("res://examples/DEMO_Female_XOtter.ini"), "female.ini")["creature"]
	var male = parser.parse_export(FileAccess.get_file_as_string("res://examples/DEMO_Male_XOtter.ini"), "male.ini")["creature"]
	female["local_id"] = "female-example"
	male["local_id"] = "male-example"
	app.data["creatures"] = [female, male]
	app.data["goals"] = {"original": {"note": "preserve this"}}
	app._show_color_table()
	check(app.find_child("ColorTableProjects", true, false) != null, "Color Table links to Projects")
	app._show_projects()
	check(app.project_id == "" and app.project_table_rows == null, "empty projects state")
	app.project_name_field.text = "Perfect X-Otter"
	app._create_project()
	var first_id = app.project_id
	check(first_id != "" and app.project_table_rows != null, "project creates an ordered table")
	check(app.find_child("ProjectRegion0", true, false) == null, "R0-R5 filter boxes are removed")
	app.project_picker_sex = "Female"
	check(app._project_filtered_creatures().size() == 1, "female filtering")
	app.project_picker_sex = "Male"
	check(app._project_filtered_creatures().size() == 1, "male filtering")
	app.project_picker_sex = "All"
	app._project_add_creature("female-example")
	app._project_add_creature("male-example")
	app._project_add_creature("female-example")
	check(Plans.members_of(app._project_current()).size() == 2, "duplicate protection keeps two rows")
	app._project_set_alias(app.project_id, "female-example", "Breeding Female")
	check(str(Plans.members_of(app._project_current())[0].get("alias", "")) == "Breeding Female", "project alias saved")
	check(str(app.data["creatures"][0].get("name", "")) != "Breeding Female", "original library name unchanged")
	app._project_move_creature("male-example", "female-example", false)
	check(Plans.members_of(app._project_current())[0]["id"] == "male-example", "drop before target reorders")
	app._project_move_one("male-example", 1)
	check(Plans.members_of(app._project_current())[0]["id"] == "female-example", "arrow move reorders")
	app.project_query = "Breeding Female"
	app._render_project_board()
	var alias_rows = app.project_table_rows.find_children("ProjectTableRow", "PanelContainer", false, false)
	check(alias_rows.size() == 1, "search includes project-only aliases")
	app.project_query = ""
	app._render_project_board()
	app.project_note_input.text = "Find a color 89 male"
	app._project_note_add()
	check(Plans.notes_of(app._project_current()).size() == 1, "add checklist item")
	var note_id = str(Plans.notes_of(app._project_current())[0]["id"])
	app._project_note_toggle(note_id, true)
	check(bool(Plans.notes_of(app._project_current())[0]["done"]), "checklist done state persists")
	var display = app.find_child("ProjectNoteText", true, false)
	check(display != null and display.text.contains("[s]"), "completed tasks render real strikethrough")
	app._project_note_edit(note_id, "Find two color 89 males")
	check(str(Plans.notes_of(app._project_current())[0]["text"]) == "Find two color 89 males", "note can be edited")
	app._project_toggle_notes()
	check(not bool(app._project_current().get("notes_open", true)), "checklist collapse saved")
	app._project_toggle_notes()
	check(bool(app._project_current().get("notes_open", false)), "checklist expand saved")
	app._project_toggle_picker()
	check(not bool(app._project_current().get("picker_open", true)), "add-creatures panel collapse saved")
	app._project_toggle_picker()
	check(bool(app._project_current().get("picker_open", false)), "add-creatures panel expand saved")
	var picker = app.find_child("ProjectPickerScroll", true, false) as ScrollContainer
	var expand = app.find_child("ProjectPickerExpand", true, false) as Button
	await process_frame
	await process_frame
	var height_before = picker.size.y
	var before_expand = app.data.duplicate(true)
	expand.pressed.emit()
	await process_frame
	await process_frame
	check(picker.size.y > height_before and app.data == before_expand, "expanding the picker adds vertical room without changing project data")
	expand.pressed.emit()
	var sex = app.find_child("ProjectPickerSex", true, false) as OptionButton
	var name_filter = app.find_child("ProjectPickerName", true, false) as LineEdit
	var level = app.find_child("ProjectPickerLevel", true, false) as LineEdit
	sex.select(1)
	sex.item_selected.emit(1)
	level.text = str(int(female["level"]))
	level.text_changed.emit(level.text)
	name_filter.text = str(female["name"]).to_upper()
	name_filter.text_changed.emit(name_filter.text)
	check(app._project_filtered_creatures().map(func(c): return c["local_id"]) == ["female-example"], "picker combines name, sex and exact level")
	level.text_changed.emit(str(int(female["level"]) + 1))
	check(app._project_filtered_creatures().is_empty() and app.project_sex_filter == "All", "picker level is exact and filters are independent of the board")
	app.project_name_field.text = "Color 89 shortlist"
	app._rename_project()
	check(str(app._project_current().get("name", "")) == "Color 89 shortlist", "project can be renamed")
	app.project_name_field.text = "Second project"
	app._create_project()
	check(app.data["projects"].size() == 2 and Plans.members_of(app._project_current()).is_empty(), "projects are independent")
	app.project_id = first_id
	app._show_projects()
	check(Plans.members_of(app._project_current()).size() == 2 and Plans.notes_of(app._project_current()).size() == 1, "switch project restores rows and notes")
	var persisted = app.storage.load_data()
	check(persisted["projects"].size() == 2, "projects survive disk save/load")
	check(Plans.members_of(persisted["projects"][first_id])[0]["id"] == "female-example", "row order survives restart")
	check(bool(Plans.notes_of(persisted["projects"][first_id])[0]["done"]), "checked note survives restart")
	check(persisted["goals"].has("original") and persisted["creatures"].size() == 2, "library and goals kept intact")
	app._project_note_delete(note_id)
	check(Plans.notes_of(app._project_current()).is_empty(), "notes can be deleted")
	app._project_remove_creature("male-example")
	check(Plans.members_of(app._project_current()).size() == 1 and app.data["creatures"].size() == 2, "project removal never deletes an otter")
	# 0.3.6 board membership with x/y coordinates remains readable in row format.
	var legacy = {"name": "Old board", "members": [{"id": "female-example", "x": 300, "y": 200}]}
	check(Plans.member_index(legacy, "female-example") == 0, "0.3.6 saved board rows remain loadable")
	check(Plans.rename_member(legacy, "female-example", "Old friend"), "legacy member accepts new alias without a migration pass")
	app.pending_project_delete_id = first_id
	app._delete_project_confirmed()
	check(app.data["projects"].size() == 1 and app.data["creatures"].size() == 2, "project deletion only affects the selected project")
	app.queue_free()
	await process_frame
	for suffix in ["", ".tmp", ".backup"]:
		if FileAccess.file_exists(path + suffix):
			DirAccess.remove_absolute(ProjectSettings.globalize_path(path + suffix))
	print("PROJECT TABLE TESTS COMPLETE; failures: ", failures.size())
	quit(0 if failures.is_empty() else 1)
