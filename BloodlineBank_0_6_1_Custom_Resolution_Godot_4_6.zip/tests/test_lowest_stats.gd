extends SceneTree

# Run only in test mode; this file makes no persistent changes.
const Tracker = preload("res://scripts/lowest_stats.gd")
const Parser = preload("res://scripts/ark_parser.gd")
const Palette = preload("res://scripts/palette.gd")
const Registry = preload("res://scripts/species_registry.gd")
const Store = preload("res://scripts/storage.gd")
var failures: Array = []

func check(ok: bool, description: String) -> void:
	if ok:
		print("PASS: ", description)
	else:
		printerr("FAIL: ", description)
		failures.append(description)

func make_otter(template: Dictionary, id: String, points: Dictionary, stats: Dictionary) -> Dictionary:
	var out = template.duplicate(true)
	out["local_id"] = id
	out["name"] = "Otter " + id
	out["wild_points"] = points
	out["stats"] = stats
	out["level"] = 13
	return out

func row_for(analysis: Dictionary, key: String) -> Dictionary:
	for entry in analysis["rows"]:
		if str(entry["stat"]["key"]) == key:
			return entry
	return {}

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	if OS.get_environment("BLOODLINEBANK_TEST_MODE") != "1":
		printerr("Requires BLOODLINEBANK_TEST_MODE=1")
		quit(1)
		return
	var parser = Parser.new(Palette.new(), Registry.new())
	var example = parser.parse_export(FileAccess.get_file_as_string("res://examples/DEMO_Male_XOtter.ini"))
	check(example.get("ok", false), "fixture can be parsed")
	if not example.get("ok", false):
		quit(1)
		return
	var template: Dictionary = example["creature"]
	var low = make_otter(template, "low", {"0": 0, "1": 1, "3": 4, "4": 0, "7": 2, "8": 5, "9": 0}, {"health": 50.0, "stamina": 250.0, "melee damage": 1.2})
	var tie = make_otter(template, "tie", {"0": 0, "1": 0, "3": 3, "4": 3, "7": 2, "8": 6}, {"health": 70.0, "stamina": 140.0, "melee damage": 1.1})
	var missing = make_otter(template, "missing", {}, {"health": 25.0, "melee damage": 1.0})
	var high = make_otter(template, "high", {"0": 12, "1": 11, "3": 9, "4": 8, "7": 7, "8": 6}, {"health": 200.0, "stamina": 380.0, "melee damage": 1.5})
	var other = make_otter(template, "other", {"0": 0, "1": 0}, {"health": 5.0})
	other["species_key"] = "other-variant"
	var creatures: Array = [low, tie, missing, high, other]
	var key = str(template["species_key"])
	var points = Tracker.analyze(creatures, key, "points")
	check(points["total"] == 4 and points["rows"].size() == 7, "selects just one variant and seven level-contributing stats")
	var hp = row_for(points, "health")
	check(hp["lowest"] == 0.0 and hp["known"] == 3 and hp["unknown"] == 1, "missing wild HP points are unknown, never zero")
	check(hp["carriers"].size() == 2, "both Otters with tied low HP are retained")
	check(row_for(points, "stamina")["lowest"] == 0.0 and row_for(points, "stamina")["carriers"][0]["creature"]["local_id"] == "tie", "different Otter can have lowest stamina")
	check(row_for(points, "movement speed")["known"] == 1, "movement speed has its own index 9 and no invented defaults")
	check(not row_for(points, "torpidity").has("stat"), "torpidity not treated as an independent breeding point")
	check(Tracker.number_for(missing, {"index": "0", "key": "health"}, "points") == null, "missing points do not borrow the displayed 25 HP")
	check(Tracker.number_for(low, {"index": "0", "key": "health"}, "points") == 0.0, "explicit zero points count")
	check(Tracker.has_points(creatures, key) and not Tracker.has_points(creatures, "no-data"), "auto selection depends on actual exported fields")
	check(Tracker.format_value(0.0, {"key": "health"}, "points") == "0 pts", "zero points shown clearly")
	var displayed = Tracker.analyze(creatures, key, "values")
	var displayed_hp = row_for(displayed, "health")
	check(displayed["rows"].size() == 8 and displayed_hp["lowest"] == 25.0, "displayed values separate and include torpor reference")
	check(displayed_hp["carriers"][0]["creature"]["local_id"] == "missing", "displayed minimum may differ from breeding-point minimum")
	check(Tracker.format_value(1.2, {"key": "melee damage"}, "values") == "120.0%", "percentage formatting matches Creature Library")
	var broken = make_otter(template, "bad", {"0": -2, "1": "zero", "3": 1.5}, {"health": -1.0, "stamina": "not available"})
	check(Tracker.number_for(broken, {"index": "0", "key": "health"}, "points") == null, "negative points ignored")
	check(Tracker.number_for(broken, {"index": "1", "key": "stamina"}, "points") == null, "nonnumeric points ignored")
	check(Tracker.number_for(broken, {"index": "3", "key": "oxygen"}, "points") == null, "fractional points ignored")
	check(Tracker.number_for(broken, {"index": "0", "key": "health"}, "values") == null, "invalid displayed value ignored")
	# Integration: new tab, filters, state retention, and opening a selected carrier.
	var app = load("res://main.tscn").instantiate()
	root.add_child(app)
	app.storage = Store.new("user://__lowest_stats_test_045_missing.json")
	app.data = {"version": 1, "creatures": creatures, "goals": {}, "projects": {}, "partner_used_females": {"low": true}}
	app._show_lowest_stats()
	await process_frame
	check(app.selected_page == "low_stats" and app.nav_buttons.has("low_stats"), "Lowest Stats sidebar tab opens")
	check(app.lowest_species_key == key and app.lowest_mode == "points", "X-Otter and breeding-point mode automatically selected")
	check(app.lowest_rows_host.find_children("LowestStatRow_*", "Button", true, false).size() == 7, "seven clickable wild-point rows")
	app._lowest_select_stat("stamina")
	check(app.lowest_selected_stat == "stamina", "clicking a stat updates ranked carriers")
	app._lowest_mode_changed(1)
	await process_frame
	check(app.lowest_mode == "values" and app.lowest_rows_host.find_children("LowestStatRow_*", "Button", true, false).size() == 8, "switching to displayed values gives eight rows")
	check(app.data["partner_used_females"].get("low") == true and app.data["creatures"].size() == 5, "Partner Finder X marks and records remain untouched")
	app._show_partner_finder()
	app._show_lowest_stats()
	check(app.lowest_mode == "values" and app.lowest_selected_stat == "stamina", "switching tabs keeps tracker selection")
	app.queue_free()
	await process_frame
	print("LOWEST STATS TEST COMPLETE; failures: ", failures.size())
	quit(0 if failures.is_empty() else 1)
