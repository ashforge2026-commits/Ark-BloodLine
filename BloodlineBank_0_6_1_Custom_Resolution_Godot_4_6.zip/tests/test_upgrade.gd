extends SceneTree

const Palette = preload("res://scripts/palette.gd")
const Registry = preload("res://scripts/species_registry.gd")
const Parser = preload("res://scripts/ark_parser.gd")
const Importer = preload("res://scripts/import_service.gd")
const Store = preload("res://scripts/storage.gd")
const PROBE_PATH = "user://_bloodlinebank_upgrade_probe.json"

func _initialize() -> void:
	var mode = OS.get_cmdline_user_args()[0] if OS.get_cmdline_user_args().size() > 0 else ""
	var store = Store.new(PROBE_PATH)
	if mode == "write":
		var importer = Importer.new(Parser.new(Palette.new(), Registry.new()))
		var plan = importer.prepare("res://examples/DEMO_XOtters.zip", [])
		var library = importer.apply_plan(plan, store.empty_data())
		library["goals"]["upgrade-check"] = {"color_id": 6, "note": "existing collection and goal"}
		var result = store.save_data(library)
		print("WRITE PATH: ", ProjectSettings.globalize_path(PROBE_PATH))
		print("UPGRADE WRITE: ", result)
		quit(0 if result.get("ok", false) else 1)
	elif mode == "read":
		var library = store.load_data()
		var ok = library.get("creatures", []).size() == 2 and library.get("goals", {}).get("upgrade-check", {}).get("note") == "existing collection and goal"
		print("READ PATH: ", ProjectSettings.globalize_path(PROBE_PATH))
		print("UPGRADE READ: ", "PASS" if ok else "FAIL")
		quit(0 if ok else 1)
	else:
		printerr("Expected write or read argument.")
		quit(1)
