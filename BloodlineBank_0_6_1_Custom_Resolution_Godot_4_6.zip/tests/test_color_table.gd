extends SceneTree

const Palette = preload("res://scripts/palette.gd")
const Registry = preload("res://scripts/species_registry.gd")
const Parser = preload("res://scripts/ark_parser.gd")
const Table = preload("res://scripts/color_table.gd")
var failures: Array = []

func check(value: bool, label: String) -> void:
	if value:
		print("PASS: ", label)
	else:
		printerr("FAIL: ", label)
		failures.append(label)

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	root.size = Vector2i(1280, 720)
	var palette = Palette.new()
	var parser = Parser.new(palette, Registry.new())
	var example = parser.parse_export(FileAccess.get_file_as_string("res://examples/DEMO_Female_XOtter.ini"), "DEMO.ini")["creature"]
	var key = str(example["species_key"])
	var a = example.duplicate(true)
	a["name"] = "Amber"
	a["local_id"] = "a"
	a["regions"][0] = palette.from_id(90)
	a["regions"][1] = palette.from_id(90) # X-Otter region 1 is unused.
	a["regions"][2] = palette.from_id(83)
	var b = example.duplicate(true)
	b["name"] = "Zed"
	b["local_id"] = "b"
	b["regions"][0] = palette.from_id(83)
	b["regions"][2] = palette.from_id(83)
	var unknown = example.duplicate(true)
	unknown["local_id"] = "u"
	unknown["name"] = "Unknown"
	unknown["regions"][0] = {"state": "ambiguous", "id": null, "candidates": [90, 83], "raw": []}
	var other = a.duplicate(true)
	other["local_id"] = "other"
	other["species_key"] = "other-species"
	other["species_name"] = "Other Species"
	var all = [a, b, unknown, other]
	var blank = ["", "", "", "", "", ""]
	var both = ["90", "", "83", "", "", ""]
	check(Table.filtered(all, key, "", both, -1, false, palette).size() == 1, "two region filters combine and exclude other species")
	check(Table.region_matches(a, 0, "90", palette), "exact color ID matches the selected region")
	check(not Table.region_matches(a, 0, "9", palette), "numeric color IDs are exact, not partial")
	check(Table.region_matches(a, 0, "lavender", palette), "partial color name matches without regard to case")
	check(not Table.region_matches(a, 1, "90", palette), "unused region does not match even if its raw color is set")
	check(not Table.region_matches(unknown, 0, "90", palette) and Table.region_matches(unknown, 0, "?", palette), "ambiguous color is unknown rather than a confirmed ID")
	check(Table.filtered(all, "", "other species", blank, -1, false, palette).size() == 1, "species name is searchable")
	var ascending = Table.filtered([unknown, a, b], "", "", blank, 0, false, palette)
	var descending = Table.filtered([unknown, a, b], "", "", blank, 0, true, palette)
	check(str(ascending[0]["local_id"]) == "b" and str(ascending[1]["local_id"]) == "a" and str(ascending[2]["local_id"]) == "u", "ascending sort orders IDs and keeps unknown last")
	check(str(descending[0]["local_id"]) == "a" and str(descending[1]["local_id"]) == "b" and str(descending[2]["local_id"]) == "u", "descending sort keeps unknown last")
	var formula = a.duplicate(true)
	formula["name"] = "=1+2\tnew line\nnext"
	var copy = Table.copied_rows([formula], palette)
	check(copy.contains("\n'=1+2 new line next\t") and copy.contains("90 MediumLavender") and copy.contains("\t—\t"), "copied spreadsheet text contains IDs and names and protects formula-like names")
	var creatures: Array = []
	for i in range(120):
		var one = example.duplicate(true)
		one["name"] = "Otter %03d" % i
		one["local_id"] = "otter-%03d" % i
		one["regions"][0] = palette.from_id(90 if i % 2 == 0 else 83)
		one["regions"][2] = palette.from_id(83)
		creatures.append(one)
	var app = load("res://main.tscn").instantiate()
	root.add_child(app)
	app.data = {"version": 1, "creatures": creatures, "goals": {}}
	app.selected_id = "otter-000"
	app._show_color_table()
	var no_picture_row = app._color_table_row(other)
	check(no_picture_row.get_child(0).get_child(0).get_child(0) is Label and no_picture_row.get_child(0).get_child(0).get_child(0).text == "?", "species without bundled images show a clear placeholder")
	no_picture_row.free()
	await process_frame
	await process_frame
	check(app.selected_page == "color_table" and app.color_table_rows.get_child_count() == 50 and not app.color_table_next.disabled, "color table opens with paginated creatures")
	check(app.color_table_rows.get_child(0).tooltip_text.contains("R1: unused") and app.color_table_rows.get_child(0).tooltip_text.contains("R2: #83"), "row tooltip explains the region colors and unused slots")
	app.color_table_next.pressed.emit()
	check(app.color_table_page == 1, "next page works")
	app.color_table_inputs[0].text = "90"
	app.color_table_inputs[0].text_changed.emit("90")
	check(app.color_table_page == 0 and app._color_table_filtered().size() == 60, "filter covers all pages and resets to the first")
	app.color_table_inputs[2].text = "83"
	app.color_table_inputs[2].text_changed.emit("83")
	check(app._color_table_filtered().size() == 60, "region 0 and region 2 can be filtered together")
	app.color_table_header_buttons[0].pressed.emit()
	check(app.color_table_sort_region == 0 and not app.color_table_descending, "region header sorts ascending")
	app.color_table_header_buttons[0].pressed.emit()
	check(app.color_table_descending, "pressing the region header again reverses the sort")
	await process_frame
	await process_frame
	var first_row = app.color_table_rows.get_child(0).get_child(0)
	var aligned = true
	for i in range(6):
		var column = first_row.get_child(i + 3).get_global_rect()
		var heading = app.color_table_header_buttons[i].get_global_rect()
		aligned = aligned and absf((column.position.x + column.size.x * 0.5) - (heading.position.x + heading.size.x * 0.5)) < 2.0
	check(aligned, "region sort headings stay aligned with the colored cells")
	app.color_table_rows.get_child(0).pressed.emit()
	var selected = app._selected()
	check(selected != null and app.selected_page == "color_table" and str(selected["local_id"]).begins_with("otter-"), "selecting a table row updates the shared creature details")
	app._show_bingo()
	check(str(app.bingo_keys[app.bingo_species.selected]) == key, "Color Bingo opens for the selected creature's species")
	app._show_color_table()
	check(app.color_table_inputs[0].text == "90" and app.color_table_inputs[2].text == "83", "region filters remain when switching tabs")
	for dimensions in [Vector2i(1680, 1050), Vector2i(1280, 720), Vector2i(1024, 768), Vector2i(960, 640)]:
		root.size = dimensions
		await process_frame
		await process_frame
		var view = app.get_viewport_rect().size
		var fit = app.details.get_global_rect().end.x <= view.x + 1 and app.middle.get_global_rect().end.x <= view.x + 1
		for input in app.color_table_inputs:
			fit = fit and input.get_global_rect().end.x <= app.middle.get_global_rect().end.x + 1
		check(fit, "table filters and details fit at %sx%s" % [dimensions.x, dimensions.y])
	check(app.color_table_scroll.get_h_scroll_bar().visible, "smaller window can scroll horizontally to all regions")
	app.color_table_scroll.scroll_horizontal = 150
	await process_frame
	check(app.color_table_header_scroll.scroll_horizontal == app.color_table_scroll.scroll_horizontal, "region headings follow horizontal scrolling")
	app.color_table_toggle_details.pressed.emit()
	await process_frame
	await process_frame
	check(not app.details.visible and not app.color_table_scroll.get_h_scroll_bar().visible, "hiding details gives all six region columns room at the smaller size")
	app.color_table_toggle_details.pressed.emit()
	await process_frame
	check(app.details.visible and app.color_table_inputs[0].text == "90", "showing details again keeps the filters")
	app._clear_color_table_filters()
	check(app._color_table_filtered().size() == 120 and app.color_table_page == 0, "clear restores all creatures")
	app.queue_free()
	await process_frame
	print("COLOR TABLE TESTS COMPLETE; failures: ", failures.size())
	quit(0 if failures.is_empty() else 1)
