extends SceneTree

const Settings = preload("res://scripts/scan_settings.gd")
const Scan = preload("res://scripts/folder_scan.gd")
const Parser = preload("res://scripts/ark_parser.gd")
const Palette = preload("res://scripts/palette.gd")
const Registry = preload("res://scripts/species_registry.gd")
const Importer = preload("res://scripts/import_service.gd")

var failures: Array[String] = []

func check(value: bool, name: String) -> void:
	if value:
		print("PASS: ", name)
	else:
		printerr("FAIL: ", name)
		failures.append(name)

func delete_tree(path: String) -> void:
	var dir = DirAccess.open(path)
	if dir == null:
		return
	for name in dir.get_files():
		DirAccess.remove_absolute(path.path_join(name))
	for name in dir.get_directories():
		delete_tree(path.path_join(name))
	DirAccess.remove_absolute(path)

func _initialize() -> void:
	if OS.get_environment("BLOODLINEBANK_TEST_MODE") != "1":
		printerr("Run this test with isolated user-data and BLOODLINEBANK_TEST_MODE=1")
		quit(1)
		return
	var root_dir = ProjectSettings.globalize_path("user://_asa_sync_test_%s" % Time.get_ticks_usec())
	var export = root_dir.path_join("ARK Survival Ascended/ShooterGame/Saved/DinoExports")
	var nested = export.path_join("steam_user_123")
	DirAccess.make_dir_recursive_absolute(nested)
	var settings = Settings.new()
	var from_detection = settings.detect_ark_folder([root_dir.path_join("missing"), export])
	check(from_detection == export, "detect existing DinoExports directory")
	check(settings.is_ark_exports_folder(export), "identify read-only ARK root")
	check(settings.is_ark_exports_folder(nested), "identify nested read-only ARK path")
	check(not settings.is_ark_exports_folder(root_dir), "ordinary export folder still supports ZIP import")

	var source = "res://tests/fixtures/ASA_XOtter_DinoExport_synthetic.ini"
	var filename = nested.path_join("DinoExport_9012345_7123456.ini")
	check(DirAccess.copy_absolute(ProjectSettings.globalize_path(source), filename) == OK, "prepare sample ASA export")
	var parser = Parser.new(Palette.new(), Registry.new())
	var parsed = parser.parse_export(FileAccess.get_file_as_string(filename), filename)
	check(parsed.get("ok", false), "parse original-format ASA export")
	if parsed.get("ok", false):
		var creature: Dictionary = parsed["creature"]
		check(creature.get("species_name") == "X-Otter", "resolve X-Otter blueprint")
		check(creature.get("sex") == "Female" and creature.get("level") == 118, "read sex and level")
		var ids: Array = []
		for region in creature["regions"]:
			ids.append(region.get("id"))
		check(ids == [86, 80, 3, 49, 69, 89], "match six uploaded color sample IDs")

	# A ZIP in the game folder must never create extracted files there.
	var zip_file = export.path_join("safe.zip")
	check(DirAccess.copy_absolute(ProjectSettings.globalize_path("res://tests/fixtures/safe_synthetic.zip"), zip_file) == OK, "prepare harmless ZIP")
	var scanner = Scan.new(parser)
	var initial = {"creatures": [], "goals": {}, "projects": {"preserve_me": {"name": "Breeding board"}}}
	var first = scanner.scan(export, initial["creatures"], {"files": {}, "archives": {}}, false)
	check(first.get("ok", false) and first["counts"]["new"] == 1, "automatically discover one new otter in nested folder")
	check(first["counts"]["extracted"] == 0 and first["counts"]["archives"] == 0, "never extract ZIP into game folder")
	check(DirAccess.get_directories_at(export).size() == 1, "game directory structure remains unchanged")
	var importer = Importer.new(parser)
	var merged = importer.apply_plan({"records": first["records"]}, initial)
	check(merged["creatures"].size() == 1 and merged["projects"].has("preserve_me"), "import retains projects and original creature identity")
	var repeat = scanner.scan(export, merged["creatures"], first["state"], false)
	check(repeat["counts"]["new"] == 0, "rescan never duplicates an imported otter")
	var reexport = FileAccess.get_file_as_string(filename).replace("Health=248.390015", "Health=270.0")
	var writer = FileAccess.open(filename, FileAccess.WRITE)
	writer.store_string(reexport)
	writer.close()
	var modified = scanner.scan(export, merged["creatures"], repeat["state"], false)
	check(modified["counts"]["review"] == 1 and modified["counts"]["new"] == 0, "changed otter waits for review instead of overwriting")
	delete_tree(root_dir)
	print("ASA AUTO SYNC TEST COMPLETE; failures: ", failures.size())
	quit(0 if failures.is_empty() else 1)
