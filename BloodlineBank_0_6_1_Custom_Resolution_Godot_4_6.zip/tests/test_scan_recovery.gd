extends SceneTree
const Store=preload("res://scripts/storage.gd")
const Parser=preload("res://scripts/ark_parser.gd")
const Palette=preload("res://scripts/palette.gd")
const Registry=preload("res://scripts/species_registry.gd")
func _initialize() -> void:
 call_deferred("_run")
func _run() -> void:
 if OS.get_environment("BLOODLINEBANK_TEST_MODE") != "1":
  printerr("Use an isolated XDG_DATA_HOME and BLOODLINEBANK_TEST_MODE=1.")
  quit(1)
  return
 root.size=Vector2i(1280,720)
 var data=Store.new().empty_data()
 var c=Parser.new(Palette.new(),Registry.new()).parse_export(FileAccess.get_file_as_string("res://examples/DEMO_Female_XOtter.ini"))["creature"]
 c["local_id"]="recover-test"
 data["creatures"].append(c)
 data["goals"]["important"]={"note":"preserve"}
 var saved=Store.new().save_data(data)
 var bad=FileAccess.open("user://scan_manifest.json",FileAccess.WRITE)
 bad.store_string("intentionally broken")
 bad.close()
 var app=load("res://main.tscn").instantiate()
 root.add_child(app)
 await process_frame
 await process_frame
 var intact=app.data["creatures"].size()==1 and app.data["goals"]["important"]["note"]=="preserve" and not app.scan_block_reason.is_empty() and FileAccess.get_file_as_string("user://scan_manifest.json")=="intentionally broken" and not app.is_importing
 app.queue_free()
 await process_frame
 var malformed=FileAccess.open("user://scan_manifest.json",FileAccess.WRITE)
 malformed.store_string('{"files":{"unexpected":"invalid"},"archives":{}}')
 malformed.close()
 var app2=load("res://main.tscn").instantiate()
 root.add_child(app2)
 await process_frame
 await process_frame
 var structured=not app2.scan_block_reason.is_empty() and app2.data["creatures"].size()==1 and not app2.is_importing
 print("SCAN RECOVERY TEST: ","PASS" if intact and structured and saved.get("ok",false) else "FAIL")
 app2.queue_free()
 await process_frame
 quit(0 if intact and structured and saved.get("ok",false) else 1)
