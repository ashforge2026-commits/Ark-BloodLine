extends SceneTree

# BLOODLINEBANK_TEST_MODE=1 godot --headless --path . --script res://tests/test_color_lab.gd
const Lab = preload("res://scripts/color_lab.gd")
const Palette = preload("res://scripts/palette.gd")
const Registry = preload("res://scripts/species_registry.gd")
const Parser = preload("res://scripts/ark_parser.gd")
const Partner = preload("res://scripts/partner_finder.gd")
const Bingo = preload("res://scripts/bingo.gd")
const Lowest = preload("res://scripts/lowest_stats.gd")
const Preview = preload("res://scripts/creature_preview.gd")
const DesignStore = preload("res://scripts/color_design_store.gd")
const Storage = preload("res://scripts/storage.gd")
const CONCAVENATOR = "/Game/ASA/Dinos/Concavenator/Concavenator_Character_BP.Concavenator_Character_BP"
const ENIGMASAUR = "/Game/ASA/Dinos/Chameleon/Chameleon_Character_BP.Chameleon_Character_BP"
var failures: Array = []

func check(ok: bool, label: String) -> void:
	if ok:
		print("PASS: ", label)
	else:
		printerr("FAIL: ", label)
		failures.append(label)

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	if OS.get_environment("BLOODLINEBANK_TEST_MODE") != "1":
		printerr("Requires BLOODLINEBANK_TEST_MODE=1")
		quit(1)
		return
	var palette = Palette.new()
	var data = {"creatures": []}
	var registry = Registry.new()
	var lab = Lab.new(palette, data, registry.lab_subject("X-Otter"))
	check(palette.entries.size() == 227, "227 defined ASA palette colors load")
	check(lab.ids.size() == 6 and lab.ids[1] == -1, "unused region remains unused")
	check(not lab.set_color(1, 233), "cannot assign unused slot 1")
	check(not lab.set_color(0, 9999), "reject undefined palette IDs")
	check(lab.set_color(0, 210), "manual selection changes a visible region")
	check(lab.undo() and lab.ids[0] == 233, "manual selection supports undo")
	lab.toggle_lock(0)
	var fixed = int(lab.ids[0])
	lab.randomize_colors("all")
	check(int(lab.ids[0]) == fixed, "randomizer preserves locked slot")
	lab.toggle_lock(0)
	lab.randomize_colors("solid")
	var solid = int(lab.ids[0])
	var same = true
	for slot in lab.active_regions:
		if int(lab.ids[slot]) != solid:
			same = false
	check(same, "solid mode uses one color across visible slots")
	var before = lab.ids.duplicate()
	lab.locked = [true, true, true, true, true, true]
	var locked_result = lab.randomize_colors("all")
	check(not locked_result["changed"] and lab.ids == before, "all-locked design remains unchanged")
	lab.locked = [false, true, false, false, false, false]
	check(not lab.apply_colors([9999, -1, 233, 233, 233, 233]), "invalid preset never partially applies")
	var parser = Parser.new(palette, Registry.new())
	var sample = parser.parse_export(FileAccess.get_file_as_string("res://examples/DEMO_Male_XOtter.ini"))
	check(sample.get("ok", false), "sample X-Otter parsed")
	if sample.get("ok", false):
		var creature: Dictionary = sample["creature"]
		data["creatures"].append(creature)
		var owned = lab.owned_ids(0)
		check(not owned.is_empty(), "owned color mode reads confirmed real regions")
		for slot in lab.active_regions:
			lab.locked[slot] = false
		lab.randomize_colors("owned")
		var valid = true
		for slot in lab.active_regions:
			var choices = lab.owned_ids(slot)
			if not choices.is_empty() and not choices.has(int(lab.ids[slot])):
				valid = false
		check(valid, "owned mode only selects matching slot color IDs")
		check(lab.from_creature(creature) or not lab.ids.is_empty(), "can receive source otter colors for testing")
	check(lab.preview_creature()["regions"].size() == 6, "preview uses exact six-region shader schema")
	await check_new_creatures(palette, registry)
	print("COLOR LAB TEST COMPLETE; failures: ", failures.size())
	quit(0 if failures.is_empty() else 1)


func make_creature(parser, blueprint: String, female: bool, id: int, ids: Array) -> Dictionary:
	var ini = "[Dino Data]\nDinoID1=%s\nDinoID2=101\nDinoClass=%s_C\nbIsFemale=%s\nbNeutered=False\nTamedName=Test %s\nCharacterLevel=60\n[Colorization]\n" % [id, blueprint, female, id]
	for slot in range(6):
		ini += "ColorSetIndices[%s]=%s\n" % [slot, ids[slot]]
	ini += "[Max Character Status Values]\nHealth=120\n"
	var parsed = parser.parse_export(ini, "synthetic.ini")
	var creature: Dictionary = parsed.get("creature", {})
	creature["local_id"] = str(id)
	return creature

func check_new_creatures(palette, registry) -> void:
	var parser = Parser.new(palette, registry)
	var conca = make_creature(parser, CONCAVENATOR, false, 1, [75, 79, 75, 79, 79, 6])
	var enigma = make_creature(parser, ENIGMASAUR, false, 2, [75, 79, 75, 79, 79, 6])
	var conca_female = make_creature(parser, CONCAVENATOR, true, 3, [6, 75, 6, 75, 75, 75])
	var enigma_female = make_creature(parser, ENIGMASAUR, true, 4, [6, 75, 6, 75, 75, 75])
	var data = {"version": 1, "creatures": [conca, enigma, conca_female, enigma_female], "goals": {}, "projects": {}}
	check(conca.get("species_name") == "Concavenator" and Partner.active_slots(conca) == [0, 2, 5], "Concavenator export uses active R0, R2 and R5")
	check(enigma.get("species_name") == "Enigmasaur" and Partner.active_slots(enigma) == [0, 1, 2, 3, 4, 5], "Enigmasaur blueprint resolves with six active regions")
	for specimen in [conca, enigma]:
		var name: String = specimen["species_name"]
		var scope: String = specimen["species_key"]
		var slots: Array = Partner.active_slots(specimen)
		var ranked = Partner.rank(data["creatures"], specimen, 75)
		check(ranked["results"].size() == 1 and ranked["total"] == slots.size(), name + " finds same-species mates using the correct region count")
		var bingo = Bingo.build(data["creatures"], scope, specimen["region_names"], palette)
		check(int(bingo[74]["total"]) == slots.size(), name + " uses the right denominator in Bingo")
		check(int(Lowest.analyze(data["creatures"], scope, "values")["total"]) == 2, name + " stats use the same species scope")
		var lab = Lab.new(palette, data, registry.lab_subject(name))
		check(lab.from_creature(specimen), name + " copies confirmed colors into the lab")
		check(lab.owned_ids(0) == [6, 75], name + " owned colors stay within its species")
		lab.toggle_lock(0)
		lab.randomize_colors("all")
		check(lab.ids[0] == 75 and (name != "Concavenator" or [lab.ids[1], lab.ids[3], lab.ids[4]] == [-1, -1, -1]), name + " randomizer respects locks and unused slots")
		lab.set_color(5, 6)
		var creature = lab.preview_creature()
		var preview = Preview.build(creature, registry.images_for(creature), Vector2(256, 256), true)
		check(preview.texture != null and preview.material != null, name + " loads a matching texture, mask and shader")
		if preview.material != null:
			check(preview.material.get_shader_parameter("use_1") == (name == "Enigmasaur") and preview.material.get_shader_parameter("use_5") == true, name + " enables only the active shader regions")
			var picked_color = Palette.display_color(palette.get_color(6)["rgba"])
			check(preview.material.get_shader_parameter("region_5").is_equal_approx(picked_color), name + " applies the picked ARK color to the shader")
		preview.free()
	var old_enigma = enigma.duplicate(true)
	old_enigma["verified_species"] = false
	old_enigma["species_name"] = "Chameleon"
	old_enigma["region_names"] = null
	old_enigma["warnings"] = [Registry.UNVERIFIED_WARNING, "other warning"]
	registry.recognize_saved_enigmasaurs([old_enigma])
	check(old_enigma["species_name"] == "Enigmasaur" and old_enigma["region_names"].size() == 6 and old_enigma["local_id"] == "2" and old_enigma["warnings"] == ["other warning"], "already-imported Enigmasaur gains metadata and retains identity")
	var store = Storage.new("user://test_creature_designs.json")
	data["color_lab_presets"] = [{"key": "old", "name": "Legacy otter", "ids": [6, -1, 6, 6, 6, 6]}]
	var app = load("res://main.tscn").instantiate()
	root.size = Vector2i(1280, 720)
	root.add_child(app)
	app.data = data
	app.storage = store
	check(store.save_data(data)["ok"], "saved a fixture with a legacy design")
	var library_before = FileAccess.get_file_as_string(store.data_path)
	app.selected_id = "1"
	app._show_library()
	app.search_mode_picker.select(1)
	app.search_mode_picker.item_selected.emit(1)
	check(not app._matches_query(conca, "79") and app._matches_query(enigma, "79"), "library search ignores colors reported only in unused regions")
	app.search_field.text = "79"
	app.library_species.select(1)
	app.library_species.item_selected.emit(1)
	check(app.library_species.get_item_text(1) == "Concavenator" and app._filtered().is_empty(), "library species combines with color ID")
	app.library_species.select(2)
	app.library_species.item_selected.emit(2)
	check(app._filtered().size() == 1 and app._filtered()[0]["species_name"] == "Enigmasaur", "changing species updates filtered library")
	app.library_species.select(0)
	app.library_species.item_selected.emit(0)
	var inactive = app._creature_region_chip(conca, 1)
	check(inactive.get_child(0).text == "—", "the Concavenator library displays a dash for inactive regions")
	inactive.free()
	var action = app.details.find_child("LibraryTryCreatureColors", true, false) as Button
	check(action != null, "Concavenator library card offers Try these colors")
	if action != null:
		action.pressed.emit()
	var lab_ui = app.color_lab
	check(lab_ui != null and lab_ui.model.species_name == "Concavenator" and lab_ui.model.ids[5] == 6, "opening Concavenator from the library loads that creature's colors")
	if lab_ui != null:
		lab_ui.name_input.text = "Demo Concavenator"
		var save_button = lab_ui.find_child("ColorLabSaveDesign", true, false) as Button
		save_button.pressed.emit()
		var designs = DesignStore.new()
		var reloaded = designs.load_data()
		check(reloaded["designs"].size() == 2 and reloaded["designs"].back()["species"] == "Concavenator", "legacy and new designs persist in the dedicated save")
		check(FileAccess.get_file_as_string(store.data_path) == library_before, "saving designs preserves the original library file")
		var strip = lab_ui.find_child("ColorLabRegionStrip", true, false) as HBoxContainer
		check(strip != null and strip.get_child_count() == 6, "all six regions share one row")
		for i in range(6):
			var color = strip.get_child(i).find_child("ColorLabRegionColor", true, false) as Button
			check(color.disabled == (i in [1, 3, 4]) and (not color.disabled or color.text == "×"), "Concavenator slot R%s has the correct availability" % i)
		check(save_button.custom_minimum_size.x >= 100 and designs.data_path == "user://color_lab_designs.json", "save button has room for text and uses app data")
		var species = lab_ui.find_child("ColorLabSpecies", true, false) as OptionButton
		species.item_selected.emit(2)
		var pose = lab_ui.find_child("ColorLabPose", true, false) as OptionButton
		check(pose != null and pose.item_count == 2, "Enigmasaur offers two poses in Color Lab")
		if pose != null:
			lab_ui.model.set_color(1, 79)
			var before = lab_ui.find_child("ColorLabCreaturePreview", true, false).texture.resource_path
			pose.item_selected.emit(1)
			var alternate = lab_ui.find_child("ColorLabCreaturePreview", true, false) as TextureRect
			check(alternate.texture.resource_path != before and alternate.material.get_shader_parameter("region_mask").resource_path.ends_with("enigmasaur_pose_2_mask.png") and lab_ui.model.ids[1] == 79, "switching pose loads its paired mask and retains the design")
		var picker = lab_ui.find_child("ColorLabSpecies", true, false) as OptionButton
		picker.item_selected.emit(0)
		check(lab_ui.model.species_name == "X-Otter" and count_button_text(lab_ui, "Legacy otter") == 1 and count_button_text(lab_ui, "Demo Concavenator") == 0, "saved designs are species-scoped and legacy otter presets still appear")
		picker = lab_ui.find_child("ColorLabSpecies", true, false) as OptionButton
		picker.item_selected.emit(1)
		check(lab_ui.model.ids[5] == 6 and count_button_text(lab_ui, "Demo Concavenator") == 1, "switching between species preserves separate drafts")
	app.queue_free()
	await process_frame
	var mobile = load("res://mobile_main.tscn").instantiate()
	root.add_child(mobile)
	mobile.library = data
	mobile._show_page("lab", enigma)
	check(mobile.lab_widget.model.species_name == "Enigmasaur" and mobile.lab_widget.model.ids[1] == 79, "mobile Lab accepts Enigmasaur from the library")
	mobile._show_page("bingo")
	var mobile_species = mobile.page_host.find_child("MobileColorSpecies", true, false) as OptionButton
	check(mobile_species != null and mobile_species.item_count == 2, "mobile Bingo lists both imported species")
	if mobile_species != null:
		mobile_species.item_selected.emit(1)
		check(mobile.bingo_spec_key == enigma["species_key"] and int(mobile.bingo_rows[74]["total"]) == 6, "mobile Bingo switches to Enigmasaur coverage")
	for page in ["partner", "table"]:
		mobile._show_page(page)
		mobile_species = mobile.page_host.find_child("MobileColorSpecies", true, false) as OptionButton
		check(mobile_species != null and mobile_species.item_count == 2, "mobile " + page + " lists both imported species")
	mobile.queue_free()
	await process_frame
	for suffix in ["", ".backup", ".tmp"]:
		for base in [store.data_path, DesignStore.PATH]:
			var path = base + suffix
			if FileAccess.file_exists(path):
				DirAccess.remove_absolute(ProjectSettings.globalize_path(path))

func count_button_text(parent: Node, value: String) -> int:
	return parent.find_children("*", "Button", true, false).filter(func(button): return button.text == value).size()
