extends SceneTree

# Run with BLOODLINEBANK_TEST_MODE=1 and BLOODLINEBANK_DISABLE_AUTOSCAN=1.
# Read-only test: never saves or imports into the user's local library.
const Finder = preload("res://scripts/partner_finder.gd")
const Palette = preload("res://scripts/palette.gd")
const Registry = preload("res://scripts/species_registry.gd")
const Parser = preload("res://scripts/ark_parser.gd")
const Store = preload("res://scripts/storage.gd")
const MARKS_TEST_PATH = "user://_partner_finder_marks_044_test.json"
var failures: Array = []
var palette = Palette.new()

func check(value: bool, label: String) -> void:
	if value:
		print("PASS: ", label)
	else:
		printerr("FAIL: ", label)
		failures.append(label)

func creature(template: Dictionary, local_id: String, sex: String, ids: Array) -> Dictionary:
	var result: Dictionary = template.duplicate(true)
	result["local_id"] = local_id
	result["sex"] = sex
	result["name"] = "Otter " + local_id
	result["neutered"] = "False"
	for i in range(6):
		result["regions"][i] = palette.from_id(int(ids[i]))
	return result

func type_key(key: Key, unicode: int = 0) -> void:
	var event = InputEventKey.new()
	event.keycode = key
	event.unicode = unicode
	event.pressed = true
	root.push_input(event)

func check_male_search(app, template: Dictionary, items: Array) -> void:
	var four = creature(template, "four", "Male", [79, 2, 79, 79, 79, 75])
	var two = creature(template, "two", "Male", [79, 79, 79, 75, 75, 75])
	var one = creature(template, "one", "Male", [79, 79, 75, 75, 75, 75])
	one["regions"][2] = {"state": "ambiguous", "id": null, "candidates": [75, 79], "raw": []}
	var tied = creature(template, "tied", "Male", [75, 2, 79, 79, 75, 75])
	tied["name"] = two["name"]
	var level_only = creature(template, "level_only", "Male", [75, 79, 75, 75, 75, 75])
	level_only["level"] = 79
	var neutered_male = creature(template, "sterile", "Male", [79, 79, 79, 79, 79, 79])
	neutered_male["neutered"] = "True"
	var candidates = [one, two, level_only, four, neutered_male, tied]
	var matches = Finder.male_matches(candidates, " #79 ")
	check(matches.map(func(entry): return entry["creature"]["local_id"]) == ["four", "tied", "two", "one"], "exact color search ranks 4, 2, 2, 1 with deterministic ties")
	check(matches.map(func(entry): return entry["count"]) == [4, 2, 2, 1], "counts exclude unused and ambiguous slots, same-level males and sterile males")
	check(Finder.male_matches(candidates, "level 79").size() == 1 and Finder.male_matches(candidates, "Otter one").size() == 1, "level prefix and name search remain available")
	var partner = creature(template, "partner_79", "Female", [75, 2, 75, 79, 75, 75])
	app.data["creatures"] = items + candidates + [partner]
	var search = app.middle.find_child("PartnerMaleSearch", true, false) as LineEdit
	search.grab_focus()
	type_key(KEY_7, 55)
	type_key(KEY_9, 57)
	await process_frame
	var rows: Array = app.partner_male_picker.get_children().filter(func(node): return node is Button)
	check(search.text == "79" and app.partner_search_query == "79", "typing in the real search field updates results live")
	check(rows.size() == 4, "UI displays only four matching males")
	if rows.size() == 4:
		check(rows[0].tooltip_text.ends_with("4× color #79") and rows[2].tooltip_text.ends_with("2× color #79") and rows[3].tooltip_text.ends_with("1× color #79"), "Matching column always scores the queried color, including single matches")
		var swatches = rows[2].get_child(0).get_child(3)
		check(swatches.get_child(0).get_theme_stylebox("panel").border_width_left == 2 and swatches.get_child(1).get_theme_stylebox("panel").border_width_left == 1, "active match outlined while unused region stays unmarked")
	type_key(KEY_BACKSPACE)
	type_key(KEY_BACKSPACE)
	await process_frame
	check(app.partner_search_query.is_empty() and app.partner_male_picker.get_children().filter(func(node): return node is Button).size() == 6, "clearing restores the general male list")
	type_key(KEY_9, 57)
	type_key(KEY_9, 57)
	type_key(KEY_9, 57)
	await process_frame
	check(app.partner_male_picker.get_child(-1) is Label and app.partner_male_picker.get_child(-1).text.contains("#999"), "no matches shows the requested color ID")
	type_key(KEY_BACKSPACE)
	type_key(KEY_BACKSPACE)
	type_key(KEY_BACKSPACE)
	type_key(KEY_7, 55)
	type_key(KEY_9, 57)
	await process_frame
	rows = app.partner_male_picker.get_children().filter(func(node): return node is Button)
	if rows.size() == 4:
		rows[2].pressed.emit()
		check(app.partner_male_id == "two" and app.partner_target_color == 79 and app.partner_color_select.get_selected_id() == 79, "clicking a male carries color 79 into the target dropdown even when 75 occurs more often")
		var find_button = app.middle.find_child("PartnerFindButton", true, false) as Button
		find_button.pressed.emit()
		check(app.partner_results.size() == 1 and app.partner_female_id == "partner_79", "Find Females uses the carried-over color")
		app._partner_toggle_picker()
		check(app.middle.find_child("PartnerMaleSearch", true, false).text == "79", "reopening the picker retains the filter")
	var other = one.duplicate(true)
	other["local_id"] = "other_species"
	other["name"] = "Orange"
	other["species_key"] = "other"
	other["species_name"] = "Another creature"
	other["level"] = 79
	app.data["creatures"].append(other)
	app._show_partner_finder()
	var species = app.middle.find_child("PartnerSpecies", true, false) as OptionButton
	var modes = app.middle.find_child("PartnerSearchMode", true, false) as OptionButton
	species.select(1)
	species.item_selected.emit(1)
	modes = app.middle.find_child("PartnerSearchMode", true, false) as OptionButton
	modes.select(2)
	modes.item_selected.emit(2)
	rows = app.partner_male_picker.get_children().filter(func(node): return node is Button)
	check(app.partner_species_key == "other" and not app._partner_find_creature("two").is_empty() and app.partner_male_id.is_empty(), "changing species clears a male from the previous species")
	check(rows.size() == 1 and app._partner_query_color() == -1, "exact-level mode uses the species filter and ignores color ID")
	modes.select(1)
	modes.item_selected.emit(1)
	app._partner_search_males("ORANGE")
	rows = app.partner_male_picker.get_children().filter(func(node): return node is Button)
	check(rows.size() == 1, "name mode matches the male's name within the chosen species")
	app.data["creatures"] = items
	app.partner_species_key = ""
	app.partner_search_mode = Finder.SearchMode.COLOR_ID
	app.partner_search_query = ""
	app.partner_picker_visible = true
	app._show_partner_finder()

func check_clear_marks(app) -> void:
	# The previously marked medium appears in the results. Overlap does not.
	app.data["partner_used_females"]["overlap"] = true
	check(app.storage.save_data(app.data).get("ok", false), "saved a mark outside the current results")
	var before: Dictionary = app.data.duplicate(true)
	before["partner_used_females"] = {}
	var clear_button: Button = app.middle.find_child("PartnerClearMarks", true, false)
	check(not clear_button.disabled, "clear-all is enabled when a female is marked")
	var rows: Array = app.partner_results_box.find_children("PartnerUsedToggle", "Button", true, false)
	var revision: int = app.database_revision
	app.data["read_only"] = true
	clear_button.pressed.emit()
	check(app.database_revision == revision and rows[1].text == "✕" and not clear_button.disabled, "failed bulk save retains the visible X and enabled button")
	check(app._partner_is_used("overlap") and Store.new(MARKS_TEST_PATH).load_data()["partner_used_females"].size() == 2, "failed bulk save retains all saved marks")
	app.data.erase("read_only")
	app.message_dialog.hide()
	clear_button.pressed.emit()
	check(app.data == before and app.database_revision == revision + 1, "bulk clear changes only mark metadata in one save")
	check(rows.all(func(button): return button.text == "□") and app.partner_results_summary.text == "3 matches", "bulk clear refreshes every visible X and count")
	check(app.partner_female_id == "medium" and app.partner_male_id == "male" and app.partner_target_color == 75 and app.partner_results.size() == 3, "bulk clear keeps selections, color, and results")
	check(clear_button.disabled and Store.new(MARKS_TEST_PATH).load_data()["partner_used_females"].is_empty(), "all marks stay cleared on reload and button disables")
	clear_button.pressed.emit()
	check(app.database_revision == revision + 1, "repeat clear with empty marks performs no save")
	rows[1].pressed.emit()
	check(app._partner_is_used("medium"), "individual marks still work after reset")
	app._partner_color_changed(app.partner_color_select.selected)
	check(not app.partner_searched and not clear_button.disabled, "clear-all is available before a female search when marks exist")
	clear_button.pressed.emit()
	check(app.data["partner_used_females"].is_empty() and clear_button.disabled, "clearing while results are hidden resets saved marks")

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	if OS.get_environment("BLOODLINEBANK_TEST_MODE") != "1":
		printerr("Set BLOODLINEBANK_TEST_MODE=1 for isolated tests.")
		quit(1)
		return
	var parser = Parser.new(palette, Registry.new())
	var parsed = parser.parse_export(FileAccess.get_file_as_string("res://examples/DEMO_Male_XOtter.ini"), "DEMO_Male_XOtter.ini")
	check(bool(parsed.get("ok", false)), "demo male parses")
	if not parsed.get("ok", false):
		quit(1)
		return
	var template: Dictionary = parsed["creature"]
	var male = creature(template, "male", "Male", [75, 75, 75, 83, 75, 69])
	var best = creature(template, "best", "Female", [75, 75, 12, 75, 10, 75])
	var medium = creature(template, "medium", "Female", [12, 75, 75, 75, 10, 69])
	var overlap = creature(template, "overlap", "Female", [75, 75, 75, 13, 75, 69])
	var only_new = creature(template, "only_new", "Female", [12, 75, 31, 75, 22, 17])
	var ambiguous = creature(template, "ambiguous", "Female", [75, 75, 31, 75, 13, 69])
	ambiguous["regions"][3] = {"state": "ambiguous", "id": null, "candidates": [75, 83], "raw": []}
	var no_target = creature(template, "no_target", "Female", [2, 75, 2, 2, 2, 2])
	var neutered = creature(template, "neutered", "Female", [75, 75, 75, 75, 75, 75])
	neutered["neutered"] = "True"
	var other_species = creature(template, "other_species", "Female", [75, 75, 75, 75, 75, 75])
	other_species["species_key"] = "different-species"
	var unknown_sex = creature(template, "unknown_sex", "Unknown", [75, 75, 75, 75, 75, 75])
	var items: Array = [overlap, no_target, male, neutered, medium, best, only_new, other_species, unknown_sex, ambiguous]
	check(Finder.active_slots(male) == [0, 2, 3, 4, 5], "X-Otter inactive region 1 is ignored")
	check(Finder.colors_for_male(male)[0] == {"id": 75, "count": 3}, "three actual male regions select color 75; unused R1 ignored")
	check(Finder.confirmed_color(ambiguous, 3) == null, "ambiguous color candidate never counts as confirmed")
	check(Finder.male_options(items).size() == 1, "only eligible, known-color males are selectable")
	var ranked = Finder.rank(items, male, 75)
	check(ranked["valid"] and ranked["total"] == 5 and ranked["male_count"] == 3, "male coverage is 3/5")
	var results: Array = ranked["results"]
	check(results.size() == 3, "only females with at least one newly covered target region are shown")
	if results.size() == 3:
		check(results[0]["creature"]["local_id"] == "best", "best female ranked first")
		check(results[0]["new_slots"] == [3, 5] and results[0]["combined_count"] == 5, "best contributes both missing slots for complete 5/5 coverage")
		check(results[0]["both_slots"] == [0], "overlap can coexist with new coverage")
		check(results[1]["creature"]["local_id"] == "medium" and results[1]["new_count"] == 1 and results[1]["both_count"] == 1, "mixed female with one new and one overlapping region remains eligible")
		check(results[2]["creature"]["local_id"] == "only_new" and results[2]["new_slots"] == [3], "female with only a missing target region is eligible")
		var all_improve = true
		var excluded_overlap_only = true
		for entry in results:
			if int(entry["new_count"]) <= 0:
				all_improve = false
			if str(entry["creature"].get("local_id", "")) in ["overlap", "ambiguous"]:
				excluded_overlap_only = false
		check(all_improve, "no +0 new females appear in ranking")
		check(excluded_overlap_only, "overlap-only and unconfirmed-missing females excluded")
	check(not Finder.rank(items, male, 999)["valid"], "unowned target color cannot be searched")
	check(not Finder.rank(items, neutered, 75)["valid"], "female cannot be selected as male")
	# UI route and result cards. UI is re-created without touching Library data.
	root.size = Vector2i(1280, 720)
	var app = load("res://main.tscn").instantiate()
	root.add_child(app)
	app.storage = Store.new(MARKS_TEST_PATH)
	app.data = {"version": 1, "creatures": items, "goals": {}, "projects": {}}
	app._show_partner_finder()
	await process_frame
	check(app.selected_page == "partner" and app.nav_buttons.has("partner"), "Partner Finder is a dedicated sidebar tab")
	check(app.partner_male_picker != null and app.partner_results_box != null, "male picker and female table exist")
	check(app.middle.find_child("PartnerClearMarks", true, false).disabled, "clear-all starts disabled for a library without marks")
	await check_male_search(app, template, items)
	app._partner_select_male("male")
	check(app.partner_male_id == "male" and app.partner_target_color == 75, "selecting male pins it and selects his strongest repeated color")
	app._partner_run_search()
	await process_frame
	check(app.partner_searched and app.partner_results.size() == 3, "Find Females button uses the live library")
	check(app.partner_female_id == "best", "highest ranked female opens in comparison panel")
	check(app.partner_results_box.find_children("PartnerFemaleRow", "", true, false).size() == 3, "female results are rendered as clickable creature rows")
	var mark_buttons = app.partner_results_box.find_children("PartnerUsedToggle", "Button", true, false)
	check(mark_buttons.size() == 3, "each female row has its own X toggle")
	if mark_buttons.size() == 3:
		var best_mark: Button = mark_buttons[0]
		check(best_mark.text == "□", "unmarked female displays empty box")
		best_mark.pressed.emit()
		check(best_mark.text == "✕" and app._partner_is_used("best"), "click X marks the selected female")
		check(app.partner_female_id == "best" and app.partner_results.size() == 3, "X click keeps selection and all ranked females visible")
		var on_disk = Store.new(MARKS_TEST_PATH).load_data()
		check(on_disk.get("partner_used_females", {}).get("best", false) == true, "X mark survives save and load")
		check(on_disk.get("creatures", []).size() == items.size() and on_disk.get("projects", {}).is_empty(), "mark save preserves creatures and projects")
		# A second click clears only that mark and persists the reset.
		best_mark.pressed.emit()
		check(best_mark.text == "□" and not app._partner_is_used("best"), "click X again removes the mark")
		check(not Store.new(MARKS_TEST_PATH).load_data().get("partner_used_females", {}).has("best"), "unmarking survives save and load")
		# Mark a different female, then rebuild the UI and load saved data.
		mark_buttons[1].pressed.emit()
		check(app._partner_is_used("medium") and not app._partner_is_used("best"), "only chosen female is marked")
		check(app.partner_female_id == "best", "marking a different female does not accidentally select her")
		app.data = Store.new(MARKS_TEST_PATH).load_data()
		app._show_partner_finder()
		check(app._partner_is_used("medium") and app.partner_results.size() == 3, "marked otter persists across tab rebuild and simulated restart")
		check(app.partner_results_box.find_children("PartnerUsedToggle", "Button", true, false)[1].text == "✕", "restored X appears in its correct female row")
		# Save failures must not pretend to mark a female.
		app.data["read_only"] = true
		var current_button: Button = app.partner_results_box.find_children("PartnerUsedToggle", "Button", true, false)[0]
		current_button.pressed.emit()
		check(current_button.text == "□" and not app._partner_is_used("best"), "read-only recovery blocks mark and leaves UI unchanged")
		app.data.erase("read_only")
	app._partner_select_female("medium")
	check(app.partner_female_id == "medium", "selecting another female updates comparison")
	app._show_library()
	app._show_partner_finder()
	check(app.partner_male_id == "male" and app.partner_female_id == "medium", "switching tabs preserves selected partner IDs")
	check_clear_marks(app)
	check(items[0]["local_id"] == "overlap" and items[0]["regions"][0]["id"] == 75, "partner search does not mutate the library")
	app.queue_free()
	await process_frame
	for suffix in ["", ".backup", ".tmp"]:
		var test_path = ProjectSettings.globalize_path(MARKS_TEST_PATH + suffix)
		if FileAccess.file_exists(MARKS_TEST_PATH + suffix):
			DirAccess.remove_absolute(test_path)
	print("PARTNER FINDER TESTS COMPLETE; failures: ", failures.size())
	quit(0 if failures.is_empty() else 1)
