extends SceneTree

const Store = preload("res://scripts/storage.gd")
var failures: Array = []

func check(condition: bool, label: String) -> void:
	if condition:
		print("PASS: ", label)
	else:
		failures.append(label)
		printerr("FAIL: ", label)

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	root.size = Vector2i(1280, 720)
	await process_frame
	var test_path = "user://_bloodlinebank_ui_test_%s.json" % Time.get_ticks_usec()
	var app = load("res://main.tscn").instantiate()
	root.add_child(app)
	app.storage = Store.new(test_path)
	app.data = app.storage.empty_data()
	app._show_library()
	check(app.selected_page == "library" and is_instance_valid(app.list_box), "library screen initializes")
	app._start_import("res://examples/DEMO_XOtters.zip")
	for i in range(100):
		if not app.is_importing:
			break
		await create_timer(0.05).timeout
	check(not app.is_importing and not app.pending_import.is_empty(), "background import reaches review")
	if not app.pending_import.is_empty():
		check(app.pending_import["counts"]["new"] == 2, "review identifies two new creatures")
		app.confirm_import.get_ok_button().emit_signal("pressed")
		check(app.data["creatures"].size() == 2, "confirmation saves two creatures")
		check(app.list_box.get_child_count() == 2, "library renders two creature rows")
		var symbol = app.list_box.get_child(0).get_child(0).get_child(2)
		check(symbol.get_script() != null and symbol.get_script().resource_path.ends_with("sex_symbol.gd"), "sex symbol is a drawn vector control")
		check(app._selected() != null, "import selects a creature")
		await process_frame
		await process_frame
		var viewport_size = app.get_viewport_rect().size
		print("LAYOUT: viewport ", viewport_size, ", details ", app.details.get_global_rect())
		check(app.details.get_global_rect().end.x <= viewport_size.x + 1, "details panel fits the initial viewport width")
		var preview = app._preview(app._selected())
		check(preview.texture != null and preview.material != null, "preview loads image and region shader")
		preview.free()
		check(app.search_mode_picker.item_count == 3 and app.search_mode_picker.get_item_text(0) == "Name" and not app.search_region.visible, "the library starts with the three-mode name picker")
		app.search_field.text = "FEMALE X-OTTER"
		check(app._filtered().size() == 1 and app._filtered()[0]["sex"] == "Female", "name search matches a creature's name case-insensitively")
		app.search_field.text = "200"
		check(app._filtered().is_empty(), "numeric levels do not appear in name mode")
		app.search_mode_picker.select(2)
		app.search_mode_picker.item_selected.emit(2)
		check(app._filtered().size() == 2 and not app.search_region.visible, "changing to Level applies the existing query")
		app.search_field.text = "20"
		check(app._filtered().is_empty(), "level search needs an exact level")
		app.search_mode_picker.select(1)
		app.search_mode_picker.item_selected.emit(1)
		app.search_field.text = "#6"
		check(app.search_region.visible and app._filtered().size() == 2, "color ID mode shows the region filter and accepts #")
		app.search_region.select(6)
		check(app._filtered().is_empty(), "region filter narrows color ID search")
		app.search_region.select(0)
		var ambiguous = app.data["creatures"][0].duplicate(true)
		for i in range(6):
			ambiguous["regions"][i] = app.palette.from_id(6)
		ambiguous["regions"][0] = {"state": "ambiguous", "id": null, "candidates": [79, 80], "raw": []}
		ambiguous["regions"][1] = app.palette.from_id(79)
		check(not app._matches_query(ambiguous, "79"), "color ID search excludes ambiguous and unused slots")
		app.search_field.text = "999"
		app.search_field.text_changed.emit("999")
		check(app.list_box.get_child(0).text == "No creatures match this search.", "zero results show a search-specific message")
		app.search_field.text = ""
		app.search_field.text_changed.emit("")
		check(app.list_box.get_child_count() == 2, "clearing the query restores the creature rows")
		app._show_goals()
		check(app.goal_keys.size() == 1, "goal species list comes from collection")
		app.goal_color.text = "6"
		app.goal_stat_1.select(1)
		app.goal_stat_2.select(4)
		app.goal_note.text = "Find region 5"
		app._refresh_goal()
		await process_frame
		check(app.goal_header_info.text.contains("ID 6"), "goal resolves selected color")
		check(app.goal_result.get_child_count() >= 5, "goal coverage and focus stat results render")
		app._save_goal()
		var reloaded = app.storage.load_data()
		var key = str(app.goal_keys[0])
		check(reloaded["goals"].has(key) and reloaded["goals"][key]["note"] == "Find region 5", "goal and note persist through save")
		check(int(reloaded["goals"][key]["stat_1"]) == 1 and int(reloaded["goals"][key]["stat_2"]) == 4, "two selected stats persist")
		var prior_library = app.data.duplicate(true)
		var swatch_before = app._creature_region_chip(app._selected(), 0)
		var chip_color = swatch_before.get_theme_stylebox("panel").bg_color
		swatch_before.free()
		app._show_settings()
		var surface = app.middle.find_child("Appearance_panels", true, false) as ColorPickerButton
		var detail = app.middle.find_child("Appearance_details", true, false) as ColorPickerButton
		var accent = app.middle.find_child("Appearance_accent", true, false) as ColorPickerButton
		surface.color = Color("#532690")
		detail.color = Color("#385621")
		accent.color = Color("#ffc971")
		app.middle.find_child("AppearanceApply", true, false).pressed.emit()
		var appearance_script = preload("res://scripts/appearance.gd")
		check(app.appearance["panels"] == Color("#532690") and appearance_script.load_colors() == app.appearance, "appearance colors persist separately")
		app._show_library()
		check(app.details.get_child(0).get_theme_stylebox("panel").bg_color.h < 0.30, "detail panel redraws with its own tint")
		check(app.search_field.get_theme_stylebox("focus").border_color.is_equal_approx(Color("#ffc971")), "focus border uses the chosen accent")
		var new_chip = app._creature_region_chip(app._selected(), 0)
		check(new_chip.get_theme_stylebox("panel").bg_color == chip_color and app.data == prior_library, "appearance preserves ARK colors and library data")
		new_chip.free()
		app._show_settings()
		var theme_picker = app.middle.find_child("AppearanceThemeColor", true, false) as ColorPickerButton
		theme_picker.color = Color.BLACK
		app.middle.find_child("AppearanceApplyTheme", true, false).pressed.emit()
		var black_theme = appearance_script.load_colors()
		check(black_theme == app.appearance and black_theme["theme_color"] == Color.BLACK, "Simpler color saves the black base and generated palette")
		theme_picker = app.middle.find_child("AppearanceThemeColor", true, false) as ColorPickerButton
		check(theme_picker.color == Color.BLACK, "Simpler color remembers the chosen black")
		app._show_library()
		var background: Color = app.background_rect.color
		var sidebar: Color = app.sidebar_panel.get_theme_stylebox("panel").bg_color
		var detail_shade: Color = app.details.get_child(0).get_theme_stylebox("panel").bg_color
		var accent_shade: Color = app.search_field.get_theme_stylebox("focus").border_color
		check(background.s < 0.001 and sidebar.s < 0.001 and detail_shade.s < 0.001 and accent_shade.s < 0.001, "black uses neutral surfaces and accent")
		check(background.v < sidebar.v and sidebar.v < detail_shade.v and detail_shade.v + 0.5 < accent_shade.v, "black keeps darker and lighter shades distinct")
		var purple_theme = appearance_script.from_color(Color("#713de3"))
		var panel_shade = appearance_script.surface(Color("#0d2231"), purple_theme)
		var purple_accent = appearance_script.accent(purple_theme)
		check(is_equal_approx(panel_shade.h, purple_accent.h) and panel_shade.s > 0.4 and panel_shade.v < purple_accent.v, "a colored theme keeps its hue across accents and surfaces")
		app._show_settings()
		app.middle.find_child("AppearanceReset", true, false).pressed.emit()
		check(appearance_script.load_colors() == appearance_script.DEFAULTS, "restore defaults persists the original palette")
	app.queue_free()
	await process_frame
	for suffix in ["", ".tmp", ".backup"]:
		var path = ProjectSettings.globalize_path(test_path + suffix)
		if FileAccess.file_exists(path):
			DirAccess.remove_absolute(path)
	print("UI FLOW TESTS COMPLETE; failures: ", failures.size())
	quit(0 if failures.is_empty() else 1)
