extends SceneTree

const MobileExports = preload("res://scripts/mobile_exports.gd")
const ScanSettings = preload("res://scripts/scan_settings.gd")
const Archive = preload("res://scripts/archive_extract.gd")
const ZIP_FIXTURE = "res://tests/fixtures/safe_synthetic.zip"
var failures = 0

func _initialize() -> void:
	call_deferred("_run")

func check(value: bool, message: String) -> void:
	if value:
		print("PASS: ", message)
	else:
		failures += 1
		printerr("FAIL: ", message)

func _wait_for_zip(app) -> void:
	for i in range(100):
		if app.extraction_thread == null:
			break
		await create_timer(0.05).timeout

func _run() -> void:
	if OS.get_environment("BLOODLINEBANK_TEST_MODE") != "1":
		printerr("Use isolated user data and BLOODLINEBANK_TEST_MODE=1.")
		quit(1)
		return
	root.size = Vector2i(360, 740)
	var app = load("res://mobile_main.tscn").instantiate()
	root.add_child(app)
	await process_frame
	var chosen = ProjectSettings.globalize_path("user://phone exports")
	DirAccess.make_dir_recursive_absolute(chosen)
	var desktop = ScanSettings.new()
	desktop.save_folder("user://Desktop exports")
	check(app.extraction_folder == MobileExports.DEFAULT_FOLDER, "mobile starts with its own app-storage folder")
	app._show_page("tools")
	await process_frame
	var button = app.page_host.find_child("MobileDinoExportLocation", true, false) as Button
	check(button != null and button.get_global_rect().end.x <= root.size.x, "extraction button fits the phone layout")
	button.pressed.emit()
	check(app.folder_picker.file_mode == FileDialog.FILE_MODE_OPEN_DIR, "button opens a directory picker")
	app.folder_picker.hide()
	app.folder_picker.dir_selected.emit(chosen)
	check(MobileExports.load_folder() == chosen and app.extraction_status.text.contains(chosen), "selected folder persists and is shown")
	check(desktop.load_folder() == "user://Desktop exports", "phone folder setting leaves desktop folder unchanged")
	app.folder_picker.dir_selected.emit(chosen.path_join("missing"))
	check(app.extraction_folder == chosen, "an inaccessible folder does not replace the saved location")
	app.notice.hide()
	var uri = "content://com.android.externalstorage.documents/tree/primary%3ADocuments%2FBloodlineBank"
	check(MobileExports.describe(uri + "#BloodlineBank Extracted/Example") == "Documents/BloodlineBank/BloodlineBank Extracted/Example", "folder display decodes Android document tree names")
	var opaque_zip = "user://example_document_123"
	DirAccess.copy_absolute(ZIP_FIXTURE, opaque_zip)
	var staged = MobileExports.stage_document(opaque_zip)
	check(staged.get("path", "").get_extension() == "zip" and staged.get("name", "") == "Dino export.zip", "staging identifies ZIPs with an opaque document ID")
	if staged.has("path"):
		check(FileAccess.get_sha256(staged["path"]) == FileAccess.get_sha256(ZIP_FIXTURE), "staged ZIP keeps all source bytes")
	var zip_before = FileAccess.get_sha256(ZIP_FIXTURE)
	app.picker.file_selected.emit(ZIP_FIXTURE)
	check(app.confirm_import.dialog_text.contains(chosen) and app.confirm_import.ok_button_text == "Import & extract", "ZIP review shows the chosen destination")
	var extraction_root = chosen.path_join(Archive.EXTRACTED_DIR)
	check(not DirAccess.dir_exists_absolute(extraction_root), "ZIP waits for confirmation")
	app.confirm_import.get_cancel_button().pressed.emit()
	check(app.pending_import.is_empty() and app.library["creatures"].is_empty(), "cancel keeps the library and destination clear")
	app.picker.file_selected.emit(ZIP_FIXTURE)
	app.confirm_import.get_ok_button().pressed.emit()
	await _wait_for_zip(app)
	check(app.library["creatures"].size() == 2 and app.extraction_thread == null, "confirm saves records and completes background extraction")
	var content = DirAccess.open(extraction_root)
	var directories = content.get_directories() if content != null else PackedStringArray()
	var output = DirAccess.open(extraction_root.path_join(directories[0])) if directories.size() == 1 else null
	check(output != null and output.get_files().size() == 3, "all three archive files are saved inside the chosen folder")
	check(app.notice.title == "ZIP complete" and FileAccess.get_sha256(ZIP_FIXTURE) == zip_before, "success reports completion and leaves source ZIP intact")
	app.notice.hide()
	app.picker.file_selected.emit(ZIP_FIXTURE)
	check(app.confirm_import.ok_button_text == "Extract ZIP", "already imported ZIP remains extractable")
	app.confirm_import.get_ok_button().pressed.emit()
	await _wait_for_zip(app)
	check(app.library["creatures"].size() == 2 and app.notice.dialog_text.contains("0 files extracted. 3 already present."), "repeating the ZIP avoids duplicate output and records")
	app.queue_free()
	await process_frame

	var reopened = load("res://mobile_main.tscn").instantiate()
	root.add_child(reopened)
	check(reopened.extraction_folder == chosen, "reopening the mobile app restores the chosen folder")
	reopened.queue_free()
	await process_frame
	print("MOBILE EXPORTS TEST COMPLETE; failures: ", failures)
	quit(0 if failures == 0 else 1)
