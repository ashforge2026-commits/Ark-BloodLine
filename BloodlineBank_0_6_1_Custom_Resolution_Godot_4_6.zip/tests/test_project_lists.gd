extends SceneTree

# Run with BLOODLINEBANK_TEST_MODE=1 and BLOODLINEBANK_DISABLE_AUTOSCAN=1
# with an isolated Godot user-data-dir. No real ARK folder or library is used.
const Store = preload("res://scripts/storage.gd")
const Plans = preload("res://scripts/project_plans.gd")
const Parser = preload("res://scripts/ark_parser.gd")
const Palette = preload("res://scripts/palette.gd")
const Registry = preload("res://scripts/species_registry.gd")
var failures: Array = []

func check(ok: bool, meaning: String) -> void:
	if ok:
		print("PASS: ", meaning)
	else:
		printerr("FAIL: ", meaning)
		failures.append(meaning)

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	if OS.get_environment("BLOODLINEBANK_TEST_MODE") != "1":
		printerr("Set BLOODLINEBANK_TEST_MODE=1 for isolated project tests.")
		quit(1)
		return
	root.size = Vector2i(1280, 720)
	var app = load("res://main.tscn").instantiate()
	root.add_child(app)
	var path = "user://_bloodlinebank_project_lists_039_%s.json" % Time.get_ticks_usec()
	app.storage = Store.new(path)
	app.data = app.storage.empty_data()
	var parser = Parser.new(Palette.new(), Registry.new())
	var example = parser.parse_export(FileAccess.get_file_as_string("res://examples/DEMO_Female_XOtter.ini"), "sample.ini")["creature"]
	for i in range(5):
		var otter = example.duplicate(true)
		otter["local_id"] = "test-otter-%s" % i
		otter["sex"] = "Female" if i % 2 == 0 else "Male"
		app.data["creatures"].append(otter)
	app._show_projects()
	app.project_name_field.text = "X-Otter bloodline"
	app._create_project()
	var original_key = app.project_id
	for i in range(5):
		app._project_add_creature("test-otter-%s" % i)
	check(Plans.lists_of(app._project_current()).size() == 1, "old project starts with Main List only")
	check(Plans.member_position(app._project_current(), "test-otter-0") == 1, "initial numbering starts at 1")
	app._project_set_position(original_key, "test-otter-4", "1")
	check(Plans.member_position(app._project_current(), "test-otter-4") == 1, "typing 1 moves otter to the top")
	app._project_set_position(original_key, "test-otter-4", "5")
	check(Plans.member_position(app._project_current(), "test-otter-4") == 5, "typing 5 moves otter to fifth position")
	app._project_set_position(original_key, "test-otter-4", "bogus")
	check(Plans.member_position(app._project_current(), "test-otter-4") == 5, "invalid position cannot reorder")
	app.project_new_list_name.text = "First Breed"
	app._project_create_list()
	var first_list = app.project_add_list_id
	app.project_new_list_name.text = "Second Batch"
	app._project_create_list()
	var second_list = app.project_add_list_id
	check(Plans.lists_of(app._project_current()).size() == 3, "named sub-lists added to one project")
	check(first_list != second_list and first_list != Plans.MAIN_LIST_ID, "breeding lists have distinct IDs")
	app._project_move_to_list("test-otter-0", first_list)
	app._project_move_to_list("test-otter-1", first_list)
	app._project_move_to_list("test-otter-2", first_list)
	check(Plans.members_in_list(app._project_current(), first_list).size() == 3, "move to First Breed without duplication")
	check(Plans.members_in_list(app._project_current(), Plans.MAIN_LIST_ID).size() == 2, "other otters remain in Main List")
	app._project_set_position(original_key, "test-otter-2", "1")
	check(Plans.member_position(app._project_current(), "test-otter-2") == 1, "position numbers work within First Breed")
	app._project_move_to_list("test-otter-3", second_list)
	check(Plans.member_position(app._project_current(), "test-otter-3") == 1, "Second Batch numbering starts independently")
	app._project_move_creature("test-otter-3", "test-otter-0", false)
	check(Plans.members_in_list(app._project_current(), first_list).size() == 4, "dragging onto another list changes membership")
	app._project_move_one("test-otter-3", 1)
	check(Plans.member_position(app._project_current(), "test-otter-3") == 3, "arrow move stays within destination list")
	app._project_toggle_list(first_list)
	var open_state = true
	for entry in Plans.lists_of(app._project_current()):
		if str(entry["id"]) == first_list:
			open_state = bool(entry["open"])
	check(not open_state, "breeding list collapses and state saves")
	app.project_query = "test"  # A search filter must not modify order or list membership.
	app._render_project_board()
	check(Plans.members_in_list(app._project_current(), first_list).size() == 4, "filters do not alter list membership")
	app.project_query = ""
	app._project_rename_list(original_key, first_list, "Breeding Pair A")
	check(str(Plans.lists_of(app._project_current())[1]["name"]) == "Breeding Pair A", "breeding list can be renamed")
	var saved = app.storage.load_data()
	check(saved.get("projects", {}).has(original_key), "project persists on disk")
	check(Plans.members_in_list(saved["projects"][original_key], first_list).size() == 4, "list membership survives disk reload")
	check(Plans.member_position(saved["projects"][original_key], "test-otter-2") == 1, "position survives disk reload")
	# Deletes only a grouping; nothing disappears from library or project.
	app.pending_project_list_delete_id = first_list
	app.pending_project_list_delete_project_id = original_key
	app._project_delete_list_confirmed()
	check(Plans.lists_of(app._project_current()).size() == 2, "list deletion removes only the group")
	check(Plans.members_in_list(app._project_current(), Plans.MAIN_LIST_ID).size() == 5, "deleting group moves its otters back into Main List")
	check(Plans.members_of(app._project_current()).size() == 5 and app.data["creatures"].size() == 5, "no creatures lost or duplicated")
	var legacy = {"members": [{"id": "old-otter", "alias": "Old friend", "x": 300, "y": 200}]}
	check(Plans.lists_of(legacy).size() == 1 and Plans.member_position(legacy, "old-otter") == 1, "0.3.8 project can load without migration")
	app.queue_free()
	await process_frame
	for suffix in ["", ".tmp", ".backup"]:
		if FileAccess.file_exists(path + suffix):
			DirAccess.remove_absolute(ProjectSettings.globalize_path(path + suffix))
	print("NAMED LIST & POSITION TESTS COMPLETE; failures: ", failures.size())
	quit(0 if failures.is_empty() else 1)
