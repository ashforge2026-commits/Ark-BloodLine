extends SceneTree

const Palette = preload("res://scripts/palette.gd")
const Registry = preload("res://scripts/species_registry.gd")
const Parser = preload("res://scripts/ark_parser.gd")
const Goals = preload("res://scripts/color_goals.gd")
const Bingo = preload("res://scripts/bingo.gd")
var failures: Array = []

func check(value: bool, label: String) -> void:
	if value:
		print("PASS: ", label)
	else:
		printerr("FAIL: ", label)
		failures.append(label)

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	root.size = Vector2i(1280, 720)
	var palette = Palette.new()
	var parser = Parser.new(palette, Registry.new())
	var female = parser.parse_export(FileAccess.get_file_as_string("res://examples/DEMO_Female_XOtter.ini"), "DEMO.ini")["creature"]
	var male = parser.parse_export(FileAccess.get_file_as_string("res://examples/DEMO_Male_XOtter.ini"), "DEMO.ini")["creature"]
	female["local_id"] = "female-1"
	male["local_id"] = "male-1"
	var key = female["species_key"]
	var rows = Bingo.build([female, male], key, female["region_names"], palette)
	check(rows.size() == 255 and rows[0]["id"] == 1 and rows[254]["id"] == 255, "Bingo includes every ID from 1 to 255")
	check(rows[100]["status"] == "undefined" and rows[254]["status"] == "undefined", "undefined palette IDs are not treated as missing colors")
	check(rows[5]["found"] == 4 and rows[5]["total"] == 5 and rows[5]["status"] != "bingo", "synthetic Magenta target is four of five")
	var one_away = Bingo.filtered(rows, "6", 2, 0)
	check(one_away.size() > 0 and one_away[0]["id"] == 6, "one-away filter finds the demo target")
	male["regions"][5] = palette.from_id(6)
	rows = Bingo.build([female, male], key, female["region_names"], palette)
	check(rows[5]["status"] == "bingo" and rows[5]["found"] == 5, "five confirmed visible regions produce Bingo")
	check(Bingo.filtered(rows, "", 0, 1)[0]["id"] == 255, "descending ID sort begins at 255")
	check(Bingo.filtered(rows, "", 0, 2)[0]["status"] == "bingo", "Bingo-first sort places completion first")
	var sorting_examples: Array = [
		{"id": 180, "name": "complete later ID", "defined": true, "status": "bingo", "found": 5, "total": 5, "unknown": 0},
		{"id": 6, "name": "complete earlier ID", "defined": true, "status": "bingo", "found": 5, "total": 5, "unknown": 0},
		{"id": 70, "name": "four found", "defined": true, "status": "progress", "found": 4, "total": 5, "unknown": 0},
		{"id": 11, "name": "four found one unknown", "defined": true, "status": "unknown", "found": 4, "total": 5, "unknown": 1},
		{"id": 2, "name": "three found", "defined": true, "status": "progress", "found": 3, "total": 5, "unknown": 0},
		{"id": 4, "name": "two found", "defined": true, "status": "progress", "found": 2, "total": 5, "unknown": 0},
		{"id": 1, "name": "one found", "defined": true, "status": "progress", "found": 1, "total": 5, "unknown": 0},
		{"id": 12, "name": "not found", "defined": true, "status": "missing", "found": 0, "total": 5, "unknown": 0},
		{"id": 5, "name": "not in data", "defined": false, "status": "undefined", "found": 0, "total": 0, "unknown": 0}
	]
	var progress_sort = Bingo.filtered(sorting_examples, "", 0, 3)
	var ordered_ids: Array = []
	for row in progress_sort:
		ordered_ids.append(int(row["id"]))
	check(ordered_ids == [6, 180, 11, 70, 2, 4, 1, 12, 5], "new sort uses Bingo, confirmed regions descending, then ID")
	check(progress_sort[2]["status"] == "unknown", "new sort preserves unknown state while ordering confirmed regions")
	var old_bingo_first = Bingo.filtered(sorting_examples, "", 0, 2)
	check(old_bingo_first[2]["id"] == 1 and old_bingo_first[3]["id"] == 2, "original Bingo-first option still orders the rest by ID")
	var completed_only = Bingo.filtered(sorting_examples, "", 1, 3)
	check(completed_only.size() == 2 and completed_only[0]["id"] == 6 and completed_only[1]["id"] == 180, "new sort works with the completed filter")
	var colors = Goals.calculate([female, male], key, female["region_names"], 6)
	check(str(colors["regions"][0]["carriers"][0]).contains("Lvl 200"), "carrier names include creature levels")
	var uncertain_f = female.duplicate(true)
	var uncertain_m = male.duplicate(true)
	uncertain_f["regions"][5] = {"state": "unknown", "id": null, "candidates": [], "raw": []}
	uncertain_m["regions"][5] = {"state": "unknown", "id": null, "candidates": [], "raw": []}
	var uncertain = Bingo.build([uncertain_f, uncertain_m], key, female["region_names"], palette)
	check(uncertain[5]["status"] == "unknown" and uncertain[5]["status"] != "bingo", "unknown color cannot create a false Bingo")
	var unknown_regions = Bingo.build([female], key, null, palette)
	check(unknown_regions[5]["status"] == "unknown", "unknown species regions cannot produce completion")
	var partial_regions = female["region_names"].duplicate()
	partial_regions[0] = "Unknown"
	var partial_male = male.duplicate(true)
	partial_male["regions"][5] = palette.from_id(79)
	var partial = Bingo.build([female, partial_male], key, partial_regions, palette)
	var partial_one_away = Bingo.filtered(partial, "6", 2, 0)
	var false_one_away = false
	for row in partial_one_away:
		if int(row["id"]) == 6:
			false_one_away = true
	check(partial[5]["status"] == "unknown" and partial[5]["found"] == 3 and partial[5]["total"] == 4 and not false_one_away, "unknown region metadata is excluded from one-away")
	var app = load("res://main.tscn").instantiate()
	root.add_child(app)
	app.data = {"version": 1, "creatures": [female, male], "goals": {}}
	app.selected_id = "female-1"
	app._show_bingo()
	await process_frame
	await process_frame
	for item in [[app.bingo_species, "Creature"], [app.bingo_search, "Find color"], [app.bingo_order, "Sort by"], [app.bingo_filter, "Filter"]]:
		var control: Control = item[0]
		var title = control.get_parent().get_child(0) as Label
		check(title.text == item[1] and title.get_theme_font_size("font_size") > control.get_theme_font_size("font_size"), item[1] + " has a larger label above its value")
	check(app.bingo_rows.size() == 255 and app.bingo_grid.get_child_count() == 255, "Bingo tab renders all 255 color cards")
	app.bingo_color_id = 6
	app._bingo_detail(6)
	var has_level = false
	for child in app.bingo_detail_box.find_children("*", "Button", true, false):
		if child is Button and child.text.contains("Lvl 200"):
			has_level = true
	check(has_level, "Bingo detail displays a clickable carrier with level")
	app.bingo_order.select(1)
	app._draw_bingo_grid()
	check(app.bingo_grid.get_child(0).tooltip_text.begins_with("Color 255:"), "Bingo UI descending sort works")
	check(app.bingo_order.get_item_text(3) == "Bingo + most regions", "new sort is available in the UI")
	app.bingo_order.select(3)
	app.bingo_order.item_selected.emit(3)
	check(app.bingo_grid.get_child(0).tooltip_text.begins_with("Color 6:"), "new UI sort displays completed colors first")
	for dimensions in [Vector2i(1680, 1050), Vector2i(1280, 720), Vector2i(1024, 768), Vector2i(960, 640)]:
		root.size = dimensions
		await process_frame
		await process_frame
		var view = app.get_viewport_rect().size
		var detail_rect = app.details.get_global_rect()
		var fit = detail_rect.end.x <= view.x + 1 and detail_rect.end.y <= view.y + 1
		for control in [app.bingo_species, app.bingo_search, app.bingo_order, app.bingo_filter]:
			fit = fit and control.get_global_rect().end.x <= app.middle.get_global_rect().end.x + 1
		check(fit, "Bingo controls fit at %sx%s" % [dimensions.x, dimensions.y])
	app._open_carrier("female-1")
	check(app.selected_page == "library" and app.selected_id == "female-1", "carrier link opens the right creature")
	app.queue_free()
	await process_frame
	print("BINGO TESTS COMPLETE; failures: ", failures.size())
	quit(0 if failures.is_empty() else 1)
