extends SceneTree

const Palette = preload("res://scripts/palette.gd")
const Registry = preload("res://scripts/species_registry.gd")
const Parser = preload("res://scripts/ark_parser.gd")
const Importer = preload("res://scripts/import_service.gd")
const Store = preload("res://scripts/storage.gd")
const Goals = preload("res://scripts/color_goals.gd")
const Zip = preload("res://scripts/zip_guard.gd")
var failures: Array = []

func check(condition: bool, label: String) -> void:
	if condition:
		print("PASS: ", label)
	else:
		failures.append(label)
		printerr("FAIL: ", label)

func _initialize() -> void:
	var palette = Palette.new()
	var registry = Registry.new()
	var parser = Parser.new(palette, registry)
	var importer = Importer.new(parser)
	check(palette.entries.size() >= 200, "ASA color palette loads")
	check(registry.by_blueprint.size() > 1000, "species registry loads")
	var red = palette.match_rgba([1.0, 0.0, 0.0, 0.0])
	var red_dye = palette.match_rgba([1.0, 0.0, 0.0, 1.0])
	check(red.get("id") == 1, "RGBA alpha distinguishes ordinary red")
	check(red_dye.get("id") == 131, "RGBA alpha distinguishes red coloring")
	# Based on a public ASA export-format example; identifying values were replaced.
	var asa_example = "[Dino Data]\nDinoID1=1\nDinoID2=2\nDinoClass=/Game/PrimalEarth/Dinos/Carcharodontosaurus/Carcha_Character_BP.Carcha_Character_BP_C\nDinoNameTag=Carcha\nbIsFemale=True\nTamedName=Example\nCharacterLevel=348\n[Colorization]\nColorSet[0]=(R=0.005000,G=0.005000,B=0.005000,A=0.000000)\n[Max Character Status Values]\nHealth=34838.4062\nMelee Damage=6.06000042\n"
	var actual_format = parser.parse_export(asa_example, "public-format-example.ini")
	check(actual_format.get("ok", false) and actual_format["creature"]["species_name"] == "Carcharodontosaurus" and actual_format["creature"]["sex"] == "Female", "public ASA export format and blueprint parse")
	var female_text = FileAccess.get_file_as_string("res://examples/DEMO_Female_XOtter.ini")
	var male_text = FileAccess.get_file_as_string("res://examples/DEMO_Male_XOtter.ini")
	var female = parser.parse_export(female_text, "DEMO/female.ini")
	var male = parser.parse_export(male_text, "DEMO/male.ini")
	check(female.get("ok", false) and male.get("ok", false), "both sample exports parse")
	if female.get("ok", false) and male.get("ok", false):
		var f: Dictionary = female["creature"]
		var m: Dictionary = male["creature"]
		check(f["sex"] == "Female" and m["sex"] == "Male", "female and male remain distinct")
		check(f["species_name"] == "X-Otter" and f["verified_species"], "blueprint maps to X-Otter")
		check(f["regions"][0].get("id") == 6 and f["regions"][1].get("state") == "empty", "color and empty region are distinct")
		check(absf(float(f["stats"].get("health", 0)) - 54.4) < 0.0001, "max health is read as a value")
		check(absf(float(f["stats"].get("melee damage", 0)) - 0.7) < 0.0001, "raw melee modifier preserved")
		var missing_sex = parser.parse_export(female_text.replace("bIsFemale=True", "bIsFemale=Maybe"), "missing.ini")
		check(missing_sex["creature"]["sex"] == "Unknown", "unknown sex is not set to male")
		var missing_health = parser.parse_export(female_text.replace("Health=54.400000", "Health=invalid"), "bad.ini")
		check(not missing_health["creature"]["stats"].has("health"), "invalid stat is not zero-filled")
		var creature_list: Array = [f, m]
		var goal = Goals.calculate(creature_list, f["species_key"], f["region_names"], 6)
		check(goal["found"] == 4 and goal["total"] == 5, "solid target finds 4/5 demo regions")
		check(goal["regions"][5]["status"] == "missing", "missing region 5 is identified")
		check(goal["regions"][1]["status"] == "unused", "unused region excluded")
		var unknown_list = creature_list.duplicate(true)
		unknown_list[0]["regions"][5] = {"state": "unknown", "id": null, "candidates": [], "raw": []}
		var uncertain_goal = Goals.calculate(unknown_list, f["species_key"], f["region_names"], 6)
		check(uncertain_goal["regions"][5]["status"] == "unknown", "unknown color is not a false missing")
		unknown_list[0]["regions"][5] = {"state": "empty", "id": null, "candidates": [], "raw": []}
		uncertain_goal = Goals.calculate(unknown_list, f["species_key"], f["region_names"], 6)
		check(uncertain_goal["regions"][5]["status"] == "unknown", "empty data on a visible region needs review")
	var guard = Zip.inspect("res://examples/DEMO_XOtters.zip")
	check(guard.get("ok", false) and guard.get("entries", []).size() == 2, "nested ZIP accepts exactly two INIs")
	var plan = importer.prepare("res://examples/DEMO_XOtters.zip", [])
	check(plan.get("ok", false), "ZIP import preparation succeeds")
	if plan.get("ok", false):
		check(plan["counts"]["new"] == 2 and plan["errors"].is_empty(), "ZIP CRC and two demo records succeed")
		var initial = {"version": 1, "creatures": [], "goals": {}}
		var merged = importer.apply_plan(plan, initial)
		check(merged["creatures"].size() == 2 and initial["creatures"].is_empty(), "import creates new data without mutating old")
		var again = importer.prepare("res://examples/DEMO_XOtters.zip", merged["creatures"])
		check(again.get("ok", false) and again["counts"]["unchanged"] == 2, "reimport does not duplicate identified dinos")
		var test_path = "user://_bloodlinebank_test_%s.json" % Time.get_ticks_usec()
		var store = Store.new(test_path)
		check(store.save_data(merged).get("ok", false), "first local save")
		var changed = merged.duplicate(true)
		changed["goals"]["example"] = {"color_id": 6, "note": "test"}
		check(store.save_data(changed).get("ok", false), "second save and backup")
		var loaded = store.load_data()
		check(loaded["creatures"].size() == 2 and loaded["goals"].has("example"), "library and goal persist")
		var broken = FileAccess.open(test_path, FileAccess.WRITE)
		broken.store_string("broken")
		broken.close()
		var recovery = store.load_data()
		check(recovery.get("read_only", false) and recovery["creatures"].size() == 2, "corrupt latest save falls back read-only to backup")
		for suffix in ["", ".tmp", ".backup"]:
			var path = ProjectSettings.globalize_path(test_path + suffix)
			if FileAccess.file_exists(path):
				DirAccess.remove_absolute(path)
	print("TESTS COMPLETE; failures: ", failures.size())
	quit(0 if failures.is_empty() else 1)
