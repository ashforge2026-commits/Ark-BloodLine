extends SceneTree

const Store = preload("res://scripts/storage.gd")
var failures: Array = []

func check(value: bool, label: String) -> void:
	if value:
		print("PASS: ", label)
	else:
		printerr("FAIL: ", label)
		failures.append(label)

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	if OS.get_environment("BLOODLINEBANK_TEST_MODE") != "1":
		printerr("Use BLOODLINEBANK_TEST_MODE=1 with isolated user data.")
		quit(1)
		return
	var folder = ProjectSettings.globalize_path("user://_color_table_scan")
	DirAccess.make_dir_recursive_absolute(folder)
	DirAccess.copy_absolute(ProjectSettings.globalize_path("res://examples/DEMO_Female_XOtter.ini"), folder.path_join("new_otter.ini"))
	var app = load("res://main.tscn").instantiate()
	root.add_child(app)
	app.storage = Store.new("user://_color_table_scan_test.json")
	app.data = app.storage.empty_data()
	app.export_folder = folder
	app.scan_state = {"files": {}, "archives": {}}
	app._show_color_table()
	app.color_table_inputs[0].text = "6"
	app.color_table_inputs[0].text_changed.emit("6")
	app._start_scan(false)
	for i in range(200):
		await create_timer(0.05).timeout
		if not app.is_importing:
			break
	check(not app.is_importing and app.data.get("creatures", []).size() == 1, "scan imports a newly exported creature while the table is open")
	check(app.selected_page == "color_table" and app._color_table_filtered().size() == 1, "the open table refreshes with the new matching creature")
	check(app.color_table_inputs[0].text == "6" and app.color_table_species.item_count == 2, "scan retains the region filter and updates the species list")
	app._delete_selected()
	check(app.selected_page == "color_table" and app.data.get("creatures", []).is_empty(), "removal from table details refreshes the same table")
	check(app.color_table_inputs[0].text == "6" and app.color_table_species.item_count == 1, "removing the last creature keeps filters and updates species")
	app.queue_free()
	await process_frame
	print("COLOR TABLE SCAN TESTS COMPLETE; failures: ", failures.size())
	quit(0 if failures.is_empty() else 1)
