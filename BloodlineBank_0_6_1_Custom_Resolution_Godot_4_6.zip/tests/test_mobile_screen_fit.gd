extends SceneTree

# Run in isolated user data: BLOODLINEBANK_TEST_MODE=1 godot --headless --path . --script res://tests/test_mobile_screen_fit.gd
var failures: Array = []

func check(condition: bool, message: String) -> void:
	if condition:
		print("PASS: ", message)
	else:
		printerr("FAIL: ", message)
		failures.append(message)

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	if OS.get_environment("BLOODLINEBANK_TEST_MODE") != "1":
		printerr("Refusing to run without BLOODLINEBANK_TEST_MODE=1")
		quit(1)
		return
	root.size = Vector2i(360, 720)
	var app = preload("res://mobile_main.tscn").instantiate()
	root.add_child(app)
	await process_frame
	check(app.nav_items.size() == 5, "Five primary navigation buttons")
	for key in ["library", "lab", "bingo", "partner", "more"]:
		check(app.nav_items.has(key), "Navigation reachable: " + key)
		if app.nav_items.has(key):
			check(app.nav_items[key].custom_minimum_size.y >= 48, "Touch target at least 48 units: " + key)
	check(app.has_node("SafeArea/Frame/BottomNavigation"), "Persistent safe-area bottom navigation exists")
	check(app.has_node("SafeArea/Frame/Pages"), "Flexible scrollable page area exists")
	app._show_page("more")
	await process_frame
	check(app.active_page == "more", "More menu opens")
	app._show_page("lab")
	await process_frame
	check(app.active_page == "lab" and is_instance_valid(app.lab_widget), "Color Lab opens in mobile shell")
	if is_instance_valid(app.lab_widget):
		check(app.lab_widget.model.ids.size() == 6, "Lab keeps the full six-slot data model")
		var strip = app.lab_widget.find_child("ColorLabRegionStrip", true, false) as HBoxContainer
		await process_frame
		await process_frame
		check(strip.get_child_count() == 6 and strip.get_global_rect().end.x <= root.size.x, "six Color Lab controls fit across a 360-unit phone viewport")
	app._show_page("library")
	await process_frame
	check(app.active_page == "library", "Back to library after Color Lab")
	print("MOBILE SCREEN FIT TEST COMPLETE; failures: ", failures.size())
	quit(0 if failures.is_empty() else 1)
