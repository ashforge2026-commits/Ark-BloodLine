extends SceneTree

const Palette = preload("res://scripts/palette.gd")
const Registry = preload("res://scripts/species_registry.gd")
const Parser = preload("res://scripts/ark_parser.gd")
const Importer = preload("res://scripts/import_service.gd")
const Scanner = preload("res://scripts/folder_scan.gd")
const Extract = preload("res://scripts/archive_extract.gd")
const Guard = preload("res://scripts/zip_guard.gd")
var failures: Array = []

func check(value: bool, label: String) -> void:
	if value:
		print("PASS: ", label)
	else:
		printerr("FAIL: ", label)
		failures.append(label)

func remove_tree(path: String) -> void:
	var d = DirAccess.open(path)
	if d == null:
		return
	for name in d.get_files():
		DirAccess.remove_absolute(path.path_join(name))
	for name in d.get_directories():
		remove_tree(path.path_join(name))
	DirAccess.remove_absolute(path)

func _initialize() -> void:
	var tmp = ProjectSettings.globalize_path("user://_scan_test_%s" % Time.get_ticks_usec())
	DirAccess.make_dir_recursive_absolute(tmp)
	var parser = Parser.new(Palette.new(), Registry.new())
	var scan = Scanner.new(parser)
	var importer = Importer.new(parser)
	var archive_path = tmp.path_join("safe.zip")
	DirAccess.copy_absolute(ProjectSettings.globalize_path("res://tests/fixtures/safe_synthetic.zip"), archive_path)
	var source_hash = FileAccess.get_sha256(archive_path)
	var first = scan.scan(tmp, [], {"files": {}, "archives": {}})
	check(first.get("ok", false) and first["counts"]["new"] == 2, "startup scan imports two new identified creatures")
	check(first["counts"]["extracted"] == 3 and first["counts"]["archives"] == 1, "ZIP extracts both INIs and ordinary text")
	check(FileAccess.get_sha256(archive_path) == source_hash, "original ZIP stays intact")
	var initial = {"version": 1, "creatures": [], "goals": {"saved": {"note": "keep me"}}}
	var merged = importer.apply_plan({"records": first["records"]}, initial)
	check(merged["creatures"].size() == 2 and merged["goals"]["saved"]["note"] == "keep me", "scan preserves saved goals")
	var second = scan.scan(tmp, merged["creatures"], first["state"])
	check(second.get("ok", false) and second["counts"]["new"] == 0 and second["counts"]["archives"] == 0, "repeat scan skips duplicates and processed ZIP")
	var deleted = merged["creatures"].duplicate(true)
	deleted.remove_at(0)
	var after_delete = scan.scan(tmp, deleted, second["state"])
	check(after_delete["counts"]["new"] == 0, "previously scanned files do not resurrect a deleted creature")
	var changed_path = ""
	for p in first["state"]["files"]:
		if str(p).get_file().to_lower().ends_with("female.ini"):
			changed_path = str(p)
			break
	check(not changed_path.is_empty(), "extracted creature path recorded")
	if not changed_path.is_empty():
		var text = FileAccess.get_file_as_string(changed_path).replace("Health=54.400000", "Health=99.000000")
		var f = FileAccess.open(changed_path, FileAccess.WRITE)
		f.store_string(text)
		f.close()
		var changed = scan.scan(tmp, merged["creatures"], second["state"])
		check(changed["counts"]["review"] == 1 and changed["counts"]["new"] == 0, "changed existing creature is queued for review")
		var repeat_review = scan.scan(tmp, merged["creatures"], changed["state"])
		check(repeat_review["counts"]["review"] == 1 and repeat_review["pending"].size() == 1, "pending review survives the next scan")
		var unpack_again = Extract.extract_archive(archive_path, tmp)
		check(not unpack_again.get("ok", false) and FileAccess.get_file_as_string(changed_path).contains("99.000000"), "ZIP extraction never overwrites a changed file")
	var bad = Guard.inspect("res://tests/fixtures/traversal.zip", true)
	check(not bad.get("ok", false), "ZIP traversal is rejected")
	var link = Guard.inspect("res://tests/fixtures/symlink.zip", true)
	check(not link.get("ok", false), "ZIP symlink is rejected")
	var corrupt_dir = tmp.path_join("corrupt")
	DirAccess.make_dir_recursive_absolute(corrupt_dir)
	DirAccess.copy_absolute(ProjectSettings.globalize_path("res://tests/fixtures/corrupt_synthetic.zip"), corrupt_dir.path_join("corrupt.zip"))
	var corrupt = scan.scan(corrupt_dir, [], {"files": {}, "archives": {}})
	check(corrupt.get("ok", false) and corrupt["counts"]["new"] == 0 and not corrupt["errors"].is_empty(), "bad CRC prevents partial creature import")
	var conflict_dir = tmp.path_join("conflicts")
	DirAccess.make_dir_recursive_absolute(conflict_dir)
	var raw = FileAccess.get_file_as_string("res://examples/DEMO_Female_XOtter.ini")
	for i in range(2):
		var f = FileAccess.open(conflict_dir.path_join("same_%s.ini" % i), FileAccess.WRITE)
		f.store_string(raw.replace("TamedName=DEMO Female X-Otter", "TamedName=Duplicate %s" % i))
		f.close()
	var conflict = scan.scan(conflict_dir, [], {"files": {}, "archives": {}})
	check(conflict["counts"]["new"] == 0 and conflict["counts"]["review"] == 2, "conflicting versions are not silently selected")
	var no_id_dir = tmp.path_join("no_id")
	DirAccess.make_dir_recursive_absolute(no_id_dir)
	var no_id_file = FileAccess.open(no_id_dir.path_join("unknown.ini"), FileAccess.WRITE)
	no_id_file.store_string(raw.replace("DinoID1=123456789\n", "").replace("DinoID2=111\n", ""))
	no_id_file.close()
	var no_id = scan.scan(no_id_dir, [], {"files": {}, "archives": {}})
	check(no_id["counts"]["new"] == 0 and no_id["counts"]["review"] == 1, "creature with no ID waits for manual review")
	var partial_dir = tmp.path_join("partial")
	DirAccess.make_dir_recursive_absolute(partial_dir)
	var partial_file = FileAccess.open(partial_dir.path_join("partial.ini"), FileAccess.WRITE)
	partial_file.store_string(raw.get_slice("[Colorization]", 0))
	partial_file.close()
	var partial = scan.scan(partial_dir, [], {"files": {}, "archives": {}})
	check(partial["counts"]["new"] == 0 and partial["counts"]["review"] == 1, "incomplete export sections wait for review")
	check(not scan.scan(tmp.path_join("missing-folder"), [], {"files": {}, "archives": {}}).get("ok", false), "missing folder is reported without touching library")
	remove_tree(tmp)
	print("SCAN TESTS COMPLETE; failures: ", failures.size())
	quit(0 if failures.is_empty() else 1)
