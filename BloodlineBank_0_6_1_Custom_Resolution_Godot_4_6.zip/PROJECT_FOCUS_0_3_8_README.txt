BloodlineBank 0.3.8 — Projects Expand / Restore
==================================================

REQUEST
Expand the red-marked Projects planning area to almost fill the app window,
and toggle back to the existing view with the same button.

USAGE
1. Open Projects.
2. Click "Expand workspace" in the upper-right title bar.
3. The sidebar and project creation/rename/delete row disappear.
   The same Notes, Filters, Otter Table, and Add Creatures area now use the
   freed width and height. The top title shows your current project name.
4. Click "Restore layout" to show the normal layout again.
5. If you navigate to a different page, the normal sidebar returns.

SAFETY / SCOPE
- Only scripts/main.gd and version text in project.godot were changed.
- No changes to the library, projects save schema, creature IDs, sort/reorder,
  notes checklist, ARK auto sync, Color Table, Bingo, or creatures/assets.
- Focus mode is temporary UI state, not saved to disk.
- Toggling does not recreate the table; it preserves active filters,
  in-progress text input, project selection, scroll and drag controls.
- This is an in-window planning focus view, NOT operating-system fullscreen.
  User can maximize the BloodlineBank desktop window normally for more area.

TEST
- Open existing project with notes and otter rows.
- Click Expand, check sidebar and options row are gone, table is wider/taller,
  and Restore remains visible.
- Enter text, drag or reorder a row, toggle notes, open Add Creatures.
- Click Restore, verify the standard layout and all data unchanged.
- Navigate to Color Table and back; sidebar should be visible.
- Resize the application window during each mode.
- Included automated smoke test: tests/test_project_focus.gd

VERIFICATION
Static source, ZIP integrity, and reference checks performed. Godot 4.6
runtime checks require a local Godot executable; do not treat this as a
Windows UI tested/confirmed build before running it.
