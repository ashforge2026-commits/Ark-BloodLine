BLOODLINEBANK 0.4.1 — REORDER ENTIRE BREEDING LISTS

BASE: 0.4.0 Easy Drag & Drop (no importer, auto-sync, assets or creature changes).

HOW TO USE
- In Projects, drag a WIDE breeding-list header (↕ First Breed, Main List, etc.)
  over ANOTHER wide breeding-list header and release.
- Drop on the UPPER half of another header to place your section BEFORE it;
  LOWER half places it AFTER it.
- Easier: drop the header onto ANY otter picture/name or blank row area
  belonging to the other list. The whole batch moves adjacent to that list
  automatically (before when moving upward, after when moving downward).
  No need to scroll past 27 otters to reach the Main List header!
- The small ↑ / ↓ controls beside each header are alternatives for moving the
  entire batch one place at a time. Main List can be moved, but cannot be deleted.
- List drag supports existing table edge auto-scroll, made faster for whole lists.
- Click a header without dragging to expand/collapse as before.
- Creature drags to headings still move only that otter; they are unchanged.
- The reordered group is scrolled into view where possible.

SAFETY + BACKWARD COMPATIBILITY
- Adds only an OPTIONAL 'list_order' array to each project's saved dictionary.
- Existing 0.4.0 projects (even large 27-otter Main Lists) load as before until
  you reorder; then relative list order is saved automatically.
- List moves NEVER change project membership, row order inside groups, creature
  IDs, Color Table, notes, your ARK exports, or your saved creature library.
- Unknown or deleted IDs in list_order are safely ignored. Newly created lists
  appear at the bottom; deleting a list still returns its members to Main List.
- Main List remains the permanent default for any legacy/unknown list assignment.

VERIFICATION
Static integrity checks and a new test_project_list_order.gd are included.
To run the new test (with Godot 4.6 installed) from project folder:
  BLOODLINEBANK_TEST_MODE=1 BLOODLINEBANK_DISABLE_AUTOSCAN=1 \
  godot --headless --path . --script res://tests/test_project_list_order.gd
Use an ISOLATED Godot user data directory for tests. Back up your app data
before loading a new candidate. Runtime drag still requires real UI testing.
