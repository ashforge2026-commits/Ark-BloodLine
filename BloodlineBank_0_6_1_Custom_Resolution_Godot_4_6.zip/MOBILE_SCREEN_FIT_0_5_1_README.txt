BLOODLINEBANK v0.5.1 — PHONE SCREEN FIT PASS (Godot 4.6)
========================================================
Goal: keep controls readable on the user's Redmi Note 11S (1080x2400)
while making common Android portrait/landscape aspect ratios usable.

CHANGED
- Responsive mobile design canvas: 420x820 portrait or 820x420 landscape,
  expanded to use tall/wide extra space, rather than scaling desktop 1280x720.
- Sensor rotation enabled on Android. Rechecks canvas design size when the
  window/screen rotates or a --mobile-preview window is resized.
- Five large always-visible bottom tabs: Otters, Lab, Bingo, Breed, More.
  Color Table, Projects, Lowest Stats, backups and imports are in More.
- Added safe-margin container, including capped insets from Android's display
  safe rectangle, to reduce overlap with notches / gesture areas.
- Control heights 50-56 logical units and clipped text where necessary.
- Color Lab uses compact left preview + right controls in landscape; remains
  a vertically scrollable one-column page in portrait.
- Color picker popup size clamps to the available viewport in both rotations.
- Picker initially renders 60 choices, with ID/name search accessing the rest.

SCREEN-SIZE MATH (static check; not actual screenshots)
- Redmi Note 11S portrait 1080x2400: 420x933 effective logical UI area.
- Redmi Note 11S landscape 2400x1080: 933x420 effective logical UI area.
- Other small phone and tablet sizes checked arithmetically.

UNCHANGED
- Existing PC user interface, creature data, parsing, persistence, database,
  breeding calculations, shader, X-Otter images and Color Lab data model.
- Android import / Android file-provider limitations are unchanged.

TRY IT ON PC
- Run usual project for PC UI.
- Run `godot --path . -- --mobile-preview` then resize window to a narrow
  portrait shape or a short landscape shape; inspect every tab.
- On Android, export a debug APK using Godot 4.6 Android export templates;
  portrait should work first and rotation should reflow the lab.

NEXT TESTS REQUIRED
- Actual Godot 4.6 parser + headless tests: tests/test_color_lab.gd and
  tests/test_mobile_screen_fit.gd, with BLOODLINEBANK_TEST_MODE=1.
- Real Android UI check: header/bottom tabs not obscured by cutouts/navigation,
  search opens software keyboard, popup usable on landscape, list can scroll,
  otter picture remains visible, and file picker Android behavior.
- PC regression: keep using the original desktop launch scene with its tests.

STATUS
Implemented. Source references, JSON, and ZIP verified statically.
Not Godot-runtime validated or tested on a phone. This is a project ZIP,
not an APK. Do not call device-fit confirmed until real hardware test.
