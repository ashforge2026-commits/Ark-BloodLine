BloodlineBank 0.3.7 — Projects Table + Notes
==============================================

WHAT CHANGED
- The Projects page is now a full-width COLOR-TABLE-LIKE list, rather than free-floating cards.
- Only the six R0-R5 FILTER input boxes were removed from Projects. The actual
  six R0-R5 creature color COLUMNS remain visible.
- Search, species, and sex filters affect BOTH the saved project table and the
  collapsible Add Creatures chooser. Search also matches custom row names and color IDs.
- Add creatures from the collapsible section at the bottom; existing records
  are referenced by stable local_id, never copied into project data.
- Drag the cyan up/down handle (↕) onto a different row to change order;
  or use the ↑ / ↓ buttons if dragging is inconvenient.
- Set an optional per-project nickname in each row's 'Your label' field.
  Press Enter or click away to save. It does not rename the actual ARK export.
- Collapsible Notes at the top contains checklist items. Use the checkbox to
  strike through completed lines, Edit to change the text, X to remove, and
  + Add note to insert a line. Notes and open/closed state are saved per project.
- Rename a project by typing its new name in the top field and clicking Rename.

MIGRATION / SAFETY
- 0.3.5/0.3.6 projects keep the same project IDs and member IDs.
- Old x/y board placement values may remain in JSON for backwards compatibility,
  but 0.3.7 ignores them and displays the stored membership order as table rows.
- Existing creatures, goals, Bingo, original Color Table, import and auto-sync
  systems are not modified by this feature.
- Any project change is saved via the existing atomic-save-plus-backup path.
- Before first run, make an extra backup of the BloodlineBank_Prototype user data
  folder on Windows (%APPDATA%/BloodlineBank_Prototype/bloodlinebank.json).

TESTING
- Godot 4.6 required. Open project.godot and run normally.
- To run a dedicated headless test on your machine (Godot on PATH):
    BLOODLINEBANK_TEST_MODE=1 BLOODLINEBANK_DISABLE_AUTOSCAN=1 \
      godot --headless --path . -s res://tests/test_projects.gd
  On Windows PowerShell:
    $env:BLOODLINEBANK_TEST_MODE='1'
    $env:BLOODLINEBANK_DISABLE_AUTOSCAN='1'
    godot --headless --path . -s res://tests/test_projects.gd
- Manually validate mouse dragging, short/window-narrow horizontal scrolling,
  new notes strikethrough, saved reorder after restart, and ongoing ARK auto-sync.

VERIFICATION SCOPE
- Candidate implementation and static checks only where Godot executable is
  unavailable. The release is not yet confirmed working on the user's Windows PC.
