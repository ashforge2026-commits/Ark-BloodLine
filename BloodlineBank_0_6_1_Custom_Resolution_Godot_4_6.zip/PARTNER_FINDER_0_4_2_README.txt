BLOODLINEBANK 0.4.2 — PARTNER FINDER
====================================

Based on the original 0.4.1 Reorder Breeding Lists PC project.

NEW: Left sidebar > Partner Finder
1. Browse/search your MALE creatures (name, species, level, or exact color ID).
   Males with the most repeated confirmed colors appear first.
2. Click a male. He stays pinned at the top; the picker hides. Use Change Male
   to reopen the male list.
3. Select Target color. The dropdown is prefilled from that male's confirmed
   visible color regions (most repeated first; supports 2, 3, 4 and even 1).
4. Click Find Females. The results table matches the original library style,
   with thumbnails, levels, sex, six region swatches and a coverage score.
5. Females from the SAME species/variant are sorted by:
   (a) the most target-color regions the male is missing that SHE has,
   (b) the most confirmed target-color regions on the female,
   (c) stable name/ID ties.
6. Choose a female to see the right-hand comparison, new color regions,
   guaranteed overlapping regions, uncovered regions and her preview.
   Open Female in Library navigates to her complete details.

EXAMPLE (X-Otter, five usable regions)
Male has #75 in R0, R2, R4: 3/5.
Female A has #75 in R3, R5: +2 new, combined coverage 5/5 (rank higher).
Female B has #75 only in R0, R2: +0 new, combined 3/5 (HIDDEN).
'Coverage 5/5' does NOT mean the baby is guaranteed solid #75: each region
with only one carrier can inherit the other parent's color. Only matched
regions in both parents are guaranteed for the selected color, ignoring
other game effects. The finder ranks based on coverage, not probability.

SAFETY/COMPATIBILITY
- Read-only calculation: changes no saved creature, project, goal or list.
- Existing local user:// library path and format are unchanged from 0.4.1.
- Unknown/ambiguous colors do not count as confirmed matches.
- Only known active regions count; unused/invisible slots are excluded.
- Excludes known-neutered animals and animals without known male/female sex.
- Uses exact species key, not just names; no unsupported cross-variant pairing.
- New files: scripts/partner_finder.gd, tests/test_partner_finder.gd.
- Main integration: scripts/main.gd (sidebar + Partner Finder UI + refresh on sync).
- Does not add genetic stat ranking, family-tree checks or breeding estimates.

TEST
Open project.godot in GODOT 4.6 (standard GDScript editor), press F5,
open Partner Finder and test your real Otters.
Regression: run tests/test_partner_finder.gd with env
BLOODLINEBANK_TEST_MODE=1 BLOODLINEBANK_DISABLE_AUTOSCAN=1.
Also rerun tests/test_project_list_order.gd and tests/test_ui_flow.gd.

Note: This delivery was statically reviewed but Godot runtime was not
available in the editing environment, so the UI and tests MUST be run
locally before calling the feature confirmed working.

0.4.3 MATCH FILTER UPDATE (11 November 2026)
- Show a female only if at least one CONFIRMED target-color region is missing on the male.
- Do NOT hide females that both fill a missing region and overlap an already-covered region.
- Hide +0 new matches (even if they share several regions with the male).
- Ranking remains by new regions first, then total female target-color regions.
- No changes to imports, saved data, projects or breeding lists.
