BLOODLINEBANK 0.4.3 — USEFUL PARTNERS ONLY
==========================================
Based on the complete BloodlineBank 0.4.2 Partner Finder project.

Small change to Partner Finder search results:
- Female must have the chosen color in one or more ACTIVE regions where the selected male does not have it.
- An overlap in the male's already-covered regions does not disqualify the female.
- Females with +0 new matches no longer appear.
- Highest NEW coverage still ranks first, then more matching color regions on the female.

Example: male color 75 in R0, R2, R4.
Female with R3=75 and R0=75 appears (+1).
Female with R3=75 only appears (+1).
Female with R0=75 and R2=75 only is hidden (+0).

Changed files:
- scripts/partner_finder.gd (one condition + comment)
- scripts/main.gd (empty-results explanation)
- tests/test_partner_finder.gd (updated matching and UI tests)

Nothing else in the project's source changed. Local user:// data stays intact.
Run under Godot 4.6, check Partner Finder with real exports.
