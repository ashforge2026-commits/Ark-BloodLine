BLOODLINEBANK 0.3.9 — NAMED BREEDING LISTS + POSITION NUMBERS

Based on 0.3.8 Project Focus Workspace. This build changes only Projects
scripts/logic and tests; source importers, ARK Auto-Sync, color table,
color chips, notes, and original creatures are not changed.

HOW TO USE
1. Open Projects and your saved project (e.g. 79 solid).
2. Existing otters appear under Main List, with their old saved order.
3. Replace the old Your label input with Position. Type 1 and press Enter
   to send an otter to first place, or 5 to fifth. Values clamp to available
   rows in THAT list. Hidden/filter-mismatched otters still count in saved order.
4. At the top of the table, type First Breed into New list name and click
   + New list. Repeat for Second Batch, etc.
5. In each otter row, use Move to list to transfer it between your batches.
   Or drag the ↕ handle onto a row in another batch. Up/down arrows only
   reorder inside that batch.
6. Click a breeding list header to collapse/expand that list. The state saves.
7. Rename a batch by editing its name field on the header. Press Enter.
8. In Add creatures from library, choose "Add to: ..." to pick the target list.
9. Delete list prompts for confirmation: ALL otters are returned to Main List;
   they are never removed from your project or the creature library.

COMPATIBILITY
- Older projects remain supported. Their saved members automatically appear
  in Main List. There is no forced migration or loss of existing member aliases.
- Old project-only custom labels are preserved in JSON and displayed as the
  creature name if they exist. New rows use numeric positions instead of an
  editable alias. Position belongs to a list, not a creature property.
- List IDs and selected grouping belong only to each project.
- Notes, creature library, exports, automatic ARK sync, and search filters remain.
- Full save path is the same user://bloodlinebank.json as previous versions.
  BACK UP that file before running a new candidate.

TESTING
Run the existing Godot project tests plus:
  BLOODLINEBANK_TEST_MODE=1 BLOODLINEBANK_DISABLE_AUTOSCAN=1 \
    godot --headless --path . --script res://tests/test_project_lists.gd
Use an isolated Godot user-data directory.

IMPORTANT
Code integration and structural checks may pass here, but an actual Godot 4.6
run on your Windows PC is still needed to confirm the controls work.
