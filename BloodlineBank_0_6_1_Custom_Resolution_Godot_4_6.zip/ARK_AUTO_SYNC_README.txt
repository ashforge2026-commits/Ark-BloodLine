BloodlineBank 0.3.6 — ARK Survival Ascended Auto-Sync (Godot 4.6)

NEW:
- On Windows, on first launch, detects the usual Steam installation:
  C:\Program Files (x86)\Steam\steamapps\common\ARK Survival Ascended\ShooterGame\Saved\DinoExports
- Also checks other common SteamLibrary roots on accessible Windows drives.
- Recursively scans .ini files in DinoExports, including user-ID subfolders.
- Auto scans at startup and every 45 seconds while BloodlineBank is open.
- New dinos with stable ARK IDs are added automatically and only once.
- Creature changes/conflicting files are held for manual review in Settings / Data.
- The ARK directory is READ ONLY: ZIPs in DinoExports are NOT extracted.
- User-chosen folders still work. Settings / Data > Choose folder.
- Settings / Data has a Use ARK folder button, Scan now, and an auto-sync toggle.
- Your current library, projects, colors, and saved plans are preserved.

IMPORTANT: This program does not press Export Dino for you in ARK. In ARK, export a dino using its interaction menu. Once ARK creates its .ini file, BloodlineBank reads it automatically when open (or on next launch).
If your game installation is not in a standard Steam location, choose its ShooterGame/Saved/DinoExports directory once.

FIRST TEST:
1. Back up your existing library (BloodlineBank local user data) before testing this candidate.
2. Open this project's project.godot in Godot 4.6, press F5.
3. Visit Settings / Data. Verify the export path is your real ARK DinoExports folder; use Choose folder if not.
4. Confirm auto-sync is checked. Verify your exported otters appear in Creature Library and Color Table.
5. Export another otter while BloodlineBank is open; verify it appears within about 45 seconds.
6. Restart BloodlineBank and confirm there are no duplicates; verify Projects layouts persist.
7. If you re-export an already imported otter after changing it, the export will be queued for REVIEW instead of silently replacing it.

Existing ZIP import, Color Bingo, Color Goals, project planning and visual system were intentionally left alone.
